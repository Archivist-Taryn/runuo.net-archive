BritanniaMOD
version 1.1 by CJ McAulay

BritanniaMOD is a total conversion (TC) for Morrowind. It is designed for fans of the Ultima series of games and those who would like
to make their own Ultima games or remakes using the Morrowind engine. You may use the mod for your own games, all I ask is you give me
credit by leaving my initials engraved in the bottom of Britanny Bay.
BritanniaMOD is a compilations of the Britannia's from Ultima 4,5,6,7 and 9 with an Elder Scrolls twist.

INSTALLING:
Unzip ultima.esp to your morrowind/datafiles directory

RUNNING:
Run morrowind and click datafiles.
Uncheck all plugins.
MAKE SURE YOU UNCHECK THE MASTER FILE Morrowind.esm!!!
Check Ultima.esp
Start a new game and go talk to the "gypsy" to pick your path.

DON'TS:
DO NOT SAVE OVER YOUR MAIN MORROWIND GAMES! It will irreversibly destroy your Morrowind saves, always start a new game with the Ultima mod.
DO NOT RUN OR EDIT WITH morrowind.esm CHECKED! This will cause god only knows what to happen, including crashing you to the desktop.

DISABLING:
Simply uncheck ultima.esp in the datafiles menu when you run morrowind and recheck morrowind.esm.

I am not resposible for any saves you destroy, quests you break, or computer crashes caused while you run this MOD.

website:
http://www.cjmcaulay.com

What's in Version 1.1:
-Landscaping 95% complete
-Moongates & Moonstones operating
-Some statics placed
