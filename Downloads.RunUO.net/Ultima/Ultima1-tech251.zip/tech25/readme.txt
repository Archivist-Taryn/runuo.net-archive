Hi,

Welcome to the second Tech-demo of Peroxide Productions remake of the
classic game Ultima 1. Below is a list of questions and answers that I
believe some you you would ask. Please read them before trying out the
demo so you know what your about to see ;)

If you did not get the Ultima tech demo from our official project page 
http://www.peroxide.dk/ultima then I suggest you go there for more 
information about this project and to see if the demo file has been updated.


CONTROLS:
---------

Arrow keys moves around, so does the Home,end, delete and page down. Left
mouse button "uses" things. Use a door to open it (if it's not locked) and
use a NPC to talk to him/her. ESC will bring up the in-game menu.


FAQ:
----

Q: Why is a blue screen with interface the only thing I see?
A: Your graphics card does not support the fogging used in the
   u1 engine. If you are using a Geforce2 graphics card with the
   detonator drivers you might have to switch on table fog emulation
   in your driver settings (this will not affect performance of other
   applications using your card). Right-click your desktop, select 
   properties, select the settings tab and click 'Advanced settings'.
   Another dialog should pop up with tabs regarding your graphics card.
   In one of them there will be an option for changing the Direct3D
   settings of your card (possibly you will have to press a button
   "Additional properties" in one of the tabs). Make sure 'fog table
   emulation is turned on'! 
      

Q: Why is this tech demo not running??
A: The most common reason for this demo not running is because you have
   extracted the files from the zip without directory information. There
   should be several directories next to your exe file (dialogs, u1, music
   etc.)
   If this is not your problem please email me with your system specs (cpu,
   ram, graphics card, OS etc.)

Q: What is a Tech-demo?
A: Tech-demo is short for Technology Demo and that is exactly what it is - 
   a demonstration of the technology developed for this game so far. This 
   means that many things are still missing from the engine that you would
   expect from a finished game. In this tech demo you can explore around and
   talk to people - but the NPCs have no real AI yet and will not walk around.
   Also it is not possible to fight monsters or access your quest log.
   
Q: What kinda machine should I have?
A: This demo requires a 3d accellerated card. We recommend a fairly good one 
   like GeForce2 or better. You should have a 800Mhz processor or better for
   smooth performance of the 3d engine. 


Q: Why is the game running so slow?
A: While the game engine has been optimized for speed to some degree there is
   still a few things which has not been implemented yet (such as occlusion 
   culling for example). The graphics detail in this demo is quite high and this
   does not come for free. We have chosen to target our game for future PCs so
   it will run fine when it's released - this means that unless you have a quite
   new machine now, then the demo will run a little slow.
   
  
Q: Can I invert the mouse?
A: Yes, from the in-game menu (press ESC)


Q: Can I change the key setup?
A: Not in this release - sorry!

Q: When will the whole game be finished?
A: I can't give you an exact date yet, but it will take awhile, sorry!

Q: How will I get the game once it's finished?
A: This is the great part : you just download it - because it's totally free!



COMMENTS :
----------

Please visit our forums at http://www.peroxide.dk/ultima with any comments or
bug reports. There will be two threads available - one for comments on the demo, 
another for bug reports.


KNOWN BUGS :
------------
 
 * When collinding against something the game might react by "pushing" you
   up and down in jerky movements.
 * Certain stairs performs poorly with the collision detection.
 * The sound might cracle now and then (at least on a SBLive!)
 * The animations for the NPCs are not too good at the moment ;)
 
 
