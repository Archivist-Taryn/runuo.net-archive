Ultima IX: Ascension - Version 1.19f

This is an unofficial patch and is installed at the user's risk.



This zip file should contain two (2) files:

Readme.txt - this file

U9patch119.exe - the patch file

------------------------------------------------------------------


Installation Instructions

Simply unzip u9patch119.exe anywhere on your hard drive and run the program.  It is recommended that you have Origin's last official patch (ver 1.18f)  installed before installing the 1.19f patch.

The patch should not adversely affect any existing savegames.


------------------------------------------------------------------



What is Fixed in version 1.19f:

-	D3D performance is improved

-	"too many items" bug fixed; having too many objects in a limited space doesn't resolve in a crash anymore

-	safedisc protection removed; safedisc caused problems running the game on some systems

-	spell damage has been tweaked
