Ultima IX: Ascension
--------------------

version 1.18

company: Origin (origin.ea.com)

We are happy to announce that we have completed a rigorous testing cycle on our
third patch, and it is now available for download! Once installed, the patch is
cumulative, meaning that it will include all fixes from the previous patches.
We have addressed many crucial issues, and believe that players will see an
improvement in performance as well as gameplay. Through our boards and other
communications, we have continued to monitor the feedback we have been given on
Ascension, and we feel everyone should be able to experience the full impact of
Ultima Ascension with the best results possible. Now that this patch is complete,
we will begin our work on the remastering of the install CD, which will be sent
to all registered owners of Ascension, free of charge. This CD will replace your
current install disk, and will include this latest patch.
To ensure that everyone playing Ultima Ascension experiences the highest possible
level of performance, we have also compiled a D3D.txt document, which features a
list of compatible D3D cards and provides the ideal settings for each of these
cards. We have included an options.txt document as well that details the settings
in the options.ini file, and how to use these to your best benefit.