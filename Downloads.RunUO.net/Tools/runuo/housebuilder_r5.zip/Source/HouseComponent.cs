using System;
using System.Drawing;

namespace Ultima
{
	public class HouseComponent : IComparable
	{
		private int m_Index, m_Z, m_Height;
		private int m_BaseIndex, m_Count;
		private Bitmap m_Image;

		public int Index{ get{ return m_Index; } }
		public int Z{ get{ return m_Z; } }
		public int Height{ get{ return m_Height; } }
		public Bitmap Image{ get{ return m_Image; } }

		public int BaseIndex{ get{ return m_BaseIndex; } }
		public int Count{ get{ return m_Count; } }

		public HouseComponent( int index, int z )
		{
			m_Index = index;
			m_Z = z;

			m_Height = TileData.ItemTable[index].CalcHeight;
			m_Image = Art.GetStatic( index );

			m_BaseIndex = index;
			m_Count = 1;
		}

		public HouseComponent( int index, int z, int baseIndex, int count )
		{
			m_Index = index;
			m_Z = z;

			m_Height = TileData.ItemTable[index].CalcHeight;
			m_Image = Art.GetStatic( index );

			m_BaseIndex = baseIndex;
			m_Count = count;
		}

		public int CompareTo( object obj )
		{
			HouseComponent hc = (HouseComponent)obj;

			if ( m_Z < hc.m_Z )
				return -1;
			else if ( hc.m_Z < m_Z )
				return 1;
			else if ( m_Height < hc.m_Height )
				return -1;
			else if ( hc.m_Height < m_Height )
				return 1;

			return 0;
		}
	}
}