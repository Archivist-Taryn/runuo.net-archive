using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Ultima
{
	public class Core : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mmMain;
		private System.Windows.Forms.MenuItem miFile;
		private System.Windows.Forms.MenuItem miNewDesign;
		private System.Windows.Forms.MenuItem miLoadDesign;
		private System.ComponentModel.Container components = null;

		public Core()
		{
			InitializeComponent();
		}

		[STAThread]
		public static void Main( string[] args )
		{
			Application.Run( new Core() );
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mmMain = new System.Windows.Forms.MainMenu();
			this.miFile = new System.Windows.Forms.MenuItem();
			this.miNewDesign = new System.Windows.Forms.MenuItem();
			this.miLoadDesign = new System.Windows.Forms.MenuItem();
			// 
			// mmMain
			// 
			this.mmMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.miFile});
			// 
			// miFile
			// 
			this.miFile.Index = 0;
			this.miFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.miNewDesign,
																				   this.miLoadDesign});
			this.miFile.MergeType = System.Windows.Forms.MenuMerge.MergeItems;
			this.miFile.Text = "&File";
			// 
			// miNewDesign
			// 
			this.miNewDesign.Index = 0;
			this.miNewDesign.Text = "&New Design";
			this.miNewDesign.Click += new System.EventHandler(this.miNewDesign_Click);
			// 
			// miLoadDesign
			// 
			this.miLoadDesign.Index = 1;
			this.miLoadDesign.Text = "&Load Design";
			this.miLoadDesign.Click += new System.EventHandler(this.miLoadDesign_Click);
			// 
			// Core
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(792, 573);
			this.IsMdiContainer = true;
			this.Menu = this.mmMain;
			this.Name = "Core";
			this.Text = "House Designer";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;

		}
		#endregion

		private void miNewDesign_Click(object sender, System.EventArgs e)
		{
			new NewDesigner( this ).Show();
		}

		private void miLoadDesign_Click(object sender, System.EventArgs e)
		{
			new HouseDesigner( new HouseDesign( "New Design.uoh" ), this ).Show();
		}
	}
}