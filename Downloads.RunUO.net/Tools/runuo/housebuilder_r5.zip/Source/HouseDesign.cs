using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Collections;

namespace Ultima
{
	public class HouseDesign
	{
		public const int Levels = 5;

		private static int[] m_LevelZ = new int[Levels]
			{
				0, 7, 27, 47, 67
			};

		public static int[] LevelZ{ get{ return m_LevelZ; } }

		private string m_Name;
		private string m_FilePath;

		private int m_Width, m_Height;
		private int m_UserWidth, m_UserHeight;
		private ArrayList[][][] m_Components;

		public string Name{ get{ return m_Name; } }
		public string FilePath{ get{ return m_FilePath; } }

		public int Width{ get{ return m_Width; } }
		public int Height{ get{ return m_Height; } }

		public int UserWidth{ get{ return m_UserWidth; } }
		public int UserHeight{ get{ return m_UserHeight; } }

		public ArrayList[][][] Components{ get{ return m_Components; } }

		public int xc, yc;

		public HouseDesign( string name, int width, int height )
		{
			m_Name = name;

			m_UserWidth = width;
			m_UserHeight = height;

			m_Width = width;
			m_Height = height + 1;

			Clear();
			BuildFoundation();
		}

		public bool GetBaseCount( TileSet root, int index, out int baseIndex, out int count )
		{
			for ( int i = 0; i < root.Entries.Count; ++i )
			{
				object o = root.Entries[i];

				if ( o is TileSet )
				{
					if ( GetBaseCount( (TileSet)o, index, out baseIndex, out count ) )
						return true;
				}
				else if ( o is TileSetEntry )
				{
					TileSetEntry tse = (TileSetEntry)o;

					if ( index >= tse.BaseIndex && index < tse.BaseIndex + tse.Count && Array.IndexOf( tse.Tiles, index ) >= 0 )
					{
						baseIndex = tse.BaseIndex;
						count = tse.Count;
						return true;
					}
				}
			}

			baseIndex = index;
			count = 1;

			return false;
		}

		public ArrayList Compress()
		{
			ArrayList list = new ArrayList();

			for ( int i = 0; i < HouseDesign.Levels; ++i )
			{
				for ( int x = 0; x < m_Width; ++x )
				{
					for ( int y = 0; y < m_Height; ++y )
					{
						ArrayList comps = m_Components[x][y][i];

						for ( int j = 0; j < comps.Count; ++j )
						{
							HouseComponent hc = (HouseComponent)comps[j];

							list.Add( new BuildEntry( x, y, hc.Z, hc.BaseIndex, hc.Count, i ) );
						}
					}
				}
			}

			bool combined, thisCombined;

			do
			{
				combined = false;

				for ( int i = 0; i < list.Count; ++i )
				{
					BuildEntry be = (BuildEntry)list[i];
					thisCombined = false;

					for ( int j = 0; !thisCombined && j < list.Count; ++j )
					{
						BuildEntry te = (BuildEntry)list[j];

						if ( i != j && be.CombineWith( te ) )
						{
							list.RemoveAt( i );
							--i;
							combined = thisCombined = true;
						}
					}
				}
			} while ( combined );

			return list;
		}

		public void SaveMultiScript()
		{
			using ( StreamWriter sw = new StreamWriter( m_Name + ".txt", false ) )
			{
				sw.WriteLine( "6 version" );
				sw.WriteLine( "1 template id" );
				sw.WriteLine( "-1 item version" );

				int count = 0;

				for ( int i = 0; i < Levels; ++i )
					for ( int x = 0; x < m_Width; ++x )
						for ( int y = 0; y < m_Height; ++y )
							count += m_Components[x][y][i].Count;

				sw.WriteLine( "{0} num components", count );

				for ( int i = 0; i < Levels; ++i )
				{
					for ( int x = 0; x < m_Width; ++x )
					{
						for ( int y = 0; y < m_Height; ++y )
						{
							ArrayList list = m_Components[x][y][i];

							foreach ( HouseComponent hc in list )
								sw.WriteLine( "{0} {1} {2} {3} 1", hc.Index, x, y, hc.Z );
						}
					}
				}
			}
		}

		public void SaveRunUOScript()
		{
			StringBuilder sb;

			using ( StreamReader ip = new StreamReader( "Internal/scriptbase.txt" ) )
				sb = new StringBuilder( ip.ReadToEnd() );

			bool firstLine = true;
			bool blankLine = false;

			StringBuilder components = new StringBuilder();

			ArrayList list = Compress();

			for ( int i = 0; i < list.Count; ++i )
			{
				BuildEntry entry = (BuildEntry)list[i];

				if ( entry.m_Width == 1 && entry.m_Height == 1 )
				{
					blankLine = false;
					if ( entry.m_Count == 1 )
						components.AppendFormat( "\r\n\t\t\tAddComponent( new AddonComponent( 0x{0:X4} ), {1}, {2}, {3} );", entry.m_Index, entry.m_X, entry.m_Y, entry.m_Z );
					else
						components.AppendFormat( "\r\n\t\t\tAddComponent( new AddonComponent( Utility.Random( 0x{0:X4}, {4} ) ), {1}, {2}, {3} );", entry.m_Index, entry.m_X, entry.m_Y, entry.m_Z, entry.m_Count );
				}
				else
				{
					if ( !firstLine && !blankLine )
						components.AppendFormat( "\r\n" );

					bool xLoop = ( entry.m_Width != 1 );
					bool yLoop = ( entry.m_Height != 1 );
					bool randomIndex = ( entry.m_Count != 1 );
					bool xOffset = ( entry.m_X != 0 );
					bool yOffset = ( entry.m_Y != 0 );

					if ( xLoop )
						components.AppendFormat( "\r\n\t\t\tfor ( int x = 0; x < {0}; ++x )", entry.m_Width );

					if ( yLoop )
					{
						if ( xLoop )
							components.AppendFormat( "\r\n\t\t\t\tfor ( int y = 0; y < {0}; ++y )", entry.m_Height );
						else
							components.AppendFormat( "\r\n\t\t\tfor ( int y = 0; y < {0}; ++y )", entry.m_Height );
					}

					string xString, yString;

					if ( !xLoop )
						xString = entry.m_X.ToString();
					else if ( !xOffset )
						xString = "x";
					else
						xString = String.Format( "{0} + x", entry.m_X );

					if ( !yLoop )
						yString = entry.m_Y.ToString();
					else if ( !yOffset )
						yString = "y";
					else
						yString = String.Format( "{0} + y", entry.m_Y );

					if ( randomIndex )
					{
						if ( xLoop && yLoop )
							components.AppendFormat( "\r\n\t\t\t\t\tAddComponent( new AddonComponent( Utility.Random( 0x{0:X4}, {4} ) ), {1}, {2}, {3} );", entry.m_Index, xString, yString, entry.m_Z, entry.m_Count );
						else
							components.AppendFormat( "\r\n\t\t\t\tAddComponent( new AddonComponent( Utility.Random( 0x{0:X4}, {4} ) ), {1}, {2}, {3} );", entry.m_Index, xString, yString, entry.m_Z, entry.m_Count );
					}
					else
					{
						if ( xLoop && yLoop )
							components.AppendFormat( "\r\n\t\t\t\t\tAddComponent( new AddonComponent( 0x{0:X4} ), {1}, {2}, {3} );", entry.m_Index, xString, yString, entry.m_Z );
						else
							components.AppendFormat( "\r\n\t\t\t\tAddComponent( new AddonComponent( 0x{0:X4} ), {1}, {2}, {3} );", entry.m_Index, xString, yString, entry.m_Z );
					}

					components.AppendFormat( "\r\n" );
					blankLine = true;
				}

				firstLine = false;
			}

			sb.Replace( "~NAME~", Name );
			sb.Replace( "~CLASSNAME~", Safe( Name ) );
			sb.Replace( "~COMPONENTS~", components.ToString() );

			using ( StreamWriter op = new StreamWriter( String.Format( "{0}.cs", Safe( Name ) ) ) )
				op.Write( sb.ToString() );
		}

		public string Safe( string ip )
		{
			ip = ip.Trim();

			if ( ip.Length == 0 )
				return "NoName";

			for ( int i = 0; i < ip.Length; ++i )
			{
				if ( !Char.IsLetterOrDigit( ip, i ) )
					ip = ip.Replace( ip[i].ToString(), "" );
			}

			if ( ip.Length == 0 )
				return "NoName";

			if ( !Char.IsLetter( ip, 0 ) )
				ip = "_" + ip;

			return ip;
		}

		public HouseDesign( string filePath )
		{
			m_FilePath = filePath;

			using ( BinaryReader bin = new BinaryReader( new FileStream( filePath, FileMode.Open, FileAccess.Read, FileShare.Read ) ) )
			{
				m_Name = bin.ReadString();
				m_Width = bin.ReadInt32();
				m_Height = bin.ReadInt32();
				m_UserWidth = bin.ReadInt32();
				m_UserHeight = bin.ReadInt32();

				Clear();

				int levels = bin.ReadInt16();
				int version = bin.ReadInt16();

				if ( version == 0 )
				{
					for ( int x = 0; x < m_Width; ++x )
					{
						for ( int y = 0; y < m_Height; ++y )
						{
							for ( int i = 0; i < levels; ++i )
							{
								int listCount = bin.ReadInt32();

								if ( i >= Levels )
								{
									bin.BaseStream.Seek( listCount * 8, SeekOrigin.Current );
								}
								else
								{
									ArrayList list = m_Components[x][y][i];

									for ( int j = 0; j < listCount; ++j )
									{
										int index = bin.ReadInt32();
										int z = bin.ReadInt32();

										int baseIndex, count;

										if ( GetBaseCount( TileSet.Toolbox, index, out baseIndex, out count ) )
											list.Add( new HouseComponent( index, z, baseIndex, count ) );
										else
											list.Add( new HouseComponent( index, z ) );
									}
								}
							}
						}
					}
				}
				else if ( version == 1 )
				{
					for ( int x = 0; x < m_Width; ++x )
					{
						for ( int y = 0; y < m_Height; ++y )
						{
							for ( int i = 0; i < levels; ++i )
							{
								int count = bin.ReadInt32();

								if ( i >= Levels )
								{
									bin.BaseStream.Seek( count * 8, SeekOrigin.Current );
								}
								else
								{
									ArrayList list = m_Components[x][y][i];

									for ( int j = 0; j < count; ++j )
										list.Add( new HouseComponent( bin.ReadInt16(), bin.ReadInt16(), bin.ReadInt16(), bin.ReadInt16() ) );
								}
							}
						}
					}
				}
				else if ( version == 2 )
				{
					int pairCount = ReadEnc7( bin );
					ArrayList pairs = new ArrayList( pairCount );

					for ( int i = 0; i < pairCount; ++i )
					{
						int num = ReadEnc7( bin );
						int index = num >> 1;
						int count = ((num & 1) == 0) ? 1 : ReadEnc7( bin );

						pairs.Add( new BuildEntry( 0, 0, 0, index, count, 0 ) );
					}

					int planeCount = ReadEnc7( bin );

					for ( int i = 0; i < planeCount; ++i )
					{
						int z = ReadEnc7( bin );
						int level = ReadEnc7( bin );
						int listCount = ReadEnc7( bin );

						int lastPos = 0;

						for ( int j = 0; j < listCount; ++j )
						{
							int num = ReadEnc7( bin );
							int index = num >> 2;
							int width = ((num & 1) == 0) ? 1 : ReadEnc7( bin );
							int height = ((num & 2) == 0) ? 1 : ReadEnc7( bin );

							lastPos += ReadEnc7( bin );

							int x = lastPos % m_Width;
							int y = lastPos / m_Width;

							BuildEntry pair = (BuildEntry)pairs[index];

							for ( int vx = x; vx < x + width; ++vx )
								for ( int vy = y; vy < y + height; ++vy )
									m_Components[vx][vy][level].Add( new HouseComponent( pair.m_Index + TileSetEntry.Random.Next( pair.m_Count ), z, pair.m_Index, pair.m_Count ) );
						}
					}
				}

				Sort();
			}
		}

		public void Save( string filePath )
		{
			m_FilePath = filePath;

			using ( BinaryWriter bin = new BinaryWriter( new FileStream( filePath, FileMode.Create, FileAccess.Write, FileShare.None ) ) )
			{
				bin.Write( m_Name );
				bin.Write( m_Width );
				bin.Write( m_Height );
				bin.Write( m_UserWidth );
				bin.Write( m_UserHeight );
				bin.Write( (short) Levels );

				bin.Write( (short) 2 );

				ArrayList list = Compress();

				list.Sort();

				ArrayList pairs = new ArrayList();

				for ( int i = 0; i < list.Count; ++i )
				{
					BuildEntry be = (BuildEntry)list[i];
					bool found = false;

					for ( int j = 0; !found && j < pairs.Count; ++j )
					{
						BuildEntry pair = (BuildEntry)pairs[j];

						if ( pair.m_Index == be.m_Index && pair.m_Count == be.m_Count )
						{
							be.m_PairIndex = j;
							found = true;
						}
					}

					if ( !found )
						be.m_PairIndex = pairs.Add( be );
				}

				WriteEnc7( bin, pairs.Count );

				for ( int i = 0; i < pairs.Count; ++i )
				{
					BuildEntry pair = (BuildEntry)pairs[i];

					int num = pair.m_Index;

					num <<= 1;

					if ( pair.m_Count != 1 )
						num |= 1;

					WriteEnc7( bin, num );

					if ( (num & 1) != 0 )
						WriteEnc7( bin, pair.m_Count );
				}

				ArrayList lists = new ArrayList();

				for ( int i = 0; i < list.Count; ++i )
				{
					int z = ((BuildEntry)list[i]).m_Z;
					int level = ((BuildEntry)list[i]).m_Level;
					Plane plane = null;

					for ( int j = 0; plane == null && j < lists.Count; ++j )
					{
						Plane t = (Plane)lists[j];

						if ( t.m_Z == z && t.m_Level == level )
							plane = t;
					}

					if ( plane == null )
						lists.Add( plane = new Plane( z, level ) );

					plane.m_List.Add( list[i] );
				}

				WriteEnc7( bin, lists.Count );

				for ( int i = 0; i < lists.Count; ++i )
				{
					Plane p = (Plane)lists[i];
					ArrayList plist = p.m_List;

					WriteEnc7( bin, p.m_Z );
					WriteEnc7( bin, p.m_Level );
					WriteEnc7( bin, plist.Count );

					int lastX = 0, lastY = 0;

					for ( int j = 0; j < plist.Count; ++j )
					{
						BuildEntry be = (BuildEntry)plist[j];

						int num = be.m_PairIndex;

						num <<= 2;

						if ( be.m_Width != 1 )
							num |= 1;

						if ( be.m_Height != 1 )
							num |= 2;

						WriteEnc7( bin, num );

						if ( (num & 1) != 0 )
							WriteEnc7( bin, be.m_Width );

						if ( (num & 2) != 0 )
							WriteEnc7( bin, be.m_Height );

						WriteEnc7( bin, ((be.m_Y * m_Width) + be.m_X) - ((lastY * m_Width) + lastX) );

						lastX = be.m_X;
						lastY = be.m_Y;
					}
				}
			}
		}

		private class Plane
		{
			public int m_Z;
			public int m_Level;
			public ArrayList m_List;

			public Plane( int z, int level )
			{
				m_Z = z;
				m_Level = level;
				m_List = new ArrayList();
			}
		}

		private static int ReadEnc7( BinaryReader bin )
		{
			int v = 0;
			int shift = 0;
			byte b;

			do
			{
				b = bin.ReadByte();
				v |= (b & 0x7F) << shift;
				shift += 7;
			} while ( b >= 0x80 );

			return v;
		}

		private static void WriteEnc7( BinaryWriter bin, int num )
		{
			uint v = (uint) num;

			while ( v >= 0x80 ) 
			{
				bin.Write( (byte) (v | 0x80) );
				v >>= 7;
			}

			bin.Write( (byte) v);
		}

		public void Sort()
		{
			for ( int x = 0; x < m_Width; ++x )
				for ( int y = 0; y < m_Height; ++y )
					for ( int i = 0; i < Levels; ++i )
						if ( m_Components[x][y][i].Count > 1 )
							m_Components[x][y][i].Sort();
		}

		public void Clear()
		{
			bool assign = ( m_Components == null );

			if ( assign )
				m_Components = new ArrayList[m_Width][][];

			for ( int x = 0; x < m_Width; ++x )
			{
				if ( assign )
					m_Components[x] = new ArrayList[m_Height][];

				for ( int y = 0; y < m_Height; ++y )
				{
					if ( assign )
						m_Components[x][y] = new ArrayList[Levels];

					for ( int i = 0; i < Levels; ++i )
					{
						if ( assign )
							m_Components[x][y][i] = new ArrayList();
						else
							m_Components[x][y][i].Clear();
					}
				}
			}
		}

		public void BuildFoundation()
		{
			AddComponent( 0, 0, 0, 0x66 );
			AddComponent( m_UserWidth - 1, m_UserHeight - 1, 0, 0x65 );

			for ( int x = 1; x < m_UserWidth; ++x )
			{
				AddComponent( x, m_UserHeight, 0, 0x751 );
				AddComponent( x, 0, 0, 0x63 );

				if ( x < m_UserWidth - 1 )
					AddComponent( x, m_UserHeight - 1, 0, 0x63 );
			}

			for ( int y = 1; y < m_UserHeight; ++y )
			{
				AddComponent( 0, y, 0, 0x64 );

				if ( y < m_UserHeight - 1 )
					AddComponent( m_UserWidth - 1, y, 0, 0x64 );
			}

			TileSetEntry te = new TileSetEntry( 0x31F4, 4 );

			for ( int x = 1; x < m_UserWidth; ++x )
				for ( int y = 1; y < m_UserHeight; ++y )
					AddComponent( x, y, LevelZ[1], 0, te.GetRandomIndex(), te.BaseIndex, te.Count );
		}

		public void AddComponent( int x, int y, int level, int index )
		{
			AddComponent( x, y, LevelZ[level], level, index );
		}

		public void AddComponent( int x, int y, int z, int level, int index )
		{
			AddComponent( x, y, z, level, index, index, 1 );
		}

		public void AddComponent( int x, int y, int z, int level, int index, int baseIndex, int count )
		{
			if ( x >= 0 && x < m_Width && y >= 0 && y < m_Height && level >= 0 && level < Levels )
			{
				ArrayList list = m_Components[x][y][level];

				HouseComponent nc = new HouseComponent( index, z, baseIndex, count );

				for ( int i = 0; i < list.Count; ++i )
				{
					HouseComponent hc = (HouseComponent)list[i];

					if ( hc.Z == z && hc.Height == 0 && nc.Height == 0 )
					{
						list[i] = nc;
						list.Sort();
						return;
					}
					else if ( hc.Z == z && hc.Height != 0 && nc.Height != 0 )
					{
						list[i] = nc;
						list.Sort();
						return;
					}
				}

				list.Add( nc );
				list.Sort();
			}
		}
	}

	public class BuildEntry : IComparable
	{
		public int m_X, m_Y, m_Width, m_Height, m_Z, m_Index, m_Count;
		public int m_PairIndex, m_Level;

		public BuildEntry( int x, int y, int z, int index, int count, int level )
		{
			m_X = x;
			m_Y = y;
			m_Width = 1;
			m_Height = 1;
			m_Z = z;
			m_Index = index;
			m_Count = count;
			m_Level = level;
		}

		public bool CombineWith( BuildEntry e )
		{
			if ( m_Level == e.m_Level && m_Z == e.m_Z && m_X == (e.m_X + e.m_Width) && m_Y == e.m_Y && m_Height == e.m_Height && m_Index == e.m_Index && e.m_Count == m_Count )
			{
				e.m_Width += m_Width;
				return true;
			}
			else if ( m_Level == e.m_Level && m_Z == e.m_Z && m_Y == (e.m_Y + e.m_Height) && m_X == e.m_X && m_Width == e.m_Width && m_Index == e.m_Index && e.m_Count == m_Count )
			{
				e.m_Height += m_Height;
				return true;
			}

			return false;
		}

		public void Send()
		{
			if ( m_Count == 1 )
				Client.SendText( "[TileRXYZ {0} {1} {2} {3} {4} Static {5}", m_X, m_Y, m_Width, m_Height, m_Z, m_Index );
			else
				Client.SendText( "[TileRXYZ {0} {1} {2} {3} {4} Static {5} {6}", m_X, m_Y, m_Width, m_Height, m_Z, m_Index, m_Count );
		}

		public void Append( StringBuilder sb )
		{
			if ( m_Count == 1 )
				sb.AppendFormat( "[TileRXYZ {0} {1} {2} {3} {4} Static {5}\r\n", m_X, m_Y, m_Width, m_Height, m_Z, m_Index );
			else
				sb.AppendFormat( "[TileRXYZ {0} {1} {2} {3} {4} Static {5} {6}\r\n", m_X, m_Y, m_Width, m_Height, m_Z, m_Index, m_Count );
		}

		public int CompareTo(object obj)
		{
			BuildEntry be = (BuildEntry)obj;

			if ( m_Y < be.m_Y )
				return -1;
			else if ( be.m_Y < m_Y )
				return 1;
			else if ( m_X < be.m_X )
				return -1;
			else if ( be.m_X < m_X )
				return 1;

			return 0;
		}
	}
}