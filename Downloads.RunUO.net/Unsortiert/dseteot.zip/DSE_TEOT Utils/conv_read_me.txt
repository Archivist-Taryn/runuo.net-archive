				converter

This program allow you to convert cfg from TEOT format to DSE_TEOT format.
