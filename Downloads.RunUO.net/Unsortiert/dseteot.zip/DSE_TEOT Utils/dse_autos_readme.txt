Launch client you want to use and search for signatures. It takes about 4 seconds on Athlon 2000XP, so be patient +). Replace all from edit boxes to new section of DSE_TEOT cfg file. Now, if you don't have exp. in asm u can try to launch client with different registers in SEND_LEN/SEND_BUF/RECV_LEN/RECV_BUF. Usually bufs r in edi/esi, because they r specialy for strings +)
Hehe, and don't try with esp! =)

0x00 - eax
0x01 - ecx
0x02 - edx
0x03 - ebx
0x04 - esp
0x05 - ebp
0x06 - esi
0x07 - edi

Uups, this program may not show correct address (for example recv addr in client-1.26.04a), so if u can find it in disasm don't use this program +)