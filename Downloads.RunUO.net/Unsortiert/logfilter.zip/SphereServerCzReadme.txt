SphereServer.Cz Readme
--------------------------------------------------------------------------
Tento soubor byl sta�en ze serveru www.sphereserver.cz
Majitel serveru neru�� za �kody vznikl� pou�it�m softwarem,
pop�. za jeho nefunk�nost, ani nenab�z� softwarovou
podporu pro dan� produkty.

V p��pad� probl�m� kontaktujte autora softwaru!

Klient pou��v� software na vlastn� riziko!

--------------------------------------------------------------------------
http://www.sphereserver.cz
sandal@sphereserver.cz
--------------------------------------------------------------------------
SphereServer.Cz Readme