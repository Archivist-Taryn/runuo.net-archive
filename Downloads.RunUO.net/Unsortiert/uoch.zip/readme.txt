By NecroPotence
dcavalcanti@bigfoot.com


The internal help of UOCH is in Portuguese, German and English


------------1st things 1st------------

Whatever you do with UOCH is your fault and responsability, not mine.
Whatever happens to you if someone caught you using a hacked client, it's your problem too.


Qualquer coisa que voce faca com o UOCH e sua culpa e responsabilidade, nao minha.
QUalquer coisa que aconteca se pegarem voce usando um cliente hackeado, e seu problema tambem.


***WARNING***
Only download UOCH if it comes from sourceforge, do not take it from other places/links!!!
Since it's source free, someone can just fake it and destroyer your PC. =P

Please don't use the No Name feature just to fuck up POL shards. (they aren't able to restart)


***AtENCAO***
Faca o download do UOCH apenas se vier da sourceforge, nao pegue de outros lugares/links!!!
Ja que o seu codigo fonte eh liberado, alguem pode simplesmente fingi-lo e destruir seu PC. =P

Por favor nao use a funcao de No Name apenas pra fuder com shards em POL. (elas nao conseguem 
reiniciar)


------------------------------------

------------How to run------------

To download original and safe uo clients:
http://www.oldsphere.com/sod/cl/cdindex.html

1 - Place a ORIGINAL client.exe in the same folder that UOCH is in
2 - Run UOCH
3 - Choose your client version in the combo box if you want Clear Nights
4 - After you crack all you want, a NPUOCH.exe will be created in the same folder that UOCH is in
5 - Just run NPUOCH and have a nice game. =)
5 - For further help, read the HELP inside the program (there is a button called HELP :P)



If you found any bugs, errors (errors, not warnings =P), or any questions, just email me.

------------------------------------




------------Como rodar------------

Para fazer o download de versoes originais e seguras do uo client:
http://www.oldsphere.com/sod/cl/cdindex.html

1 - Coloque um client.exe ORIGINAL na mesma pasta que UOCH
2 - Rode UOCH
3 - Escolha a versao do cliente.exe na combo box (a caixa com setinha) se voce quer Clear Nights
4 - Depois que voce crackear o client, uma arquivo NPUOCH.exe sera criado na mesma pasta que UOCH
5 - Rode NPUOCH and tenha um bom jogo. =)
6 - Para outras duvidas ou ajuda, leia o HELP dentro do programa (tem um botao escrito HELP :P)

Se voce achou algum problema, erro (erros, nao avisos =P), or qualquer duvida, me mande um email

------------------------------------
