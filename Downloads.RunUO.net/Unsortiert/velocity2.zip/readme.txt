--------------------------------------------------------------
------------------ Readme for Tavu's Velocity ----------------
-------------------- http://tgh.phazm.net --------------------
--------------------------------------------------------------
Introduction
	The main feature of Velocity is it's ability to remove
	all traces of lag in movement, acting as if you had a 
	ping time of 0 and through adjusting the settings you
	can reach the absolute maximum speed allowed on your
	server, even if you are a dialup user. This program is
	only recommended for dialup users and there are occasional
	problems while using this program.

---- Index ----
1) Instructions
	Descriptions on how to adjust your speed correctly to
	be at the exact maximum speed.

2) Information 
	Information regarding what the Delay, Speed Boost, 
	CSq, RSq, and Created/Received boxes are.

3) Credits
---------------

-------------------- Instructions ----------------------------
1) Instructions
	Here are some instructions on how to reach the absolute
	maximum speed allowed on your Ultima Online server.
	
	Log into uo with my program running and
	hit "Advanced". Set the 'Delay' box to 1 and
	the Speed Boost scroll bar to Maximum, farthest right.
	When you run in uo right now, you will probably
	experience rubber-banding. Rubber-banding is when
	your character keeps jumping suddenly back. Now,
	decrease the Speed Boost scroll bar by moving it
	farther to the left until you no longer experience
	this rubber-banding.

	If you are having problems with getting a consistent
	speed using the Speed Boost scroll bar, you can also
	increase the 'delay' box to a number in the range of
	20 to 110 to control your speed.

-------------------- Information ----------------------------
2) Information
	a) Delay Box
		This is the delay between when you move and
		when my program sends the confirm move
		information in 1/100 of a second. Advanced
		users can use this box to help configure
		their optimal speed.
	b) Speed Boost Scroll Bar
		This is my original adrenaline speed boost
		which increases your speed in game. The
		farther it is to the right, the faster
		you will move in game.
	c) CSq and RSq Boxes
		The CSq is the list of move information
		that my program has created, and RSq is
		the list of received move informations.
		Advanced users can look at this to
		determine how far ahead of their information
		they are.
	d) Created/Received Box
		When an incoming move information does
		not agree with the expected move
		information, it is put in this dialog.
		This information can be used by
		advanced users to determine whether
		a resync is required.

-------------------- Credits ----------------------------
3) Credits

Wepage: http://tgh.phazm.net/

Author: Tavu

Testers:
redrum
Mystic Llama
Lithanual

		
