#pragma once

void CleanupGame();
