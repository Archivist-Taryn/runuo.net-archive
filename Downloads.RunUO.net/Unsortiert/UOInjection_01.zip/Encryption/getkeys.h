#pragma once
extern int LoginSeed;
void CalculateKeys(BYTE Plaintext[62],BYTE Ciphertext[62]);
extern unsigned ClientLoginKey1;
extern unsigned ClientLoginKey2;
