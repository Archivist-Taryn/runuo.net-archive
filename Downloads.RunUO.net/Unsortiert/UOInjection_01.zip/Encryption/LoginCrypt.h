#pragma once

extern unsigned int LoginKey1;
extern unsigned int LoginKey2;

void CleanupLogin();
