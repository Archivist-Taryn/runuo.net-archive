Turn off precompiled headers for *.c files
