//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UOInjection.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_UOINJECTION_DIALOG          102
#define IDS_VERSION                     102
#define IDS_LAUNCH                      103
#define IDS_NEW                         104
#define IDS_EDIT                        105
#define IDS_DELETE                      106
#define IDS_ADVANCED                    107
#define IDS_EXIT                        108
#define IDS_CHECK_FOR_UPDATES_NOW       109
#define IDS_CLIENT_LABEL                110
#define IDS_ADDRESS_LABEL               111
#define IDS_ALT_DATA_DIR_LABEL          112
#define IDS_LAUNCH_UOAM_LABEL           113
#define IDS_USE_INJECTION_LABEL         114
#define IDS_CLIENT_EMULATION_LABEL      115
#define IDS_VERSION_LABEL               116
#define IDS_CHECK_FOR_UPDATE_ON_RUN_LABEL 117
#define IDS_CLOSE                       118
#define IDS_OK                          119
#define IDS_CANCEL                      120
#define IDR_MAINFRAME                   128
#define IDD_EDITSERVERDLG_DIALOG        132
#define IDD_ADVANCE_SETTINGS_DIALOG     134
#define IDD_EDIT_ADDRESS_DIALOG         135
#define IDD_LAUNCH_PROGRESS_DIALOG      136
#define IDD_PLUGINS_DIALOG              138
#define IDC_SERVERS_LIST                1000
#define IDC_EDIT_BUTTON                 1001
#define IDC_NEW_BUTTON                  1002
#define IDC_DELETE_BUTTON               1003
#define IDC_CHECK_FOR_UPDATES_CHECK     1006
#define IDC_CHECK_FOR_UPDATE_BUTTON     1007
#define IDC_ADDRESS_STATIC              1008
#define IDC_ALT_DATA_DIR_STATIC         1009
#define IDC_LAUNCH_UOAM_STATIC          1010
#define IDC_USE_INJECTION_STATIC        1011
#define IDC_CLIENT_EMULATION_STATIC     1012
#define IDC_VERSION_STATIC              1013
#define IDC_NAME_EDIT                   1014
#define IDC_CLIENT_EDIT                 1015
#define IDC_GET_CLIENT_BUTTON           1016
#define IDC_ADDRESSES_LIST              1019
#define IDC_NEW_ADDRESS_BUTTON          1020
#define IDC_EDIT_ADDRESS_BUTTON         1021
#define IDC_DELETE_ADDRESS_BUTTON       1022
#define IDC_USE_ALT_DIR_CHECK           1023
#define IDC_ALT_DATA_DIR_EDIT           1024
#define IDC_ALT_DATA_DIR_BUTTON         1025
#define IDC_LAUNCH_UOAM_CHECK           1026
#define IDC_REMEMBER_USERNAME_CHECK     1027
#define IDC_USERNAME_EDIT               1028
#define IDC_REMEMBER_PASSWORD_CHECK     1029
#define IDC_PASSWORD_EDIT               1030
#define IDC_USE_INJECTION_CHECK         1031
#define IDC_CLIENT_EMULATION_COMBO      1032
#define IDC_FIX_WALK_CHECK              1033
#define IDC_FIX_TALK_CHECK              1034
#define IDC_ADVANCE_BUTTON              1034
#define IDC_INSTALL_DIR_EDIT            1035
#define IDC_PATCHFILE_EDIT              1036
#define IDC_INJECTIONDIR_EDIT           1036
#define IDC_KEYFILE_EDIT                1037
#define IDC_PLUGIN_DIR_EDIT             1038
#define IDC_SCRIPT_DIR_EDIT             1039
#define IDC_INSTALL_DIR_BUTTON          1040
#define IDC_PATCHFILE_BUTTON            1041
#define IDC_ADDRESS_EDIT                1041
#define IDC_KEYFILE_BUTTON              1042
#define IDC_PORT_EDIT                   1042
#define IDC_PLUGIN_DIR_BUTTON           1043
#define IDC_LOGIN_FILE_EDIT             1043
#define IDC_SCRIPT_DIR_BUTTON           1044
#define IDC_CLIENT_STATIC               1044
#define IDC_LAUNCH_LOG_EDIT             1045
#define IDC_PLUGINS                     1053
#define IDC_PLUGINS_LIST                1054
#define IDC_ADD_BUTTON                  1055
#define IDC_REMOVE_BUTTON               1056
#define IDC_STATIC_PHASE1               1064
#define IDC_STATIC_PHASE2               1065
#define IDC_STATIC_PHASE3               1066
#define IDC_STATIC_PHASE4               1067
#define IDC_STATIC_PHASE5               1068
#define IDC_STATIC_STATE1               1069
#define IDC_STATIC_STATE2               1070
#define IDC_STATIC_STATE3               1071
#define IDC_STATIC_STATE4               1072
#define IDC_STATIC_STATE5               1073
#define IDC_BUTTON1                     1074

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
