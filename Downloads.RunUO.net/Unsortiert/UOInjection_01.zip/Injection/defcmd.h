#pragma once

extern DWORD CharacterSerial;	// char serial No
void InitWorld();
void DeleteWorld();
