//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Injection.rc
//
#define IDP_SOCKETS_INIT_FAILED         101
#define IDD_MAIN_TAB                    106
#define IDD_DISPLAY_TAB                 107
#define IDD_ITEMS_TAB                   108
#define IDD_OBJECT_TYPES_TAB            109
#define IDC_BUTTON1                     1000
#define IDS_ERROR                       1001
#define IDC_BUTTON2                     1001
#define IDS_PATCHFAILED                 1002
#define IDI_MAINICON                    1002
#define IDS_NOENCRYPTIONPLUGIN          1003
#define IDC_CHECK2                      1003
#define IDC_CHECK3                      1004
#define IDC_CHECK4                      1005
#define IDC_CHECK5                      1006
#define IDC_CHECK6                      1007
#define IDC_CHECK1                      1010
#define IDC_CHECK7                      1011
#define IDC_CHECK8                      1012
#define IDC_CHECK9                      1013
#define IDC_CHECK10                     1014
#define IDC_CHECK11                     1015
#define IDC_CHECK12                     1016
#define IDC_CHECK13                     1017
#define IDC_CHECK14                     1018
#define IDC_CHECK15                     1019
#define IDC_CHECK16                     1020
#define IDC_CHECK17                     1021
#define IDC_CHECK18                     1022
#define IDC_CHECK19                     1023
#define IDC_CHECK20                     1024
#define IDC_CHECK21                     1025
#define IDC_CHECK22                     1026
#define IDC_CHECK23                     1027
#define IDC_CHECK24                     1028
#define IDC_CHECK25                     1029
#define IDC_CHECK26                     1030
#define IDC_FROMTARGET                  1032
#define IDC_FROMTARGETIDC_FROMTARGET    1032
#define IDC_TABCONTROL                  10000
#define IDC_EDITCONTROL                 10001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1004
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           1002
#endif
#endif
