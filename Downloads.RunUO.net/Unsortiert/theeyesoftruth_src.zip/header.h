/*
By Ilichev Roman 2004(C)
e-mail:roman3k@mail.ru
web:mudator.by.ru
icq:166321817
*/

#if !defined(TEOT_HEADER)
#define TEOT_HEADER

#include <windows.h>
#include <winsock2.h>
#include <stdio.h>
#include <string.h>

/*Player varible*/
unsigned int	MobSerial;
unsigned int 	MobBPUID;
unsigned char	FakePacket[2] = {0x73, 0x01};
unsigned char   MobName[30];
/*Windows hadles and id and buffers*/
unsigned int		ProcessID          			= 0;
HANDLE          	ProcessHandle          		= 0;
HANDLE          	ThreadHandle        		= 0;

/*Target hack*/
unsigned int TargetFunc			= 0;
unsigned int TargetEnable			= 0;
unsigned int TargetFuncAddr 		= 0;
typedef int UOTargetCallBack (unsigned int uid);
UOTargetCallBack *TargetCallBack = 0;

/*Client packet handle varible*/
unsigned char		SendOld        	= 0;
unsigned char     	RecvOld        	= 0;
unsigned int      	SendAdress     	= 0;
unsigned int       	RecvAdress     	= 0;
unsigned char      	SendRegLen    	= 0;
unsigned char      	RecvRegLen     	= 0;
unsigned char      	SendRegBuf    	= 0;
unsigned char      	RecvRegBuf     	= 0;
unsigned int       	ProcessReg       [7];

/*Debug varibles*/
unsigned char           BreakCode      	= 0xCC;
unsigned int           	BreakAddress   	= 0;
DEBUG_EVENT     		DebugEvent;
CONTEXT         		ProcessContext;

/*Other*/
unsigned int           	TimeStamp       	= 0;
unsigned int           	PacketLen           = 0;
unsigned int           	PacketBuff         	= 0;
unsigned char         	TempData            [512];
unsigned char           *BackBuffer     	= 0;
/*Cheat triggers*/
int 					BankHack				= 0;
int 					GetCharStats			= 0;
unsigned int 			ObjectToDye				= 0;
int 					DyeHack					= 0;
/*function's*/
void _FatalError(char *text)
{
	printf(text);
	system("pause");
	ExitProcess(0);
}

void ReadClientMemory(void *from_addr, void *in, int size)
{
	ReadProcessMemory	(
							ProcessHandle,
							from_addr,
							in,
							size,
							(unsigned int*)0
						);
	return;
}

void WriteClientMemory(void *to_addr, void *in, int size)
{
	WriteProcessMemory(	ProcessHandle,
						(void *)to_addr,
						in,
						size,
						(unsigned int*)0
					);
}

inline void pack_big_uint32(unsigned char * buf, unsigned int x)
{
    buf[0] = (unsigned char)(x >> 24);
    buf[1] = (unsigned char)((x >> 16) & 0xff);
    buf[2] = (unsigned char)((x >> 8) & 0xff);
    buf[3] = (unsigned char)(x & 0xff);
}

inline unsigned int unpack_big_uint32(unsigned char * buf)
{
    return (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3];
}

inline unsigned short unpack_big_uint16(unsigned char * buf)
{
    return (buf[0] << 8) | buf[1];
}

void ShowTarget(void *func)
{
	char enable=0x01;
	WriteClientMemory((void*)TargetEnable, &enable, 1);
	TargetCallBack=(UOTargetCallBack*)func;
	return;
}

void UpdateBackBuffer(void *what, int len)
{
	WriteProcessMemory(	ProcessHandle,
						(void *)(BackBuffer),
						what,
						len,
						(unsigned int*)0
					);
	if(BreakAddress==SendAdress)
	{
		ProcessReg[SendRegLen]=(unsigned int)len;
		ProcessReg[SendRegBuf]=(unsigned int)BackBuffer;
	}
	else if(BreakAddress==RecvAdress)
	{
		ProcessReg[RecvRegLen]=(unsigned int)len;
		ProcessReg[RecvRegBuf]=(unsigned int)BackBuffer;
	}
}

int ParseWorldInfo(FILE *cfg, char *what, char *hack)
{
	char line[0x100];
	int insection = 0;
	int sn = 0;
	if(!cfg)
		{
			printf("Config is missing.\n");
			return 0;
		}
	while(fgets(line, sizeof(line), cfg))
   	{
		 if((!insection) && strstr(line, what))
         {
			insection = 1;
			continue;
		 }
		 if(insection && strchr(line, '{'))
      	 	continue;
		 if(insection && strchr(line, '}'))
      	 {
		    return sn;
         }
		 if(insection)
		 {
			char *c = line;
			while((*c!='@')&&*++c)
				;
			if(*c)
			{
				if(strstr(c, "@MOB_UID"))
					sprintf(c, "0%x\n\0", MobSerial);
				else if(strstr(c, "@MOB_BP_UID"))
					sprintf(c, "0%x\n\0", MobBPUID);
			}
			int n = strlen(line);
			strcpy(&hack[sn], line);
			sn+=n;
		 }
	}
	return 0;
}

void ClientTalk(int color, unsigned char type, const char *zText)
{

		char Buff[0x400];
		strcpy(Buff, zText);
		WCHAR Text[0x400];
		int StrLen=strlen(Buff);
		MultiByteToWideChar(1251,0,Buff,StrLen,Text,1024);
		for(int i=0; i<StrLen; i++)
			Text[i]=htons(Text[i]);
		Buff[0]=(char)0xad;
		Buff[1]=(StrLen*2+14)/256;
		Buff[2]=(StrLen*2+14)%256;
		Buff[3]=(char)type;
		Buff[4]=color/256;
		Buff[5]=color%256;
		Buff[6]=0;
		Buff[7]=3;
		strcpy(Buff+8,"RUS");
		memcpy(Buff+12,Text,StrLen*2);
		Buff[StrLen*2+12]=0;
		Buff[StrLen*2+13]=0;
		UpdateBackBuffer(Buff,StrLen*2+14);
		return;
}

int HackBook1(unsigned int uid) //Hack with book write in world my logo
{
	unsigned char buf[0x400];
	*buf=0x66;
	pack_big_uint32(&buf[3], uid);
	/*parse the file*/
	FILE *cfg = fopen("./teot.scp", "r");
	char *text = malloc(0x200);
	int n = ParseWorldInfo(cfg, "HACK_BOOK", text);
	if(!n&&(n>255))
	{
		printf("Config section error.\n");
		return 0;
	}
	fclose(cfg);
	/*end*/
	n = strlen(text);
	strcpy(&buf[13], text);
	free(text);
	++n;
	int p_len = (13 + n);
	buf[1] = (p_len/256);
	buf[2] = (p_len%256);
	buf[7] = 0x00; buf[8] = 0x01; //total page's
	buf[9] = 0x00; buf[10] = 0x01; //page index from 1
	buf[11] = 0x00; buf[12] = 0x01; //line's on page
	UpdateBackBuffer(buf, p_len);
	return 1;
}


int HackBB1(unsigned int uid) // Hack with BB write in world my logo
{
	char buf[0x400];
	char bb_title[0x100];
    char bb_text[0x100];
	memset(buf, 0x00, 0x400);
	strcpy(bb_title, "Hello World");
    unsigned char bb_title_len = strlen(bb_title);
	++bb_title_len;

	/*parse the file*/
	FILE *cfg = fopen("./teot.scp", "r");
	char *text = malloc(0x200);
	int n = ParseWorldInfo(cfg, "HACK_BB", text);
	if(!n&&(n>255))
	{
		printf("Config section error.\n");
		return 0;
	}
	fclose(cfg);
	/*end*/
	strcpy(bb_text, text);
	free(text);
	unsigned short bb_text_len = strlen(bb_text);
	++bb_text_len;
	*buf = 0x71;
	int p_len = (15 + bb_text_len + bb_title_len);
	buf[1] = (p_len/256);
	buf[2] = (p_len%256);
	buf[3] = 0x05; /*Post message type*/
	pack_big_uint32(&buf[4], uid);
	buf[12] = bb_title_len;
	strcpy(&buf[13], bb_title);
    buf[13+bb_title_len] = 0x01; /*line's in message*/
	buf[13+bb_title_len+1] = bb_text_len;
	strcpy(&buf[13+bb_title_len+2], bb_text);
	UpdateBackBuffer(buf, p_len);
	return 1;
}
int RequestCharStats(unsigned int uid) //try to get char stats
{
	unsigned char p[]={0x34 ,0xed ,0xed ,0xed ,0xed ,0x04 ,0x00 ,0x00, 0x8c, 0xd9};
	pack_big_uint32(&p[6], uid);
	UpdateBackBuffer(p, 10);
	return 1;
}

int DyeHackFunc(unsigned int uid) //dye cheat .. dye anything what you want
{
	ObjectToDye = uid;
	DyeHack = 1;
	printf("Use dye's on dye tub and select color\n");
	return 0;
}

int RenameMob(unsigned int uid) //rename cheat
{
	unsigned char p[0x23];
	*p=0x75;
	pack_big_uint32(&p[1], uid);
	for(int i=0;i<30;i++)
	{
		if(MobName[i]=='$')
			MobName[i]=0x0A;
	}
	strcpy(&p[5], MobName);
	UpdateBackBuffer(p, 0x23);
	return 1;
}

int SetTag(unsigned int uid) //set tag value
{
	if(strstr(MobName, "@MOB_UID"))
		MobSerial = uid;
	else if(strstr(MobName, "@MOB_BP_UID"))
		MobBPUID = uid;
	printf("Tag '%s' is '0%x'\n", MobName, uid);
	return 0;
}

int AttackMob(unsigned int uid) //atack mob
{
	unsigned char p[0x05];
	*p=0x05;
	pack_big_uint32(&p[1], uid);
	UpdateBackBuffer(p, 0x05);
	return 1;
}

int ExecCmd(char *cmd, char *param)
{
	if (!stricmp(cmd, "#ress"))
    {
        unsigned char p[]={0x2c, 0x01};
        UpdateBackBuffer(p, 0x02);
        printf("Resurrection cheat!\n");
        return 1;
    }
	else if(!stricmp(cmd, "#godyell"))
	{
		if(param)
			ClientTalk(0x22, 0xFF, param);
		printf("Godyell cheat!\n");
		return 1;
	}
	else if(!stricmp(cmd, "#crash"))
	{
		if(param)
			ClientTalk(0x6D60, 0x00, param);
		else
			ClientTalk(0x6D60, 0x00, "Fallout");
		printf("Crash cheat!\n");
		return 1;
	}
	else if(!stricmp(cmd, "#charstats"))
	{
		GetCharStats = 1;
		ShowTarget(RequestCharStats);
		return 0;
	}
	else if(!stricmp(cmd, "#hackbook"))
	{
		ShowTarget(HackBook1);
		return 0;
	}
	else if(!stricmp(cmd, "#hackbb"))
	{
		ShowTarget(HackBB1);
		return 0;
	}
	else if(!stricmp(cmd, "#rename"))
	{
		ShowTarget(RenameMob);
		if(param)
			strcpy(MobName, param);
		else
			strcpy(MobName, "Fallout");
		return 0;
	}
	else if(!stricmp(cmd, "#xinfo"))
	{
		ShowTarget(SetTag);
		if(param)
			strcpy(MobName, param);
		else
			strcpy(MobName, "info about object");
		return 0;
	}
	else if(!stricmp(cmd, "#attack"))
	{
		ShowTarget(AttackMob);
		return 0;
	}
	else if(!stricmp(cmd, "#dye"))
	{
		ShowTarget(DyeHackFunc);
		return 0;
	}
	else if(!stricmp(cmd, "#bankhack"))
	{
		printf("Wait for bank...\n");
		BankHack = 1;
		return 0;
	}
	return 0;
}

int ParseCmd(char *Packet, int Len, int IsUni)
{
	char tmpBuf[0x100];
	memset(tmpBuf, 0x00, 0x100);
	if(IsUni)
	{
		int n=0;
		int nLen=Len<<1;
		for(int i=1;i<nLen;i++)
		{
			char c=Packet[i];
			if(isprint(c))
				tmpBuf[n++]=c;
		}
	}
	else
		memcpy(tmpBuf, Packet, Len);
	char* param = strchr(tmpBuf, ' ');
	if(param)
		*param++='\0';
	return ExecCmd(tmpBuf, param);
}

void PacketHandle(unsigned char *Packet, int Len, int Where)
{

	if (Where==SendAdress)
	{
		switch(Packet[0])
		{
			case 0x03:
			{
				if (Packet[8] == '#'){
					int Len=(((Packet[1] << 8) + Packet[2])-8);
               		if(!ParseCmd((char*)&Packet[8], Len, 0))
                	{
						UpdateBackBuffer(FakePacket, 0x02);
                	}
				}
				break;
			}
			case 0xad:
			{
				if (Packet[13] == '#'){
					int Len=(((Packet[1] << 8) + Packet[2])-12)>>1;
                	if(!ParseCmd((char*)&Packet[12], Len, 1))
					{
                		UpdateBackBuffer(FakePacket, 0x02);
                	}
				}
				break;
			}
			case 0x95:
			{
				if(DyeHack){
					DyeHack = 0;
					pack_big_uint32(&Packet[1], ObjectToDye);
					UpdateBackBuffer(Packet, 0x09);
					printf("Object '0x%X' was dyed.\n", ObjectToDye);
				}
				break;
			}
			case 0x6c:
			{
				if(TargetCallBack)
				{
					if(!TargetCallBack(unpack_big_uint32(&Packet[7])))
						UpdateBackBuffer(FakePacket, 0x02);
					TargetCallBack=0;
				}
				break;
			}
			default:
				break;
		}
	}
	else
	{
		switch(Packet[0])
		{
			case 0x33: //fast death
				{
					unsigned char p[]={0x33, 0x00};
					UpdateBackBuffer(p, 0x02);
					break;
				}
			case 0x4f: //always light
				{
					unsigned char p[]={0x4f, 0x00};
					UpdateBackBuffer(p, 0x02);
					break;
				}
			case 0x65: //always clear
				{
					unsigned char p[]={0x65, 0xFF, 0x00, 0x00};
					UpdateBackBuffer(p, 0x04);
					break;
				}
			case 0x2c: //remove death screen
				{
					unsigned char p[]={0x2c, 0x01};
					UpdateBackBuffer(p, 0x02);
					break;
				}
			case 0x20:
				{
					Packet[6]=0x90;
					UpdateBackBuffer(Packet, Len);
					break;
				}
			case 0x11:
				{
					if(!GetCharStats) //Stop flood in console +)
						break;
					unsigned short hits = unpack_big_uint16(&Packet[37]);
					unsigned short max_hits = unpack_big_uint16(&Packet[39]);
					char *name = &Packet[7];

					if(max_hits!=100)
						{
							printf("%s has %d/%d hitpoint's.\n", name, hits, max_hits);
						}
					else
						{
							//For protected shard's but not for all
							unsigned short perc_hits = (hits*100/max_hits);
							printf("%s has %d hitpoint's\n", name, perc_hits);
						}
					GetCharStats = 0;

					break;
				}
			case 0x1b:
				{
					MobSerial = unpack_big_uint32(&Packet[1]);
					break;
				}
			case 0x2e:
				{
					if(BankHack)
					{
						unsigned short layer = Packet[8];
						if(layer!=29)
							break;
						printf("Bank with uid '0x%X' hacked.\n", unpack_big_uint32(&Packet[1]));
						Packet[8]=0x0f;
						UpdateBackBuffer(Packet, 15);
						BankHack=0;
					}
					break;
				}
			default:
				break;
		}
	}

}

unsigned int CfgReadInt(FILE *cfg, char *name, unsigned int timestamp)
{
   char line[200];
   char *found;
   char time[20];
   int insection=0, findstamp=0;
   unsigned int result=0;

   sprintf(time, "CLIENT 0x%X", timestamp);
   rewind(cfg);
   while(fgets(line, sizeof(line), cfg))
   {
      if(strstr(line, time))
         findstamp=1;
      if(findstamp && strchr(line, '{'))
         insection=1;
      if(insection && (found=strstr(line, name)))
      {
         int num=0;
         if(!strchr(found, '='))
            continue;
         found=strchr(line, '=')+1;
         if(strstr(found, "0x"))
            num=sscanf(found, "%X", &result);
         else
            num=sscanf(found, "%lu", &result);
         if(num==1)
            return result;
      }
      if(insection && strchr(line, '}'))
      {
         insection=0; findstamp=0;
      }
   }
   return 0;
}

void CfgReadString(FILE *cfg, char *name, char *dest, unsigned int timestamp)
{
   char line[200];
   char result[100];
   char *found;
   char time[20];
   int insection=0, findstamp=0;

   sprintf(time, "CLIENT 0x%X", timestamp);
   rewind(cfg);
   while(fgets(line, sizeof(line), cfg))
   {
      if(strstr(line, time))
         findstamp=1;
      if(findstamp && strchr(line, '{'))
         insection=1;
      if(insection && (found=strstr(line, name)))
      {
         int i=0;
         if(!strchr(found, '='))
            continue;
         found=strchr(line, '"')+1;
         while(found[i++]!='"') result[i-1]=found[i-1];
         result[i-1]='\0';
         strcpy(dest, result);
         return;
      }
      if(insection && strchr(line, '}'))
      {
         insection=0; findstamp=0;
      }
   }
   return;
}

#endif

