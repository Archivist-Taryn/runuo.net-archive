/*
By Ilichev Roman 2004(C)
e-mail:roman3k@mail.ru
web:mudator.by.ru
icq:166321817
*/

#include "header.h"


void main(void)
{
	SetConsoleTitle("The Eyes Of Truth [REVENGE] by Ilichev Roman");
	HWND UoWindow = FindWindow("Ultima Online", 0);
	if(!UoWindow)
		_FatalError("|->Can't find UO window.\n");
	GetWindowThreadProcessId(
								UoWindow,
								&ProcessID
							);
	if(!ProcessID)
		_FatalError("|->Cant's get process id.\n");
	ProcessHandle = OpenProcess(
									PROCESS_ALL_ACCESS,
									0,
									ProcessID
								);
	if(!ProcessHandle)
		_FatalError("|->Can't get process handle.\n");
	ReadClientMemory ((void *)(0x40003C), &TimeStamp, 4);
    ReadClientMemory ((void *)(0x400000 | (TimeStamp + 8)), &TimeStamp, 4);
  	/*Try to ident UO client*/
	FILE *cfg = fopen("./config.scp", "r");
	if(!cfg)
		_FatalError("|->Can't open config file\n");
	char cs[30] = {0x00};
	CfgReadString(cfg, "CLIENT_NAME", cs, TimeStamp);
	if(!strlen(cs)){
		fclose(cfg);
		_FatalError("|->Can't ident UO client type.\n");
	}
	/*Like Folko +)*/
	SendAdress		=	CfgReadInt(cfg, "SEND_HOOK", TimeStamp);
    RecvAdress 		= 	CfgReadInt(cfg, "RECV_HOOK", TimeStamp);
    SendRegBuf    	= 	CfgReadInt(cfg, "SEND_BUF", TimeStamp);
    SendRegLen    	= 	CfgReadInt(cfg, "SEND_LEN", TimeStamp);
    RecvRegBuf    	= 	CfgReadInt(cfg, "RECV_BUF", TimeStamp);
    RecvRegLen    	= 	CfgReadInt(cfg, "RECV_LEN", TimeStamp);
	TargetFunc 		=	CfgReadInt(cfg, "TARGET_FUNC", TimeStamp);
	TargetFuncAddr 	= 	CfgReadInt(cfg, "TARGET_ADDR", TimeStamp);
	TargetEnable 	= 	CfgReadInt(cfg, "TARGET_SHOW", TimeStamp);

	fclose(cfg);

	printf("Found %s uo client version\n", cs);

	BackBuffer = (unsigned char *)VirtualAllocEx(
													ProcessHandle,
													0,
													0xFFFF,
                                     				MEM_COMMIT,
													PAGE_READWRITE
												);
	if (!BackBuffer)
		_FatalError("|->Cant's allocate memory in process.\n");
	int IsDebug = DebugActiveProcess(ProcessID);
	if (!IsDebug)
		_FatalError("|->Cant's debug active process.\n");

	/*new Write target hack*/
	WriteClientMemory((void*)TargetFunc, &TargetFuncAddr, 4);

	ReadClientMemory((void *)SendAdress, &SendOld, 1);
    WriteClientMemory((void *)SendAdress, &BreakCode, 1);

    ReadClientMemory((void *)RecvAdress, &RecvOld,1);
    WriteClientMemory((void *)RecvAdress, &BreakCode, 1);

	/*Debug loop*/
	printf("Good game and good cheat's =)\n");
	while(1)
            {
                if(WaitForDebugEvent(&DebugEvent, INFINITE))
                {
                    if (DebugEvent.dwDebugEventCode==EXCEPTION_DEBUG_EVENT)
                    {
                        if (DebugEvent.u.Exception.ExceptionRecord.ExceptionCode==EXCEPTION_BREAKPOINT)
                        {
                            BreakAddress = (DWORD)DebugEvent.u.Exception.ExceptionRecord.ExceptionAddress;
                            if((BreakAddress==SendAdress)||(BreakAddress==RecvAdress))
                            {
                                ThreadHandle = OpenThread(	THREAD_GET_CONTEXT |
														 	THREAD_SET_CONTEXT,
                                    						0, DebugEvent.dwThreadId );
                                ProcessContext.ContextFlags=CONTEXT_FULL;
                                GetThreadContext(ThreadHandle, &ProcessContext);
                                memcpy(ProcessReg, &ProcessContext.Edi, 28);
                                PacketLen=ProcessReg[((BreakAddress==SendAdress)?
							   						 	SendRegLen : RecvRegLen)];
                                PacketLen=(PacketLen & 0xFF);
                                PacketBuff=ProcessReg[(BreakAddress==SendAdress)?
														SendRegBuf : RecvRegBuf];
                                ReadClientMemory((void *)PacketBuff, TempData, PacketLen);
                                PacketHandle(TempData, PacketLen, BreakAddress);
                                memcpy(&ProcessContext.Edi, ProcessReg, 28);
                                WriteProcessMemory(ProcessHandle, (void *)BreakAddress,
                                    (BreakAddress==SendAdress)? &SendOld : &RecvOld, 1, (unsigned int*)0);
                                ProcessContext.Eip--;
                                ProcessContext.EFlags |= 0x100;
                                SetThreadContext( ThreadHandle, &ProcessContext);
                                ContinueDebugEvent(DebugEvent.dwProcessId,
								DebugEvent.dwThreadId, DBG_CONTINUE);
                                continue;
                            }

                        }
                        if (DebugEvent.u.Exception.ExceptionRecord.ExceptionCode==EXCEPTION_SINGLE_STEP)
                        {
                            WriteProcessMemory(ProcessHandle, (void *)BreakAddress, &BreakCode, 1, (unsigned int*)0);
                            GetThreadContext( ThreadHandle, &ProcessContext);
                            ProcessContext.EFlags &= ~0x100;
                            SetThreadContext( ThreadHandle, &ProcessContext);
                            CloseHandle(ThreadHandle);
                        }

                    }
                    else if(DebugEvent.dwDebugEventCode==EXIT_PROCESS_DEBUG_EVENT)
                    {
						_FatalError("|->Client is terminated..\n");
                	}
					ContinueDebugEvent(DebugEvent.dwProcessId, DebugEvent.dwThreadId, DBG_CONTINUE);
            	}
			}
	return;
}
