/* Weditres generated include file. Do NOT edit */
#define	IDICON52	52
#define	IDICON53	53
#define	IDA	102
#define	IDH	103
#define	IDC	104
#define	IDPC	105
#define	IDADCDT	106
#define	IDBH	107
#define	IDAL	108
#define	IDAC	109
#define	IDD_MAINDIALOG	200
