/*
	Project code name is - DSE
	DSE => " Detpyrc Si Eman " => reverse => " Name Is Crypted " %)))

	18.12.2004, 4:26 - currently supports only 203 client... and handles only client packets +)) ss...
	18.12.2004, 16:15 - now can handle received packets.. packet logger added
	19.12.2004, 0:19 - some bug fixes and new recv hack
	19.12.2004, 18:12 - auto search of addresses of send & recv functions added
	20.12.2004, 3:20 - SearchFuncAddrInIAT function added
	21.12.2004, 16:18 - hacks location is now 0x400500-FFF
	21.12.2004, 19:02 - officialy support of 2.0.3, 2.0.0.e, 1.26.04.b clients (all clients what i have +))
	23.12.2004, 00:17 - auto search moved to a seperate project. addr.cfg file created.
	24.12.2004, 18:15 - all hacks completely recoded +) ... added all TEOT cheats (except private hacks)
	25.12.2004,	15:20 - changed cfg file format, added list box functions (from my old text-game project)
	26.12.2004, 0:32 - hacks now modify reg with packet len (!), all founded bugs are fixed (mostly in cheats)
	27.12.2004, 13:34 - check for UO client every 10 ms (auto-detaching if not found), detaching now works properly
	28.12.2004, 23:58 - program adds icon to the taskbar when minimized, icon added
	29.12.2004, 21:11 - added new hook for allocating virtual memory in UO client (for support with 9x)
	29.12.2004, 23:27 - added BackBuffer (heh, i'm forgot about it)
	30.12.2004, 00:25 - first public release

	TODO List:
	- hook for VirtualFree after detaching & self-modifying code for auto-replacing jmp to hook with original call
	- support of 4.x.x


	(c) 0xD
*/

#include "dseres.h"
#include "header.h"


static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	unsigned char	packet[8192];
	DWORD			oldProtect;
	BYTE			code[4];
	POINT			pt;
	static HWND		chkMem	= (HWND)-1;

	switch (msg)
	{
		case WM_INITDIALOG:
		{
			FILE *f;

			if (!hWndLB)
			{
				hWndLB = GetDlgItem(hwndDlg,101);
				SendMessage(hWndLB,EM_LIMITTEXT,CHARS_IN_LINE,0);
				InitErasedLines(hWndLB);
				SetLineText(hWndLB, "");
				//LBS_NOSEL
			}

			retry:

			f = fopen("dse.cfg","r");

			if (!f)
			{
				MoveLinesUp(hWndLB);
				SetLineText(hWndLB, "dse.cfg not found! Creating default dse.cfg");
				f = fopen("dse.cfg","w");
				fprintf(f,"10011");
				fclose(f);
				goto retry;
			}
			if (FileSize(f) != 5)
			{
				fclose(f);
				MoveLinesUp(hWndLB);
				SetLineText(hWndLB, "dse.cfg file corrupted! Creating default dse.cfg");
				f = fopen("dse.cfg","w");
				fprintf(f,"10011");
				fclose(f);
				goto retry;
			}
			else
			{
				for (int i=0;i<5;i++)
				{
					fseek(f, i, SEEK_SET);
					fread(log, 1, 1, f);
					SendDlgItemMessage(hwndDlg, 105+i, BM_SETCHECK, atoi(log), 0);
				}
				fclose(f);
			}
			hPopupMenu = CreatePopupMenu();
			AppendMenu(hPopupMenu,MF_STRING,ID_RESTORE,RS);
			AppendMenu(hPopupMenu,MF_STRING,ID_EXIT,ES);

			SendMessage(hwndDlg, WM_SETICON, ICON_BIG, (long)(LoadIcon(hInst, MAKEINTRESOURCE(53))));

			return 1;
		}
		case WM_SIZE:
			if (wParam == SIZE_MINIMIZED)
			{
				Add_TrayIcon(hwndDlg);
				ShowWindow(hwndDlg,SW_HIDE);
			}
			return 1;

		case WM_NOTIFYICON:
			if (wParam == 1)
				if (lParam == WM_RBUTTONDOWN)
				{
					GetCursorPos(&pt);
					SetForegroundWindow(hwndDlg);
					TrackPopupMenu(hPopupMenu,TPM_LEFTALIGN | TPM_LEFTBUTTON,pt.x,pt.y,0,hwndDlg,NULL);

					PostMessage(hwndDlg,WM_NULL,0,0);
				}
				else if (lParam == WM_LBUTTONDBLCLK)
					SendMessage(hwndDlg,WM_COMMAND,ID_RESTORE,0);
			return 1;

		case CM_SEND: // ya! we r recv a msg from client
		{
			/*
			client send a packet 
			wParam - address of packet buffer
			lParam - packet length
			*/
			if ((int)lParam > 8192)
				return 1;

			ReadProcessMemory(procHandle, (void *)wParam, packet, (int)lParam, &bytes);
			packet_len = (int)lParam;
			/* write packet to our back buffer */
			WriteProcessMemory(procHandle, (void *)BackBuffer, &packet, sizeof(packet), &bytes);

			handlePacket(hwndDlg, packet, (int)lParam, (void *)wParam, 0);

			/* update length of packet */
			REVERSEDWORD(&code[0], packet_len);
			WriteProcessMemory(procHandle, (void *)0x400519, &code, 4, &bytes);

			return TRUE;
		}
		case CM_RECV:
		{
			/*
			client recv a packet 
			wParam - address of packet buffer
			lParam - packet length
			*/
			if ((int)lParam > 8192)
				return 1;

			ReadProcessMemory(procHandle, (void *)wParam, packet, (int)lParam, &bytes);

			packet_len = (int)lParam;
			WriteProcessMemory(procHandle, (void *)BackBuffer, &packet, sizeof(packet), &bytes);

			handlePacket(hwndDlg, packet, (int)lParam, (void *)wParam, 1);

			REVERSEDWORD(&code[0], packet_len);
			WriteProcessMemory(procHandle, (void *)0x400619, &code, 4, &bytes);

			return TRUE;
		}

		case CM_ALLOC: 
		{
			/* 
			message from VAlloc hook
			wParam - address of allocated memory
			lParam - esp register
			*/
			unsigned int addrFrom = 0;

			if (!wParam)
			{
				MessageBox(0, "Can't allocate memory in process", "!", MB_OK);
				GetDlgItemText(hwndDlg,102,log,256);
				if (!strcmp(log,"Detach"))
					TerminateApp(hwndDlg);
				return 1;
			}

			BackBuffer = (unsigned char *)wParam;
			/* read address where VAlloc hook called (call adds ret addr to esp reg) */
			ReadClientMemory((void *)(lParam+0x24), &addrFrom, 4); 

			if (addrFrom-5 == addrSend)
			{
				/* writing jmp to send hook in VirtualAlloc hook */
				REVERSEDWORD(&code[0], CALCCALL(0x40072D, 0x400500));
				WriteClientMemory((void *)0x40072E, &code, 4);
			}
			else if (addrFrom-7 == addrRecv)
			{
				/* writing jmp to recv hook in VirtualAlloc hook */
				REVERSEDWORD(&code[0], CALCCALL(0x40072D, 0x400600));
				WriteClientMemory((void *)0x40072E, &code, 4);
			}

			/* replacing client calls with jmps to hooks */
			replaceClientCalls();

			return 1;
		}

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case ID_RESTORE:
					Delete_TrayIcon(hwndDlg);
					ShowWindow(hwndDlg,SW_RESTORE);
					SetForegroundWindow(hwndDlg);
					return 1;

				case ID_EXIT:
					EndDialog(hwndDlg,0);
					return 1;

				case IDA:
				{
					GetDlgItemText(hwndDlg,102,log,256);
					if (!strcmp(log,"Attach"))
					{

						hWndUO = FindWindow("Ultima Online",NULL);
						if (!hWndUO)
						{
							MessageBox(NULL, "Can't find UO window!", "!", MB_OK);
							return 1;
						}
						GetWindowThreadProcessId(hWndUO,&procId);
						if (!procId)
						{
							MessageBox(NULL, "Can't get UO process!", "!", MB_OK);
							hWndUO = 0;
							return 1;
						}
						procHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, procId);
						if (!procHandle)
						{
							MessageBox(NULL, "Can't open process", "!", MB_OK);
							procId = 0;
							hWndUO = 0;
							return 1;
						}
						if (!VirtualProtectEx(procHandle, (void*)0x400000, 0x1000, PAGE_READWRITE, &oldProtect))
						{
							MessageBox(NULL, "Can't change the access protection of memory", "!", MB_OK);
							procId = 0;
							procHandle = 0;
							hWndUO = 0;
							CloseHandle(procHandle);
							return 1;
						}

						GetTimeStamp(); // this func set TimeStamp var

						FILE *cfg = fopen("./addr.cfg", "r");
						if (!cfg)
						{
							MessageBox(NULL, "Can't open addr.cfg", "!", MB_OK);
							fclose(cfg);
							CloseHandle(procHandle);
							return 1;
						}

						char idClient[30];
						memset(idClient, 0, sizeof(idClient));
						CfgReadString(cfg, "CLIENT_NAME", idClient, TimeStamp);
						if(!strlen(idClient))
						{
							MessageBox(NULL, "Can't identify UO client version", "!", MB_OK);
							fclose(cfg);
							CloseHandle(procHandle);
							return 1;
						}

						addrSend       = CfgReadInt(cfg, "SEND_HOOK", TimeStamp);
    					addrRecv       = CfgReadInt(cfg, "RECV_HOOK", TimeStamp);
    					regSendBuf     = CfgReadInt(cfg, "SEND_BUF", TimeStamp);
    					regSendLen     = CfgReadInt(cfg, "SEND_LEN", TimeStamp);
    					regRecvBuf     = CfgReadInt(cfg, "RECV_BUF", TimeStamp);
   						regRecvLen     = CfgReadInt(cfg, "RECV_LEN", TimeStamp);
						addrTargInit   = CfgReadInt(cfg, "TARGET_FUNC", TimeStamp);
						addrTargFunc   = CfgReadInt(cfg, "TARGET_ADDR", TimeStamp);
						addrTargEnable = CfgReadInt(cfg, "TARGET_SHOW", TimeStamp);

						fclose(cfg);
						
						WriteProcessMemory(procHandle, (void *)addrTargInit, &addrTargFunc, sizeof(addrTargFunc), &bytes);

						/*
						hooks locations:
						0x400500 - send
						0x400600 - recv
						0x400700 - VAlloc
						*/
						writeSendHack(hwndDlg, 0x400500, addrSend);
						writeRecvHack(hwndDlg, 0x400600, addrRecv);

						if (chkMem == (HWND)-1 || chkMem != hWndUO)
						{
							chkMem = hWndUO;
							writeVAlloc(hwndDlg, 0x400700);
						}
						else if (chkMem == hWndUO) // we already have allocated memory
							replaceClientCalls();

						SendDlgItemMessage(hwndDlg,102,WM_SETTEXT,0,(long)"Detach");
						sprintf(log, "Initializing client %s... OK", idClient);
						MoveLinesUp(hWndLB);
						SetLineText(hWndLB, log);
						SetTimer(hwndDlg, 1, 10, NULL);
					}
					else if (!strcmp(log,"Detach"))
					{
						TerminateApp(hwndDlg);
						SendDlgItemMessage(hwndDlg,102,WM_SETTEXT,0,(long)"Attach");
					}
					return 1;
				}

				case IDC:
					EndDialog(hwndDlg,0);
					return 1;

				case IDH:
					ShellExecute(hwndDlg, "open", "DSE_TEOT.txt", NULL, NULL, SW_SHOW);
					return 1;
			}
			break;

		case WM_TIMER:
			if (!FindWindow("Ultima Online",NULL))
			{
				if (SendDlgItemMessage(hwndDlg, 106, BM_GETCHECK, 0, 0)==BST_CHECKED)
					EndDialog(hwndDlg,0);
				else
				{
					KillTimer(hwndDlg, 1);
					CloseHandle(procHandle);
					frecvh = 0;
					fsendh = 0;
					BackBuffer = 0; // we need to allocate memory with next attaching
					SetDlgItemText(hwndDlg,102,"Attach");
				}
			}
			return 1;

		case WM_CLOSE:
			EndDialog(hwndDlg,0);
			return 1;

		case WM_DESTROY:
			GetDlgItemText(hwndDlg,102,log,256);
			if (!strcmp(log,"Detach"))
				TerminateApp(hwndDlg);
			Delete_TrayIcon(hwndDlg);
			DestroyMenu(hPopupMenu);
			UpdateCFG(hwndDlg);
			return 1;

	}
	return FALSE;
}

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wc;
	INITCOMMONCONTROLSEX cc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = DefDlgProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = DLGWINDOWEXTRA;
	wc.hInstance = hinst;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
	wc.lpszClassName = "dse";
	RegisterClass(&wc);
	memset(&cc,0,sizeof(cc));
	cc.dwSize = sizeof(cc);
	cc.dwICC = 0xffffffff;
	InitCommonControlsEx(&cc);

	hInst = hinst;

	return DialogBox(hinst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);
}
