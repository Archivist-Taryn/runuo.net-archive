#if !defined(DSE)
#define DSE

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <stdio.h>
#include <winsock.h>
#include <shellapi.h>

#define CALCCALL(from, to) 	((to)-(from)-5)
#define CM_SEND				WM_USER+1
#define CM_RECV				WM_USER+2
#define CM_ALLOC			WM_USER+3
#define CHARS_IN_LINE		128
#define LB_LINES			60
#define WM_NOTIFYICON		WM_USER+100
#define ID_RESTORE			1000
#define ID_EXIT				2000

/*
Windows identifiers & misc. variables
*/
HANDLE 						procHandle		= 0;
unsigned int 				procId			= 0;
unsigned long 				bytes;
HWND						hWndUO			= 0;
unsigned int				TimeStamp		= 0;
HWND						hWndLB			= 0;
char						log[512];
unsigned int				oldSend			= 0;
unsigned int				oldRecv			= 0;
unsigned int				frecvh			= 0;
unsigned char				fsendh			= 0;
unsigned int				packet_len		= 0;
const char					RS[]			= "Restore",
							ES[]			= "Exit";
HINSTANCE					hInst;
HMENU						hPopupMenu;
unsigned char				*BackBuffer     = 0;

/*
Target hack
*/
typedef int UOTargetCallBack (unsigned int uid);
UOTargetCallBack *TargetCallBack = 0;
unsigned int				addrTargEnable	= 0;
unsigned int				addrTargInit	= 0;
unsigned int				addrTargFunc	= 0;

/*
Client variables
*/
unsigned int 				addrRecv		= 0;
unsigned int				addrSend		= 0;
unsigned char				regRecvBuf		= 0;
unsigned char				regRecvLen		= 0;
unsigned char				regSendBuf		= 0;
unsigned char				regSendLen		= 0;

/*
Player variables
*/
unsigned int				MobSerial;
unsigned int 				MobBPUID;
unsigned char				FakePacket[2]	= {0x73, 0x01};
unsigned char				MobName[30];

/*
Cheat triggers
*/
int 						BankHack		= 0;
int 						GetCharStats	= 0;
unsigned int 				ObjectToDye		= 0;
int 						DyeHack			= 0;

/*
LISTBOX functions
*/
void MoveLinesUp(HWND dhwnd)
{
	char m[CHARS_IN_LINE];

	for (int i=1;i<LB_LINES+1;i++)
	{
		SendMessage(dhwnd,LB_GETTEXT,i,(int)m);
		SendMessage(dhwnd,LB_DELETESTRING,i-1,0);
		SendMessage(dhwnd,LB_INSERTSTRING,i-1,(int)m);
	}
}

void SetLineText(HWND dhwnd, char *text)
{
	SendMessage(dhwnd,LB_INSERTSTRING,LB_LINES,(int)text);
	SendMessage(dhwnd,LB_DELETESTRING,(LB_LINES+1),0);
	SendMessage(dhwnd,LB_SETCURSEL,LB_LINES,0);
}

void InitErasedLines(HWND dhwnd)
{
	int i;

	for (i=0;i<LB_LINES;i++)
		SendMessage(dhwnd,LB_INSERTSTRING,0,(int)"");
}

/*
Tray functions
*/
void Add_TrayIcon(HWND hwndDlg)
{
	NOTIFYICONDATA tnid;
	HICON hicon;

	hicon = LoadIcon(hInst, MAKEINTRESOURCE(IDICON53));

	tnid.cbSize = sizeof(NOTIFYICONDATA);
	tnid.hWnd = hwndDlg;
	tnid.uID = 1;
	tnid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	tnid.uCallbackMessage = WM_NOTIFYICON;
	tnid.hIcon = hicon;
    lstrcpyn(tnid.szTip, "DSE_TEOT", sizeof(tnid.szTip));

	Shell_NotifyIcon(NIM_ADD, &tnid);

	if (hicon)
        DestroyIcon(hicon);
}

void Delete_TrayIcon(HWND hwndDlg)
{
	NOTIFYICONDATA tnid;

	tnid.cbSize = sizeof(NOTIFYICONDATA);
    tnid.hWnd = hwndDlg;
    tnid.uID = 1;

	Shell_NotifyIcon(NIM_DELETE, &tnid);
}

/*
---
*/
long GetFuncAddrInIAT(char *DLLName, char *funcName)
{
	HINSTANCE hMod;
	void* funcAddr;
	DWORD PEOffset;
	DWORD IATAddr;
	DWORD IATSize;
	DWORD cmpAddr;

	hMod = LoadLibrary(DLLName);
	funcAddr = GetProcAddress(hMod, funcName);
	FreeLibrary(hMod);

	ReadProcessMemory(procHandle, (void *)0x40003C, &PEOffset, 4, &bytes);
	ReadProcessMemory(procHandle, (void *)(0x400000 + PEOffset + 0xD8), &IATAddr, 4, &bytes);
	IATAddr += 0x400000;
	ReadProcessMemory(procHandle, (void *)(0x400000 + PEOffset + 0xDC), &IATSize, 4, &bytes);

	for (int i = 0; i < IATSize/4; i++)
	{
		ReadProcessMemory(procHandle, (void *)(IATAddr + i * 4), &cmpAddr, 4, &bytes);
		if ((long)funcAddr == cmpAddr)
			return IATAddr + i * 4;
	}

	return 0;
}

void GetTimeStamp()
{
	DWORD PEOffset;

	ReadProcessMemory(procHandle, (void *)0x40003C, &PEOffset, 4, &bytes);
	ReadProcessMemory(procHandle, (void *)(0x400000 + PEOffset + 0x08), &TimeStamp, 4, &bytes);
}

void UpdatePacket(char *packet, unsigned int len)
{
	packet_len = len;
	WriteClientMemory((void *)(BackBuffer), packet, len);
}

unsigned long FileSize(FILE *File)
{
	unsigned long size, old;
   	old=ftell(File);
	fseek(File, 0, SEEK_END);
	size=ftell(File);
	fseek(File, old, SEEK_SET);
	return size;
}

void TerminateApp(HWND hwndDlg)
{
	KillTimer(hwndDlg, 1);
	remSendHack(addrSend);
	remRecvHack(addrRecv);
	CloseHandle(procHandle);
	frecvh = 0;
	fsendh = 0;
}

void UpdateCFG(HWND hwndDlg)
{
	FILE *f;
	f = fopen("dse.cfg","w");
	for (int i=0;i<5;i++)
	{
		fseek(f, i, SEEK_SET);
		sprintf(log, "%d", SendDlgItemMessage(hwndDlg, 105+i, BM_GETCHECK, 0, 0));
		fwrite(log, 1, 1, f);
	}
	fclose(f);
}

void replaceClientCalls()
{
	BYTE code_repsend[] = {
		0xE9, 0x00, 0x00, 0x00, 0x00		/* call */
	};

	BYTE code_frep[] = {
		0xE9, 0x00, 0x00, 0x00, 0x00,		/* jmp  0x400600*/
		0x74, 0x00							/* je xx bytes down */
	};

	/* writing jmp to send hook in sendAddr */
	REVERSEDWORD(&code_repsend[1], CALCCALL(addrSend, 0x400500));
	WriteProcessMemory(procHandle, (void *)addrSend, &code_repsend, sizeof(code_repsend), &bytes);

	/* writing jmp to recv hook in recvAddr */
	REVERSEDWORD(&code_frep[5], frecvh);
	REVERSEDWORD(&code_frep[1], CALCCALL(addrRecv, 0x400600));
	WriteProcessMemory(procHandle, (void *)addrRecv, &code_frep, sizeof(code_frep), &bytes);

	/* writing address of backbuffer to hooks */
	WriteProcessMemory(procHandle, (void *)0x40051E, &BackBuffer, sizeof(BackBuffer), &bytes);
	WriteProcessMemory(procHandle, (void *)0x40061E, &BackBuffer, sizeof(BackBuffer), &bytes);
}

void writeVAlloc(HWND hDlg, DWORD whereAddr)
{
	BYTE code_valloc[] = {

				0x60, 								/* pushad */
				0x9C, 								/* pushfd */

				0x54,								/* push esp (!don't forget += 24!) */

				0x6A, 0x04,							/* push 0x04 */
				0x68, 0x00, 0x10, 0x00, 0x00,		/* push 0x1000 */
				0x68, 0xFF, 0xFF, 0x00, 0x00,		/* push 0xFFFF */
				0x6A, 0x00,							/* push 0 */
				0xFF, 0x15, 0x00, 0x00, 0x00, 0x00,	/* call VirtualAlloc */

				0x50,								/* push eax */
				0x68, 0x3, 0x04, 0x00, 0x00,		/* push WM_USER+3 */
				0x68, 0x00, 0x00, 0x00, 0x00,		/* push HWND */
				0xFF, 0x15, 0x00, 0x00, 0x00, 0x00,	/* call SendMessage */

				0x9D, 								/* popfd */
				0x61, 								/* popad */
				0x83, 0xC4, 0x04,					/* add esp, 4 */
				0xE9, 0x00, 0x00, 0x00, 0x00		/* jmp signed hook */
	};

	BYTE code_repsend[] = {
				0xE8, 0x00, 0x00, 0x00, 0x00		/* call */
	};
	BYTE code_reprecv[] = {
				0xE8, 0x00, 0x00, 0x00, 0x00		/* call */
	};

	/* initializing alternate VirtualAlloc code */
	REVERSEDWORD(&code_valloc[19], GetFuncAddrInIAT("kernel32.dll", "VirtualAlloc"));
	REVERSEDWORD(&code_valloc[30], (long)hDlg);
	REVERSEDWORD(&code_valloc[36], GetFuncAddrInIAT("User32.dll", "SendMessageA"));

	/* initializing recv & send hook calls */
	REVERSEDWORD(&code_repsend[1], CALCCALL(addrSend, 0x400700));
	REVERSEDWORD(&code_reprecv[1], CALCCALL(addrRecv+2, 0x400700));

	/* writing opcodes to client process */
	WriteProcessMemory(procHandle, (void *)whereAddr, &code_valloc, sizeof(code_valloc), &bytes);
	WriteProcessMemory(procHandle, (void *)addrSend, &code_repsend, sizeof(code_repsend), &bytes);
	WriteProcessMemory(procHandle, (void *)(addrRecv+2), &code_reprecv, sizeof(code_reprecv), &bytes);
}

void writeSendHack(HWND hDlg, DWORD whereAddr, DWORD repAddr)
{
	DWORD call;
	DWORD targAddr;
	BYTE code[] = {
				0x60, 								/* pushad */
				0x9C, 								/* pushfd */
				0x00, 								/* push regSendLen */
				0x00, 								/* push regSendBuf */
				0x68, 0x1, 0x04, 0x00, 0x00, 		/* push WM_USER+1 */
				0x68, 0x00, 0x00, 0x00, 0x00, 		/* push HWND */
				0xFF, 0x15, 0x00, 0x00, 0x00, 0x00, /* call SendMessage */
				0x9D, 								/* popfd */
				0x61, 								/* popad */

				0x00,								/* pop regSendBuf */
				0x00,								/* pop regSendLen */
				0x00, 0x00, 0x00, 0x00, 0x00,		/* mov regSendLen, packet_len */
				0x00, 0x00, 0x00, 0x00, 0x00,		/* mov regSendBuf, BackBuffer */
				0x00,								/* push regSendLen */
				0x00,								/* push regSendBuf */

				0xE8, 0x00, 0x00, 0x00, 0x00, 		/* call targAddr */
				0xE9, 0x00, 0x00, 0x00, 0x00, 		/* jmp repAddr+5 */

				0xC3 								/* ret */
	};

	if (!fsendh)
	{
		REVERSEDWORD(&code[10], (long)hDlg);
		REVERSEDWORD(&code[16], GetFuncAddrInIAT("User32.dll", "SendMessageA"));

		ReadProcessMemory(procHandle, (void *)(repAddr+1), &call, sizeof(call), &bytes);
		targAddr = repAddr + (call) + 5;
		REVERSEDWORD(&code[25], packet_len);
		REVERSEDWORD(&code[37], CALCCALL(whereAddr+36,targAddr));
		REVERSEDWORD(&code[42], CALCCALL(whereAddr+41,repAddr+5));
		code[2] = regSendLen+0x50;
		code[3] = regSendBuf+0x50;
		code[22] = regSendBuf+0x58;
		code[23] = regSendLen+0x58;
		code[24] = regSendLen+0xB8;
		code[29] = regSendBuf+0xB8;
		code[34] = regSendLen+0x50;
		code[35] = regSendBuf+0x50;

		oldSend = call;
		fsendh = 1;
		WriteProcessMemory(procHandle, (void *)whereAddr, &code, sizeof(code), &bytes);
	}
}

void writeRecvHack(HWND hDlg, DWORD whereAddr, DWORD repAddr)
{
	DWORD call;
	WORD jmp;
	DWORD targAddr;
	BYTE code[] = {
				0x60, 								/* pushad */
				0x9C, 								/* pushfd */
				0x00, 								/* push regRecvLen */
				0x00, 								/* push regSendLen */
				0x68, 0x2, 0x04, 0x00, 0x00, 		/* push WM_USER+2 */
				0x68, 0x00, 0x00, 0x00, 0x00, 		/* push HWND */
				0xFF, 0x15, 0x00, 0x00, 0x00, 0x00, /* call SendMessage */
				0x9D, 								/* popfd */
				0x61, 								/* popad */

				0x00,								/* pop regRecvBuf */
				0x00,								/* pop regRecvLen */
				0x00, 0x00, 0x00, 0x00, 0x00,		/* mov regRecvLen, packet_len */
				0x00, 0x00, 0x00, 0x00, 0x00,		/* mov regRecvBuf, BackBuffer */
				0x00,								/* push regRecvLen */
				0x00,								/* push regRecvBuf */

				0xE8, 0x00, 0x00, 0x00, 0x00, 		/* call targAddr */
				0xE9, 0x00, 0x00, 0x00, 0x00, 		/* jmp repAddr+5 */
				0xC3 								/* ret */
	};

	if (!frecvh)
	{

		REVERSEDWORD(&code[10], (long)hDlg);
		REVERSEDWORD(&code[16], GetFuncAddrInIAT("User32.dll", "SendMessageA"));
		ReadProcessMemory(procHandle, (void *)(repAddr+3), &call, sizeof(call), &bytes);

		targAddr = (repAddr+2) + (call) + 5;
		REVERSEDWORD(&code[37], CALCCALL(whereAddr+36,targAddr));
		REVERSEDWORD(&code[42], CALCCALL(whereAddr+41,repAddr+5));
		code[2] = regRecvLen+0x50;
		code[3] = regRecvBuf+0x50;
		code[22] = regRecvBuf+0x58;
		code[23] = regRecvLen+0x58;
		code[24] = regRecvLen+0xB8;
		code[29] = regRecvBuf+0xB8;
		code[34] = regRecvLen+0x50;
		code[35] = regRecvBuf+0x50;

		oldRecv = call;
		ReadProcessMemory(procHandle, (void *)repAddr, &jmp, sizeof(jmp), &bytes);
		frecvh = jmp;
		WriteProcessMemory(procHandle, (void *)whereAddr, &code, sizeof(code), &bytes);
	}

}

void remSendHack(DWORD repAddr)
{
	BYTE code_rep[] = { 0xE8, 0x00, 0x00, 0x00, 0x00 }; /* call */

	REVERSEDWORD(&code_rep[1], oldSend);
	WriteProcessMemory(procHandle, (void *)repAddr, &code_rep, 5, &bytes);

}

void remRecvHack(DWORD repAddr)
{
	BYTE xx;
	BYTE code_frep[] = {	0x74, 0x00,
							0xE8, 0x00, 0x00, 0x00, 0x00 };	/* call */

	ReadProcessMemory(procHandle, (void *)(repAddr+6), &xx, 1, &bytes);
	code_frep[1] = xx;
	REVERSEDWORD(&code_frep[3], oldRecv);
	WriteProcessMemory(procHandle, (void *)repAddr, &code_frep, 7, &bytes);
}

/*
---
*/
void ShowTarget(void *func)
{
	char enable=0x01;
	WriteProcessMemory(procHandle, (void*)addrTargEnable, &enable, 1, &bytes);
	TargetCallBack=(UOTargetCallBack*)func;
	return;
}

void inline REVERSEDWORD(BYTE *Buffer, DWORD val)
{
   *(Buffer+0)=((BYTE)(val>>0)&0xFF);
   *(Buffer+1)=((BYTE)(val>>8)&0xFF);
   *(Buffer+2)=((BYTE)(val>>16)&0xFF);
   *(Buffer+3)=((BYTE)(val>>24)&0xFF);
}

inline void pack_big_uint32(unsigned char * buf, unsigned int x)
{
    buf[0] = (unsigned char)(x >> 24);
    buf[1] = (unsigned char)((x >> 16) & 0xff);
    buf[2] = (unsigned char)((x >> 8) & 0xff);
    buf[3] = (unsigned char)(x & 0xff);
}

inline unsigned int unpack_big_uint32(unsigned char * buf)
{
    return (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3];
}

inline unsigned short unpack_big_uint16(unsigned char * buf)
{
    return (buf[0] << 8) | buf[1];
}

void ReadClientMemory(void *from_addr, void *in, int size)
{
	ReadProcessMemory(procHandle, from_addr, in, size, &bytes);
}

void WriteClientMemory(void *to_addr, void *in, int size)
{
	WriteProcessMemory(procHandle, to_addr,	in,	size, &bytes);
}

int ParseWorldInfo(FILE *cfg, char *what, char *hack)
{
	char line[0x100];
	int insection = 0;
	int sn = 0;

	if(!cfg)
	{
		MoveLinesUp(hWndLB);
		SetLineText(hWndLB, "Config is missing.");
		return 0;
	}

	while(fgets(line, sizeof(line), cfg))
   	{
		if((!insection) && strstr(line, what))
		{
			insection = 1;
			continue;
		}
		if(insection && strchr(line, '{'))
      	 	continue;
		if(insection && strchr(line, '}'))
      	{
		    return sn;
        }
		if(insection)
		{
		char *c = line;
			while((*c!='@')&&*++c)
				;
			if(*c)
			{
				if(strstr(c, "@MOB_UID"))
					sprintf(c, "0%x\n\0", MobSerial);
				else if(strstr(c, "@MOB_BP_UID"))
					sprintf(c, "0%x\n\0", MobBPUID);
			}
			int n = strlen(line);
			strcpy(&hack[sn], line);
			sn+=n;
		}
	}
	return 0;
}

void ClientTalk(int color, unsigned char type, const char *zText)
{
		char Buff[0x400];
		strcpy(Buff, zText);
		WCHAR Text[0x400];
		int StrLen=strlen(Buff);
		MultiByteToWideChar(1251,0,Buff,StrLen,Text,1024);
		for(int i=0; i<StrLen; i++)
			Text[i]=htons(Text[i]);
		Buff[0]=(char)0xad;
		Buff[1]=(StrLen*2+14)/256;
		Buff[2]=(StrLen*2+14)%256;
		Buff[3]=(char)type;
		Buff[4]=color/256;
		Buff[5]=color%256;
		Buff[6]=0;
		Buff[7]=3;
		strcpy(Buff+8,"RUS");
		memcpy(Buff+12,Text,StrLen*2);
		Buff[StrLen*2+12]=0;
		Buff[StrLen*2+13]=0;
		UpdatePacket(Buff, StrLen*2+14);
		return;
}

int HackBook1(unsigned int uid) //Hack with book write in world my logo
{
	unsigned char buf[0x400];
	*buf=0x66;
	pack_big_uint32(&buf[3], uid);
	/*parse the file*/
	FILE *cfg = fopen("./teot.scp", "r");
	char *text = malloc(0x200);
	int n = ParseWorldInfo(cfg, "HACK_BOOK", text);
	if(!n || (n>255))
	{
		MoveLinesUp(hWndLB);
		SetLineText(hWndLB, "Config section error.");
		return 0;
	}
	fclose(cfg);
	/*end*/
	n = strlen(text);
	strcpy(&buf[13], text);
	free(text);
	++n;
	int p_len = (13 + n);
	buf[1] = (p_len/256);
	buf[2] = (p_len%256);
	buf[7] = 0x00; buf[8] = 0x01; //total page's
	buf[9] = 0x00; buf[10] = 0x01; //page index from 1
	buf[11] = 0x00; buf[12] = 0x01; //line's on page
	UpdatePacket(buf, p_len);
	return 1;
}


int HackBB1(unsigned int uid) // Hack with BB write in world my logo
{
	char buf[0x400];
	char bb_title[0x100];
    char bb_text[0x100];
	memset(buf, 0x00, 0x400);
	strcpy(bb_title, "Hello World");
    unsigned char bb_title_len = strlen(bb_title);
	++bb_title_len;

	/*parse the file*/
	FILE *cfg = fopen("./teot.scp", "r");
	char *text = malloc(0x200);
	int n = ParseWorldInfo(cfg, "HACK_BB", text);

	if(!n || (n>255))
	{
		MoveLinesUp(hWndLB);
		SetLineText(hWndLB, "Config section error.");
		return 0;
	}

	fclose(cfg);
	/*end*/
	strcpy(bb_text, text);
	free(text);
	unsigned short bb_text_len = strlen(bb_text);
	++bb_text_len;
	*buf = 0x71;
	int p_len = (15 + bb_text_len + bb_title_len);
	buf[1] = (p_len/256);
	buf[2] = (p_len%256);
	buf[3] = 0x05; /*Post message type*/
	pack_big_uint32(&buf[4], uid);
	buf[12] = bb_title_len;
	strcpy(&buf[13], bb_title);
    buf[13+bb_title_len] = 0x01; /*line's in message*/
	buf[13+bb_title_len+1] = bb_text_len;
	strcpy(&buf[13+bb_title_len+2], bb_text);
	UpdatePacket(buf, p_len);
	return 1;
}
int RequestCharStats(unsigned int uid) //try to get char stats
{
	unsigned char p[]={0x34 ,0xed ,0xed ,0xed ,0xed ,0x04 ,0x00 ,0x00, 0x8c, 0xd9};
	pack_big_uint32(&p[6], uid);
	UpdatePacket(p, 10);
	return 1;
}

int DyeHackFunc(unsigned int uid) //dye cheat .. dye anything what you want
{
	ObjectToDye = uid;
	DyeHack = 1;
	MoveLinesUp(hWndLB);
	SetLineText(hWndLB, "Use dye's on dye tub and select color");
	return 0;
}

int RenameMob(unsigned int uid) //rename cheat
{
	unsigned char p[0x23];
	*p=0x75;
	pack_big_uint32(&p[1], uid);
	for(int i=0;i<30;i++)
	{
		if(MobName[i]=='$')
			MobName[i]=0x0A;
	}
	strcpy(&p[5], MobName);
	UpdatePacket(p, 0x23);
	sprintf(log, "Rename to '%s', uid '0x%x'\n", MobName, uid);
	MoveLinesUp(hWndLB);
	SetLineText(hWndLB, log);
	return 1;
}

int SetTag(unsigned int uid) //set tag value
{
	if(strstr(MobName, "@MOB_UID"))
		MobSerial = uid;
	else if(strstr(MobName, "@MOB_BP_UID"))
		MobBPUID = uid;
	sprintf(log, "Tag '%s' is '0%x'\n", MobName, uid);
	MoveLinesUp(hWndLB);
	SetLineText(hWndLB, log);
	return 0;
}

int AttackMob(unsigned int uid) //atack mob
{
	unsigned char p[0x05];
	*p=0x05;
	pack_big_uint32(&p[1], uid);
	UpdatePacket(p, 0x05);
	return 1;
}

int ExecCmd(char *cmd, char *param)
{
	if (!stricmp(cmd, "#ress"))
    {
        unsigned char p[]={0x2c, 0x01};
        UpdatePacket(p, 0x02);
		MoveLinesUp(hWndLB);
		SetLineText(hWndLB, "Resurrection cheat!");
        return 1;
    }
	else if(!stricmp(cmd, "#godyell"))
	{
		if(param)
			ClientTalk(0x22, 0xFF, param);
		MoveLinesUp(hWndLB);
		SetLineText(hWndLB, "Godyell cheat!");
		return 1;
	}
	else if(!stricmp(cmd, "#crash"))
	{
		if(param)
			ClientTalk(0x6D60, 0x00, param);
		MoveLinesUp(hWndLB);
		SetLineText(hWndLB, "Crash cheat!");
		return 1;
	}
	else if(!stricmp(cmd, "#charstats"))
	{
		GetCharStats = 1;
		ShowTarget(RequestCharStats);
		return 0;
	}
	else if(!stricmp(cmd, "#hackbook"))
	{
		ShowTarget(HackBook1);
		return 0;
	}
	else if(!stricmp(cmd, "#hackbb"))
	{
		ShowTarget(HackBB1);
		return 0;
	}
	else if(!stricmp(cmd, "#rename"))
	{
		ShowTarget(RenameMob);
		if(param)
			strcpy(MobName, param);
		return 0;
	}
	else if(!stricmp(cmd, "#xinfo"))
	{
		ShowTarget(SetTag);
		if(param)
			strcpy(MobName, param);
		else
			strcpy(MobName, "info about object");
		return 0;
	}
	else if(!stricmp(cmd, "#attack"))
	{
		ShowTarget(AttackMob);
		return 0;
	}
	else if(!stricmp(cmd, "#dye"))
	{
		ShowTarget(DyeHackFunc);
		return 0;
	}
	else if(!stricmp(cmd, "#bankhack"))
	{
		MoveLinesUp(hWndLB);
		SetLineText(hWndLB, "Wait for bank...");
		BankHack = 1;
		return 0;
	}

	return 0;
}

int ParseCmd(char *Packet, int Len, int IsUni)
{
	char tmpBuf[0x100];
	memset(tmpBuf, 0x00, 0x100);
	if(IsUni)
	{
		int n=0;
		int nLen=Len<<1;
		for(int i=1;i<nLen;i++)
		{
			char c=Packet[i];
			if(isprint(c))
				tmpBuf[n++]=c;
		}
	}
	else
		memcpy(tmpBuf, Packet, Len);
	char* param = strchr(tmpBuf, ' ');
	if(param)
		*param++='\0';
	return ExecCmd(tmpBuf, param);
}

void handlePacket(HWND hwndDlg, unsigned char *packet, unsigned int len, void *addr, unsigned int type)
{
	if (type == 0)
		switch (packet[0])
		{
			case 0x03:
			{
				if (SendDlgItemMessage(hwndDlg, 105, BM_GETCHECK, 0, 0)==BST_UNCHECKED)
					break;
				if (packet[8] == '#')
				{
					int Len=(((packet[1] << 8) + packet[2])-8);
               		if(!ParseCmd((char*)&packet[8], Len, 0))
                	{
						UpdatePacket(FakePacket, 0x02);
                	}
				}
				break;
			}
			case 0xad:
			{
				if (SendDlgItemMessage(hwndDlg, 105, BM_GETCHECK, 0, 0)==BST_UNCHECKED)
					break;
				if (packet[13] == '#')
				{
					int Len=(((packet[1] << 8) + packet[2])-12)>>1;
                	if(!ParseCmd((char*)&packet[12], Len, 1))
					{
                		UpdatePacket(FakePacket, 0x02);
                	}
				}
				break;
			}
			case 0x95:
			{
				if(DyeHack)
				{
					DyeHack = 0;
					pack_big_uint32(&packet[1], ObjectToDye);
					UpdatePacket(packet, 0x09);
					sprintf(log, "Object '0x%X' was dyed.", ObjectToDye);
					MoveLinesUp(hWndLB);
					SetLineText(hWndLB, log);
				}
				break;
			}
			case 0x6c:
			{
				if(TargetCallBack)
				{
					if(!TargetCallBack(unpack_big_uint32(&packet[7])))
						UpdatePacket(FakePacket, 0x02);
					TargetCallBack=0;
				}
				break;
			}
			default:
				break;
		}
	else
		switch (packet[0])
		{
			case 0x33: //fast death
			{
				unsigned char p[]={0x33, 0x00};
				UpdatePacket(p, 0x02);
				break;
			}
			case 0x4f: //always light
			{
				if (SendDlgItemMessage(hwndDlg, 108, BM_GETCHECK, 0, 0)==BST_CHECKED)
				{
				unsigned char p[]={0x4f, 0x00};
				UpdatePacket(p, 0x02);
				}
				break;
			}
			case 0x65: //always clear
			{
				if (SendDlgItemMessage(hwndDlg, 109, BM_GETCHECK, 0, 0)==BST_CHECKED)
				{
				unsigned char p[]={0x65, 0xFF, 0x00, 0x00};
				UpdatePacket(p, 0x04);
				}
				break;
			}
			case 0x2c: //remove death screen
			{
				unsigned char p[]={0x2c, 0x01};
				UpdatePacket(p, 0x02);
				break;
			}
			case 0xae:
			case 0x1c:
			{
				if(unpack_big_uint16(&packet[10])>=0x03e9)
				{
					packet[10]=0x00;
					UpdatePacket(packet, len);
				}
				break;
			}
			case 0x20:
			{
				packet[6]=0x90;
				UpdatePacket(packet, len);
				break;
			}
			case 0x11:
			{
				if(!GetCharStats) //Stop flood in list box+))
					break;
				unsigned short hits = unpack_big_uint16(&packet[37]);
				unsigned short max_hits = unpack_big_uint16(&packet[39]);
				char *name = &packet[7];
				sprintf(log, "%s has %d/%d hitpoint's.", name, hits, max_hits);
				MoveLinesUp(hWndLB);
				SetLineText(hWndLB, log);
				GetCharStats = 0;
				break;
			}
			case 0x1b:
			{
				MobSerial = unpack_big_uint32(&packet[1]);
				break;
			}
			case 0x2e:
			{
				if(BankHack || SendDlgItemMessage(hwndDlg, 107, BM_GETCHECK, 0, 0)==BST_CHECKED)
				{
					unsigned short layer = packet[8];
					if(layer!=29)
						break;
					sprintf(log, "Bank with uid '0x%X' hacked.", unpack_big_uint32(&packet[1]));
					MoveLinesUp(hWndLB);
					SetLineText(hWndLB, log);
					packet[8]=0x0f;
					UpdatePacket(packet, 15);
					BankHack=0;
				}
				break;
			}
			default:
				break;
		}
}

unsigned int CfgReadInt(FILE *cfg, char *name, unsigned int timestamp)
{
   char line[200];
   char *found;
   char time[20];
   int insection=0, findstamp=0;
   unsigned int result=0;

   sprintf(time, "CLIENT 0x%X", timestamp);
   rewind(cfg);
   while(fgets(line, sizeof(line), cfg))
   {
      if(strstr(line, time))
         findstamp=1;
      if(findstamp && strchr(line, '{'))
         insection=1;
      if(insection && (found=strstr(line, name)))
      {
         int num=0;
         if(!strchr(found, '='))
            continue;
         found=strchr(line, '=')+1;
         if(strstr(found, "0x"))
            num=sscanf(found, "%X", &result);
         else
            num=sscanf(found, "%lu", &result);
         if(num==1)
            return result;
      }
      if(insection && strchr(line, '}'))
      {
         insection=0; findstamp=0;
      }
   }
   return 0;
}

void CfgReadString(FILE *cfg, char *name, char *dest, unsigned int timestamp)
{
   char line[200];
   char result[100];
   char *found;
   char time[20];
   int insection=0, findstamp=0;

   sprintf(time, "CLIENT 0x%X", timestamp);
   rewind(cfg);
   while(fgets(line, sizeof(line), cfg))
   {
      if(strstr(line, time))
         findstamp=1;
      if(findstamp && strchr(line, '{'))
         insection=1;
      if(insection && (found=strstr(line, name)))
      {
         int i=0;
         if(!strchr(found, '='))
            continue;
         found=strchr(line, '"')+1;
         while(found[i++]!='"') result[i-1]=found[i-1];
         result[i-1]='\0';
         strcpy(dest, result);
         return;
      }
      if(insection && strchr(line, '}'))
      {
         insection=0; findstamp=0;
      }
   }
   return;
}

#endif
