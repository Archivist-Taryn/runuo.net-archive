
Transition Maker:

use it from the command line

transition <path_to_map0.mul> <min_x> <min_y> <max_x> <max_y>

path_to_map0.mul - full path to your map0.mul file
min_x, min_y, max_x, max_y - this is the rectangle that should be worked on

everything else will be read from the file "transition.txt", which
defines what the transitions should look like.
