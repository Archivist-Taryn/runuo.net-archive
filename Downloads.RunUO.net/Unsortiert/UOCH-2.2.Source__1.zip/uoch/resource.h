//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by uoch.rc
//
#define NECRO_ICON                      101
#define DIALOG_MAIN                     103
#define CHECK_CRYPT                     1001
#define CHECK_NIGHTHACK                 1002
#define CHECK_NAMES                     1003
#define CHECK_MULTI                     1004
#define CHECK_EVERMAN                   1005
#define CHECK_MACRO                     1006
#define TEXT_DUMP                       1008
#define BUTTON_PATCH                    1009
#define EDIT_PATH                       1010
#define BUTTON_PATH                     1011
#define CHECK_LOGO                      1012
#define CHECK_STAMINA                   1013
#define IDC_CHECK1                      1015
#define CHECK_DEV                       1015
#define STATIC_PATH                     1016
#define STATIC_OPTIONS                  1017
#define STATIC_LOG                      1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
