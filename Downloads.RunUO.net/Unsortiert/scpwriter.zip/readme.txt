-------------------------------------------------------------
AVATAR PATCH'S .SCP MAKER CREATED BY FIRESTARTER
VER = 1.1
RELEASEDATE = 3.3.2002
-------------------------------------------------------------


--- News ---
-Added copy function 

--- To DO ---
-New and better design
-Paste & Cut function

--------OldReleases

Ver1.0
-ProjectStarted on 2.3.2002 by Avatars request to me
-this was test release


-------------------------------------------------------------
Special Avatar for wanting me to create this program 
www.AvatarPatch.com
Also to persons who wanted to contact to me
Icq=536944
Mail=sutunc3@yahoo.com
-------------------------------------------------------------
