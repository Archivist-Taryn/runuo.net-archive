This directory will hold the Random Static Information,
that will be used by the UOL tool: UO Map Make

Example:
<RandomStatics Chance="15">
  <Statics Description="Peach Tree with green leaves" Freq="0">
    <Static TileID="3484" X="0" Y="0" Z="0" Hue="0" />
    <Static TileID="3485" X="0" Y="0" Z="0" Hue="0" />
  </Statics>
</RandomStatics>

Chance is the Random chance to place a static object from the list.
Freq is a representation of how many can be placed.