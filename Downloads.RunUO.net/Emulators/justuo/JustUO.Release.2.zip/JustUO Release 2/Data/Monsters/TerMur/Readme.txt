Drop file "Termur" in root of your RunUO Directory.

To load the save. 
Wile in game, Type: "[XMLspawnerload Termur" 