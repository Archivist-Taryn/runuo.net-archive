using System;

namespace Server.Engines.BulkOrders
{
	public enum BODType
	{
		Smith,
		Tailor
	}
}