using System;
using System.Collections;
using Server.Network;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class PutridHuskSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Curse of the Putrid Husk", "Intre Invisre Inloc",
                17,
				Reagent.Bone,
				Reagent.SpidersSilk,
				Reagent.PigIron,
				Reagent.PigIron,
				Reagent.GraveDust,
				Reagent.GraveDust
			);

		public override string Desc{ get{ return "Places the target under an illusion."; } }
		public override string ReagentsDesc{ get{ return "One Spider's Silk, One Bone, Two PigIron, Two GraveDust."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Sixth; } }
        public override int SpellNumber { get { return 365; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Illusion; } }

		public PutridHuskSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( Mobile m )
		{
			if ( CheckHSequence( m ) && m is PolyGlotMobile)
			{
				SpellHelper.Turn( Caster, m );
				PolyGlotMobile dark = m as PolyGlotMobile;

				m.SendMessage( "Your flesh begins rotting away!" );

				m.FixedParticles( 0x373A, 1, 15, 9913, 67, 7, EffectLayer.Head );
				m.PlaySound( 0x1BB );

				double ss = GetDamageSkill( Caster );
				double mr = ( Caster == m ? 0.0 : GetResistSkill( m ) );

				TimeSpan duration = TimeSpan.FromSeconds( ((ss - mr) / 2.5) + 40.0 );

                //CustomResistanceMod mod1 = new CustomResistanceMod( dark, ResistType.Bludgeoning, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod1 );
                //CustomResistanceMod mod2 = new CustomResistanceMod( dark, ResistType.Slashing, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod2 );
                //CustomResistanceMod mod3 = new CustomResistanceMod( dark, ResistType.Piercing, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod3 );
                //CustomResistanceMod mod4 = new CustomResistanceMod( dark, ResistType.Fire, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod4 );
                //CustomResistanceMod mod5 = new CustomResistanceMod( dark, ResistType.Cold, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod5 );
                //CustomResistanceMod mod6 = new CustomResistanceMod( dark, ResistType.Acid, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod6 );
                //CustomResistanceMod mod7 = new CustomResistanceMod( dark, ResistType.Poison, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod7 );
                //CustomResistanceMod mod8 = new CustomResistanceMod( dark, ResistType.Energy, "MagicBuff", -25, duration, false);
                //dark.AddResistMod( mod8 );

				double sl = (GetResistSkill(m));
				if(sl > Utility.Random(50, 200))
				{
					dark.Sleep( duration );
					dark.PlaySound( 0x204 );
					dark.SendMessage("You've fainted in fear!");
					Caster.SendMessage("You have made " + dark.Name + " faint magically");
				}
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private PutridHuskSpell m_Owner;

			public InternalTarget( PutridHuskSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
					m_Owner.Target( (Mobile) o );
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
