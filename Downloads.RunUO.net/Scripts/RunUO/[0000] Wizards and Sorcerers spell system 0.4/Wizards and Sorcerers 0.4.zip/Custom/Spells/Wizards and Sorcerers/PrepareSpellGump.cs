using System;
using Server;
using Server.Gumps;
using Server.Mobiles;
using Server.Network;
using System.Collections;
using Server.Spells;
using Server.Spells.Magician;
using Server.Commands;

namespace Server.Gumps
{
	public class PrepareSpellGump : Gump
	{
		
		public static void Initialize()
		{
            CommandSystem.Register("PrepareSpell", AccessLevel.Player, new CommandEventHandler(PrepareSpells_OnCommand));
		}
		
		[Usage( "PrepareSpell" )]
		[Description( "Lets a Wizard prepare a spell from his spell list." )]
		private static void PrepareSpells_OnCommand( CommandEventArgs e )
		{
			PolyGlotMobile dark = e.Mobile as PolyGlotMobile;
			
			if ((dark.Class == ClassType.Wizard)&&(dark.Alive))
			{
				dark.CloseGump( typeof( PrepareSpellGump ) );
				dark.SendGump( new PrepareSpellGump(dark) );
			}
			else
				dark.SendMessage("That is not a command.");
		}
		
		
		
		public PrepareSpellGump(PolyGlotMobile dark)
			: base( 0, 0 )
		{
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			
			this.AddPage(1);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 21, 10441);
			this.AddLabel(216, 45, 5, @"Wizard Spell Preparation");
			this.AddButton(230, 80, 22151, 22150, 50, GumpButtonType.Page, 2);
			this.AddButton(230, 120, 22151, 22150, 51, GumpButtonType.Page, 3);
			this.AddButton(230, 160, 22151, 22150, 52, GumpButtonType.Page, 4);
			this.AddButton(230, 200, 22151, 22150, 53, GumpButtonType.Page, 5);
			this.AddButton(230, 240, 22151, 22150, 54, GumpButtonType.Page, 6);
			this.AddButton(230, 280, 22151, 22150, 55, GumpButtonType.Page, 7);
			this.AddButton(230, 320, 22151, 22150, 56, GumpButtonType.Page, 8);
			this.AddButton(230, 360, 22151, 22150, 57, GumpButtonType.Page, 9);
			this.AddLabel(252, 78, 6, @"Level One Spells");
			this.AddLabel(252, 118, 7, @"Level Two Spells");
			this.AddLabel(252, 158, 9, @"Level Three Spells");
			this.AddLabel(252, 198, 11, @"Level Four Spells");
			this.AddLabel(252, 238, 13, @"Level Five Spells");
			this.AddLabel(252, 278, 16, @"Level Six Spells");
			this.AddLabel(252, 318, 19, @"Level Seven Spells");
			this.AddLabel(252, 358, 26, @"Level Eight Spells");
			this.AddImage(170, 58, 113);
			this.AddImage(384, 57, 113);
			this.AddImage(172, 96, 10464);
			this.AddImage(172, 149, 10464);
			this.AddImage(172, 202, 10464);
			this.AddImage(172, 254, 10464);
			this.AddImage(413, 19, 10441);
			this.AddImage(386, 96, 10464);
			this.AddImage(386, 149, 10464);
			this.AddImage(386, 202, 10464);
			this.AddImage(386, 254, 10464);
			this.AddImage(172, 307, 10464);
			this.AddImage(386, 306, 10464);
			
			this.AddPage(2);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(234, 43, 6, @"Level One Spells");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 1);
			this.AddButton(385, 52, 4005, 4007, 0, GumpButtonType.Page, 3);
			
			for (int i = 0; i<12; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 1 + i, GumpButtonType.Reply, i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 1, i));
				if (dark.SpellsKnown.LevelOne[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}
		
			this.AddPage(3);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddLabel(234, 43, 7, @"Level Two Spells");
			this.AddImage(194, 47, 113);
			this.AddImage(346, 47, 113);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 2);
			this.AddButton(385, 52, 4005, 4007, 0, GumpButtonType.Page, 4);
			
			for (int i = 0; i<10; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 13 + i, GumpButtonType.Reply, 12 + i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 2, i));
				if (dark.SpellsKnown.LevelTwo[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}
			
			this.AddPage(4);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddLabel(234, 43, 9, @"Level Three Spells");
			this.AddImage(194, 47, 113);
			this.AddImage(346, 47, 113);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 3);
			this.AddButton(385, 52, 4005, 4007, 0, GumpButtonType.Page, 5);
			
			for (int i = 0; i<7; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 23 + i, GumpButtonType.Reply, 22 + i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 3, i));
				if (dark.SpellsKnown.LevelThree[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}

			
			this.AddPage(5);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddLabel(234, 43, 11, @"Level Four Spells");
			this.AddImage(194, 47, 113);
			this.AddImage(346, 47, 113);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 4);
			this.AddButton(385, 52, 4005, 4007, 0, GumpButtonType.Page, 6);
			
			for (int i = 0; i<5; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 30 + i, GumpButtonType.Reply, 29 + i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 4, i));
				if (dark.SpellsKnown.LevelFour[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}
			
			this.AddPage(6);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddLabel(234, 43, 13, @"Level Five Spells");
			this.AddImage(194, 47, 113);
			this.AddImage(346, 47, 113);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 5);
			this.AddButton(385, 52, 4005, 4007, 0, GumpButtonType.Page, 7);
			
			for (int i = 0; i<4; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 35 + i, GumpButtonType.Reply, 34 + i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 5, i));
				if (dark.SpellsKnown.LevelFive[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}
			
			this.AddPage(7);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddLabel(234, 43, 16, @"Level Six Spells");
			this.AddImage(194, 47, 113);
			this.AddImage(346, 47, 113);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 6);
			this.AddButton(385, 52, 4005, 4007, 0, GumpButtonType.Page, 8);
			
			for (int i = 0; i<3; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 39 + i, GumpButtonType.Reply, 38 + i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 6, i));
				if (dark.SpellsKnown.LevelSix[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}
			
			this.AddPage(8);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddLabel(231, 43, 19, @"Level Seven Spells");
			this.AddImage(194, 47, 113);
			this.AddImage(350, 47, 113);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 7);
			this.AddButton(385, 52, 4005, 4007, 0, GumpButtonType.Page, 9);
			
			for (int i = 0; i<2; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 42 + i, GumpButtonType.Reply, 41 + i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 7, i));
				if (dark.SpellsKnown.LevelSeven[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}
			
			this.AddPage(9);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddLabel(234, 43, 26, @"Level Eight Spells");
			this.AddImage(194, 47, 113);
			this.AddImage(348, 47, 113);
			this.AddButton(161, 52, 4014, 4016, 0, GumpButtonType.Page, 8);
			
			for (int i = 0; i<1; i++)
			{
				this.AddButton(176, 82+(26*i), 22151, 22150, 44 + i, GumpButtonType.Reply, 43 + i);
				this.AddLabel(196, 81+(26*i), 0, ComputeSpellName(dark, 8, i));
				if (dark.SpellsKnown.LevelEight[i].IsPrepared)
					this.AddLabel(329, 82+(26*i), 0, @"Prepared");
				else
					this.AddLabel(329, 82+(26*i), 0, @"Not Ready");
			}

		}
		
		public string ComputeSpellName(PolyGlotMobile dark, int level, int slot)
		{
			switch(level)
			{
				case 1:
					{
						int spellnum = dark.SpellsKnown.LevelOne[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
						
//						if (dark.SpellsKnown.LevelOne[slot].spell == 500)
//							return "Magic Missile";

					}
				case 2:
					{
						int spellnum = dark.SpellsKnown.LevelTwo[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
						
//						if (dark.SpellsKnown.LevelTwo[slot].spell == 501)
//							return "Fire Blast";
						
						
					}
				case 3:
					{
						int spellnum = dark.SpellsKnown.LevelThree[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
						
//						if (dark.SpellsKnown.LevelThree[slot].spell == 502)
//							return "Lightning Bolt";
							
					}
				case 4:
					{
						int spellnum = dark.SpellsKnown.LevelFour[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
						
//						if (dark.SpellsKnown.LevelFour[slot].spell == 504)
//							return "Explosion";
						
					}
				case 5:
					{
						int spellnum = dark.SpellsKnown.LevelFive[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
						
//						if (dark.SpellsKnown.LevelFive[slot].spell == 508)
//							return "Energy Bolt";		
					}
				case 6:
					{
						int spellnum = dark.SpellsKnown.LevelSix[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
						
//						if (dark.SpellsKnown.LevelSix[slot].spell == 506)
//							return "Chain Lightning";
						
						
					}
				case 7:
					{
						int spellnum = dark.SpellsKnown.LevelSeven[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
					}
				case 8:
					{
						int spellnum = dark.SpellsKnown.LevelEight[slot].spell;
						
						if ((spellnum < 300)||(spellnum >=400))
						{	
							return "null";
						}
						
						Spell spell = SpellRegistry.NewSpell( spellnum, dark as Mobile, null );		
						return spell.Name;
						
//						if (dark.SpellsKnown.LevelEight[slot].spell == 507)
//							return "Tremor";
						
					}
				
				default:
					return "null";
			}
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			PolyGlotMobile dark = state.Mobile as PolyGlotMobile;

			switch ( info.ButtonID )
			{
				// Level One Responses:
				case 1:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 0, dark));
						break;
					}
					
				case 2:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 1, dark));
						break;
					}
					
				case 3:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 2, dark));
						break;
					}
					
				case 4:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 3, dark));
						break;
					}
					
				case 5:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 4, dark));
						break;
					}
					
				case 6:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 5, dark));
						break;
					}
					
				case 7:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 6, dark));
						break;
					}
					
				case 8:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 7, dark));
						break;
					}
				
				case 9:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 8, dark));
						break;
					}
					
				case 10:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 9, dark));
						break;
					}
				
				case 11:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 10, dark));
						break;
					}
					
				case 12:
					{
						dark.SendGump( new PrepareLevelSpellGump(1, 11, dark));
						break;
					}
				
				// Level Two Responses:	
				case 13:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 0, dark));
						break;
					}
					
				case 14:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 1, dark));
						break;
					}
					
				case 15:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 2, dark));
						break;
					}
					
				case 16:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 3, dark));
						break;
					}
					
				case 17:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 4, dark));
						break;
					}
					
				case 18:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 5, dark));
						break;
					}
				
				case 19:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 6, dark));
						break;
					}
					
				case 20:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 7, dark));
						break;
					}
				
				case 21:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 8, dark));
						break;
					}
					
				case 22:
					{
						dark.SendGump( new PrepareLevelSpellGump(2, 9, dark));
						break;
					}
				
				// Level Three Responses:
				case 23:
					{
						dark.SendGump( new PrepareLevelSpellGump(3, 0, dark));
						break;
					}
					
				case 24:
					{
						dark.SendGump( new PrepareLevelSpellGump(3, 1, dark));
						break;
					}
					
				case 25:
					{
						dark.SendGump( new PrepareLevelSpellGump(3, 2, dark));
						break;
					}
					
				case 26:
					{
						dark.SendGump( new PrepareLevelSpellGump(3, 3, dark));
						break;
					}
					
				case 27:
					{
						dark.SendGump( new PrepareLevelSpellGump(3, 4, dark));
						break;
					}
				
				case 28:
					{
						dark.SendGump( new PrepareLevelSpellGump(3, 5, dark));
						break;
					}
				
				case 29:
					{
						dark.SendGump( new PrepareLevelSpellGump(3, 6, dark));
						break;
					}
				
				// Level Four Responses:
				case 30:
					{
						dark.SendGump( new PrepareLevelSpellGump(4, 0, dark));
						break;
					}
					
				case 31:
					{
						dark.SendGump( new PrepareLevelSpellGump(4, 1, dark));
						break;
					}
				
				case 32:
					{
						dark.SendGump( new PrepareLevelSpellGump(4, 2, dark));
						break;
					}
				
				case 33:
					{
						dark.SendGump( new PrepareLevelSpellGump(4, 3, dark));
						break;
					}
					
				case 34:
					{
						dark.SendGump( new PrepareLevelSpellGump(4, 4, dark));
						break;
					}
				
				// Level Five Responses:
				case 35:
					{
						dark.SendGump( new PrepareLevelSpellGump(5, 0, dark));
						break;
					}
					
				case 36:
					{
						dark.SendGump( new PrepareLevelSpellGump(5, 1, dark));
						break;
					}
				
				case 37:
					{
						dark.SendGump( new PrepareLevelSpellGump(5, 2, dark));
						break;
					}
					
				case 38:
					{
						dark.SendGump( new PrepareLevelSpellGump(5, 3, dark));
						break;
					}
				
				// Level Six Responses:
				case 39:
					{
						dark.SendGump( new PrepareLevelSpellGump(6, 0, dark));
						break;
					}
				
				case 40:
					{
						dark.SendGump( new PrepareLevelSpellGump(6, 1, dark));
						break;
					}
				
				case 41:
					{
						dark.SendGump( new PrepareLevelSpellGump(6, 2, dark));
						break;
					}
				
				// Level Seven Responses:
				case 42:
					{
						dark.SendGump( new PrepareLevelSpellGump(7, 0, dark));
						break;
					}
				case 43:
					{
						dark.SendGump( new PrepareLevelSpellGump(7, 1, dark));
						break;
					}
					
				// Level Eight Responses:	
				case 44:
					{
						dark.SendGump( new PrepareLevelSpellGump(8, 0, dark));
						break;
					}
					
				default:
					break;
					
					
			}
		}
	}
	
	public class PrepareLevelSpellGump : Gump
	{
		private int[] spells;
		private int spellslevel;
		private int spellslot;
		private Mobile dude;
		
		public PrepareLevelSpellGump(int level, int slot, PolyGlotMobile dark) : base( 0, 0 )
		{
			dude = dark as Mobile;
			spellslevel = level;
			spellslot = slot;
			int counter = 0;
			int spacing = 40;
			ArrayList temp = new ArrayList();
			
			int[] knownspells = dark.SpellsKnown.GenerateArrayOfSpells();
			
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			this.AddPage(1);
			this.AddBackground(203, 32, 185, 370, 9260);
			this.AddLabel(251, 47, 5, @"Choose a spell");
			this.AddLabel(234, 67, 5, @"To Begin to Prepare");
			switch(level)
			{
				case 1:
					{
						this.AddLabel(246, 90, 5, @"Level One Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
							if (((MagicianSpell)spell).SpellLevel == SpellCircle.First)
								temp.Add(knownspells[i]);
						}
						break;		
					}
				case 2:
					{
						this.AddLabel(246, 90, 5, @"Level Two Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
                            if (((MagicianSpell)spell).SpellLevel == SpellCircle.Second)
								temp.Add(knownspells[i]);
						}
						
						break;
					}
				case 3:
					{
						this.AddLabel(246, 90, 5, @"Level Three Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
                            if (((MagicianSpell)spell).SpellLevel == SpellCircle.Third)
								temp.Add(knownspells[i]);
						}
						
						break;		
					}
				case 4:
					{
						this.AddLabel(246, 90, 5, @"Level Four Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
                            if (((MagicianSpell)spell).SpellLevel == SpellCircle.Fourth)
								temp.Add(knownspells[i]);
						}
						
						break;
					}
				case 5:
					{
						this.AddLabel(246, 90, 5, @"Level Five Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
                            if (((MagicianSpell)spell).SpellLevel == SpellCircle.Fifth)
								temp.Add(knownspells[i]);
						}
						
						break;		
					}
				case 6:
					{
						this.AddLabel(246, 90, 5, @"Level Six Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
                            if (((MagicianSpell)spell).SpellLevel == SpellCircle.Sixth)
								temp.Add(knownspells[i]);
						}
						
						break;
					}
				case 7:
					{
						this.AddLabel(246, 90, 5, @"Level Seven Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
                            if (((MagicianSpell)spell).SpellLevel == SpellCircle.Seventh)
								temp.Add(knownspells[i]);
						}
						
						break;		
					}
				case 8:
					{
						this.AddLabel(246, 90, 5, @"Level Eight Spells");
						
						for( int i = 0; i < knownspells.Length; i++)
						{
							Spell spell = SpellRegistry.NewSpell( knownspells[i], dude, null );
                            if (((MagicianSpell)spell).SpellLevel == SpellCircle.Eighth)
								temp.Add(knownspells[i]);
						}
						
						break;
					}
				
				default:
					break;
			}
			
			spells = new int[temp.Count];
			counter = temp.Count;
			if( temp.Count > 0 )
			{
				for (int i = 0; i < temp.Count; i++)
				{
					spells[i] = (int)temp[i];
				}
			}

			for (int i = 0; i < 6; i++)
			{
				if (counter > 0)
				{
					this.AddButton(230, 160 + (i*spacing), 22151, 22150, i+1, GumpButtonType.Reply, i);
					this.AddLabel(252, 158 + (i*spacing), 5, ComputeSpellName(spells[i]));
					counter--;
				}
			}


            if (counter == 0)
            {
                this.AddButton(340, 120, 4005, 4006, 41, GumpButtonType.Page, 2);

                this.AddPage(2);
                this.AddBackground(203, 32, 185, 370, 9260);
                this.AddButton(220, 120, 4014, 4015, 42, GumpButtonType.Page, 1);
                this.AddLabel(251, 47, 5, @"You do not know any spells");
                this.AddLabel(234, 67, 5, @"of this level!");
                this.AddButton(230, 160, 22151, 22150, 999, GumpButtonType.Reply, 18);
                this.AddLabel(252, 158, 5, "Click here to go back.");
            }

			if(counter > 0)
			{
				this.AddButton(340, 120, 4005, 4006, 37, GumpButtonType.Page, 2);
				
				this.AddPage(2);
				this.AddBackground(203, 32, 185, 370, 9260);
				this.AddButton(220, 120, 4014, 4015, 38, GumpButtonType.Page, 1);
				this.AddLabel(251, 47, 5, @"Choose a spell");
				this.AddLabel(234, 67, 5, @"To Begin to Prepare");
				
				for (int i = 0; i < 6; i++)
				{
					if (counter > 0)
					{
						this.AddButton(230, 160 + (i*spacing), 22151, 22150, i+7, GumpButtonType.Reply, i+6);
						this.AddLabel(252, 158 + (i*spacing), 5, ComputeSpellName(spells[i+6]));
						counter--;
					}
				}	
			}
				
		}
		
		public string ComputeSpellName(int spellnumber)
		{
						
			if ((spellnumber < 300)||(spellnumber >=400))
			{	
				return "null";
			}
						
			Spell spell = SpellRegistry.NewSpell( spellnumber, dude, null );		
			return spell.Name;
			
			
//			switch(spellnumber)
//			{
//				case 500:
//					return "Magic Missile";		
//				default:
//					return "null";
//			}
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			PolyGlotMobile dark = state.Mobile as PolyGlotMobile;

			switch ( info.ButtonID )
			{
				case 0:
					{
						break;
					}
				case 37:
					{
						break;
					}
					
				case 38:
					{
						break;
					}
					
				case 39:
					{
						break;
					}
					
				case 40:
					{
						break;
					}
					
				case 41:
					{
						break;
					}
					
				case 42:
					{
						break;
					}
					
				case 43:
					{
						break;
					}
					
				case 44:
					{
						break;
					}
					
				case 45:
					{
						break;
					}	
				case 46:
					{
						break;
					}
				case 47:
					{
						break;
					}
                case 999:
                    {
                        dark.SendGump(new PrepareSpellGump(dark));
                        break;
                    }
				default:
					{
						dark.SpellsKnown.PrepareSpell(dark, spells[info.ButtonID-1], this.spellslevel, this.spellslot);
						dark.SendGump( new PrepareSpellGump(dark) );
						break;
					}
			}
		}
		
	}
}
