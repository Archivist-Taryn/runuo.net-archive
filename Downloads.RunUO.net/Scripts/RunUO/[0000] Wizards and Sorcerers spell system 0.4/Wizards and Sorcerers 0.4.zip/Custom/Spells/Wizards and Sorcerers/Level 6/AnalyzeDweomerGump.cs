using System;
using Server;
using Server.Gumps;
using Server.Mobiles;

namespace Server.Gumps
{
	public class AnalyzeDweomerGump : Gump
	{
		public AnalyzeDweomerGump(PolyGlotMobile target)
			: base( 0, 0 )
		{
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			this.AddPage(0);
			this.AddBackground(86, 90, 220, 254, 9270);
			this.AddLabel(144, 105, 0, @"Analyze Dweomer");
			string Str = Convert.ToString(target.Str);
			string Dex = Convert.ToString(target.Dex);
			string Intl = Convert.ToString(target.Int);
			string Name = Convert.ToString(target.Name);
			string Fire = Convert.ToString(target.FireResistance);
			string Cold = Convert.ToString(target.ColdResistance);
			string Energy = Convert.ToString(target.EnergyResistance);
			string Physical = Convert.ToString(target.PhysicalResistance); 
			string Poison = Convert.ToString(target.PoisonResistance); 
			this.AddHtml( 116, 142, 161, 152, @"Name: " + Name + "<br><br>" + "Str: " + Str + "<br>" + "Dex: " + Dex + "<br>" + "Int: " + Intl + "<br><br>" + "Fire: " + Fire + "<br>" + "Cold: " + Cold + "<br>" + "Energy: " + Energy + "<br>" + "Physical: " + Physical + "<br>" + "Poison: " + Poison, (bool)true, (bool)true);

		}
		

	}
}