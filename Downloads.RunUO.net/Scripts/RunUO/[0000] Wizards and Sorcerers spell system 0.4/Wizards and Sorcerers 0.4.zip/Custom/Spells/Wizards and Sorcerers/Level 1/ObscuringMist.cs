using System;
using Server;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Misc;
using Server.Items;
using System.Collections;

namespace Server.Spells.Magician
{
	public class ObscuringMistSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Obscuring Mist", "Mit Insisen Lorlocrener",
				Reagent.BloodSpawn,
				Reagent.SpidersSilk
			);

		public override string Desc{ get{ return "Summons a source of darkness to center on the Caster."; } } 
       	public override string ReagentsDesc{ get{ return "One SulfurousAsh."; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 15.0; } }
		public override int RequiredMana{ get{ return 10; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 360; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }

		public ObscuringMistSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				int ticks = ( Caster.Int * 2 );
				new ObscuringMistTimer(Caster, ticks).Start();
				Caster.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
				Caster.PlaySound( 0x1EE );
			}
			FinishSequence();
		}

		private class ObscuringMistTimer : Timer
		{
			private Mobile Caster;
			public ObscuringMistTimer( Mobile m_caster, int ticks ) : base( TimeSpan.Zero, TimeSpan.FromSeconds(1), ticks )
			{
				Caster = m_caster;
			}	
			protected override void OnTick()
			{
				for ( int i = 0; i <= 5; ++i )
				{
					Point3D p;
					switch(i)
					{
						case 0:
							p = new Point3D( Caster.X , Caster.Y , Caster.Z );
						break;
						case 1:
							p = new Point3D( Caster.X - 1 , Caster.Y , Caster.Z );
						break;
						case 2:
							p = new Point3D( Caster.X , Caster.Y - 1 , Caster.Z );
						break;
						case 3:
							p = new Point3D( Caster.X , Caster.Y + 1 , Caster.Z );
						break;
						case 4:
							p = new Point3D( Caster.X + 1 , Caster.Y , Caster.Z );
						break;
						default:
							p = new Point3D( Caster.X , Caster.Y , Caster.Z );
						break;
					}
					Effects.SendLocationEffect( new Point3D( p.X + 1, p.Y, p.Z + 4 ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X + 1, p.Y, p.Z ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X + 1, p.Y, p.Z - 4 ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X, p.Y + 1, p.Z + 4 ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X, p.Y + 1, p.Z ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X, p.Y + 1, p.Z - 4 ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X + 1, p.Y + 1, p.Z + 11 ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X + 1, p.Y + 1, p.Z + 7 ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X + 1, p.Y + 1, p.Z + 3 ), Caster.Map, 0x3728, 13 );
					Effects.SendLocationEffect( new Point3D( p.X + 1, p.Y + 1, p.Z - 1 ), Caster.Map, 0x3728, 13 );
				}
			}
		}
	}
}


