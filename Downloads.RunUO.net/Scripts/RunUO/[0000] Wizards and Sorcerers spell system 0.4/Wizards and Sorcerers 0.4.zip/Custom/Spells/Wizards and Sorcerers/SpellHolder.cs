using System;
using Server;
using System.Collections;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Spells.Magician;

namespace Server.Spells
{
	public class SpellHolder
	{
		private ArrayList KnownSpellTypes;
        private SpellSchool m_Specialized;
		
		public WizardSpellPrep[] LevelOne;
		public WizardSpellPrep[] LevelTwo;
		public WizardSpellPrep[] LevelThree;
		public WizardSpellPrep[] LevelFour;
		public WizardSpellPrep[] LevelFive;
		public WizardSpellPrep[] LevelSix;
		public WizardSpellPrep[] LevelSeven;
		public WizardSpellPrep[] LevelEight;


        [CommandProperty(AccessLevel.GameMaster)]
		public  SpellSchool Specialized
        {
            get { return m_Specialized; }
            set { m_Specialized = value; }
        }
		
		public bool CheckForPreparedSpell(PolyGlotMobile Caster, int Spelltype)
		{
            Spell mspell = SpellRegistry.NewSpell( Spelltype, Caster as Mobile, null );
            int level = (int)((MagicianSpell)mspell).SpellLevel + 1;

			switch( level )
			{
				case 1:
				{
					for (int i = 0; i<Caster.SpellsKnown.LevelOne.Length; i++)
					{
						if ((LevelOne[i].IsPrepared) && (LevelOne[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
				
				case 2:
				{
					for (int i = 0; i<LevelTwo.Length; i++)
					{
						if ((LevelTwo[i].IsPrepared) && (LevelTwo[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
				
				case 3:
				{
					for (int i = 0; i<LevelThree.Length; i++)
					{
						if ((LevelThree[i].IsPrepared) && (LevelThree[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
					
				case 4:
				{
					for (int i = 0; i<LevelFour.Length; i++)
					{
						if ((LevelFour[i].IsPrepared) && (LevelFour[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
				
				case 5:
				{
					for (int i = 0; i<LevelFive.Length; i++)
					{
						if (LevelFive[i].IsPrepared && (LevelFive[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
				
				case 6:
				{
					for (int i = 0; i<LevelSix.Length; i++)
					{
						if (LevelSix[i].IsPrepared && (LevelSix[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
				
				case 7:
				{
					for (int i = 0; i<LevelSeven.Length; i++)
					{
						if (LevelSeven[i].IsPrepared && (LevelSeven[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
				
				case 8:
				{
					for (int i = 0; i<LevelEight.Length; i++)
					{
						if (LevelEight[i].IsPrepared && (LevelEight[i].spell == Spelltype))
						{
							return true;
						}
					}
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
				
				default:
				{
					Caster.SendMessage("You do not have that spell prepared!");
					return false;
				}
			}
		}
		
		public void PrepareSpell(PolyGlotMobile Caster, int Spelltype, int level, int slot )
		{
			switch(level)
			{
				case 1:
					{
						TimeSpan ugh = new TimeSpan(0,1,0);
						if (!LevelOne[slot].IsPrepared)
							LevelOne[slot].TimerStop();
			
						LevelOne[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);
						break;
					}
				case 2:
					{
						TimeSpan ugh = new TimeSpan(0,10,0);
						if (!LevelTwo[slot].IsPrepared)
							LevelTwo[slot].TimerStop();
			
						LevelTwo[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);
						break;
					}
				case 3:
					{
						TimeSpan ugh = new TimeSpan(0,20,0);
						if (!LevelThree[slot].IsPrepared)
							LevelThree[slot].TimerStop();
			
						LevelThree[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);
						break;
					}
				case 4:
					{
						TimeSpan ugh = new TimeSpan(0,30,0);
						if (!LevelFour[slot].IsPrepared)
							LevelFour[slot].TimerStop();
			
						LevelFour[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);
						break;
					}
				case 5:
					{
						TimeSpan ugh = new TimeSpan(0,40,0);
						if (!LevelFive[slot].IsPrepared)
							LevelFive[slot].TimerStop();
			
						LevelFive[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);
						break;
					}
				case 6:
					{
						TimeSpan ugh = new TimeSpan(0,50,0);
						if (!LevelSix[slot].IsPrepared)
							LevelSix[slot].TimerStop();
			
						LevelSix[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);	
						break;
					}
				case 7:
					{
						TimeSpan ugh = new TimeSpan(1,0,0);
						if (!LevelSeven[slot].IsPrepared)
							LevelSeven[slot].TimerStop();
			
						LevelSeven[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);
						break;
					}
				case 8:
					{
						TimeSpan ugh = new TimeSpan(1,30,0);
						if (!LevelEight[slot].IsPrepared)
							LevelEight[slot].TimerStop();
			
						LevelEight[slot].SpellPrepInitialize(Caster, Spelltype, ugh, level, slot);
						break;
					}
				default:
					break;
			}
		}

        public void UseSpell(PolyGlotMobile Caster, int SpellType)
        {
            Spell mspell = SpellRegistry.NewSpell( SpellType, Caster as Mobile, null );

            int level = (int)((MagicianSpell)mspell).SpellLevel + 1;

            switch (level)
            {
                case 1:
                    {
                        for(int i = 0; i < this.LevelOne.Length; i++)
					    {
                            if (LevelOne[i].spell == SpellType)
                            {
                                LevelOne[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                case 2:
                    {
                        for (int i = 0; i < this.LevelTwo.Length; i++)
                        {
                            if (LevelTwo[i].spell == SpellType)
                            {
                                LevelTwo[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                case 3:
                    {
                        for (int i = 0; i < this.LevelThree.Length; i++)
                        {
                            if (LevelThree[i].spell == SpellType)
                            {
                                LevelThree[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                case 4:
                    {
                        for (int i = 0; i < this.LevelFour.Length; i++)
                        {
                            if (LevelFour[i].spell == SpellType)
                            {
                                LevelFour[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                case 5:
                    {
                        for (int i = 0; i < this.LevelFive.Length; i++)
                        {
                            if (LevelFive[i].spell == SpellType)
                            {
                                LevelFive[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                case 6:
                    {
                        for (int i = 0; i < this.LevelSix.Length; i++)
                        {
                            if (LevelSix[i].spell == SpellType)
                            {
                                LevelSix[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                case 7:
                    {
                        for (int i = 0; i < this.LevelSeven.Length; i++)
                        {
                            if (LevelSeven[i].spell == SpellType)
                            {
                                LevelSeven[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                case 8:
                    {
                        for (int i = 0; i < this.LevelEight.Length; i++)
                        {
                            if (LevelEight[i].spell == SpellType)
                            {
                                LevelEight[i] = new WizardSpellPrep();
                                break;
                            }
                        }
                        break;
                    }
                default:
                    break;
            }
        }

		public void Add(PolyGlotMobile Caster, int Spelltype)
		{
			Caster.CloseGump( typeof( MagicianSpellbookGump ) );
			if ( HasSpell( Spelltype ) )
			{
				Caster.SendLocalizedMessage( 500179 ); // That spell is already present in that spellbook.
				return;
			}
			else
			{
				KnownSpellTypes.Add( Spelltype );
			}
				
		}
		
		public void Remove(PolyGlotMobile Caster, int Spelltype)
		{
			Caster.CloseGump( typeof( MagicianSpellbookGump ) );
			if ( !HasSpell( Spelltype ) )
			{
				Caster.SendMessage("You do not know that spell anyways.");
				return;
			}
			else
			{
				KnownSpellTypes.Remove( Spelltype );
			}

		}
		
		public bool HasSpell(int m_SpellType)
		{
			return KnownSpellTypes.Contains(m_SpellType);
		}
		
		public void RemoveAllSpells()
		{
			KnownSpellTypes.Clear();
			for(int i = 0; i < 15; i++)
			{
				LevelOne[i].TimerStop();
			}
			for(int i = 0; i < 13; i++)
			{
				LevelTwo[i].TimerStop();
			}
			for(int i = 0; i < 10; i++)
			{
				LevelThree[i].TimerStop();
			}
			for(int i = 0; i < 8; i++)
			{
				LevelFour[i].TimerStop();
			}
			for(int i = 0; i < 6; i++)
			{
				LevelFive[i].TimerStop();
			}
			for(int i = 0; i < 5; i++)
			{
				LevelSix[i].TimerStop();
			}
			for(int i = 0; i < 3; i++)
			{
				LevelSeven[i].TimerStop();
			}
			for(int i = 0; i < 2; i++)
			{
				LevelEight[i].TimerStop();
			}
			
			LevelOne = new WizardSpellPrep[15];
			LevelTwo = new WizardSpellPrep[13];
			LevelThree = new WizardSpellPrep[10];
			LevelFour = new WizardSpellPrep[8];
			LevelFive = new WizardSpellPrep[6];
			LevelSix = new WizardSpellPrep[5];
			LevelSeven = new WizardSpellPrep[3];
			LevelEight = new WizardSpellPrep[2];
			
			for( int i = 0; i < LevelOne.Length; i++ )
			{
				LevelOne[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelTwo.Length; i++ )
			{
				LevelTwo[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelThree.Length; i++ )
			{
				LevelThree[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelFour.Length; i++ )
			{
				LevelFour[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelFive.Length; i++ )
			{
				LevelFive[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelSix.Length; i++ )
			{
				LevelSix[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelSeven.Length; i++ )
			{
				LevelSeven[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelEight.Length; i++ )
			{
				LevelEight[i] = new WizardSpellPrep();
			}
		}
		
		
		public int[] GenerateArrayOfSpells()
		{
			int[] spells = new int[KnownSpellTypes.Count];
			
			for ( int i = 0; i < KnownSpellTypes.Count; ++i )
			{
				spells[i] = (int)KnownSpellTypes[i];
			}
			
			return spells;
		}

		public SpellSchool[] OppositeSchool()
		{
			switch( this.Specialized )
			{
				case SpellSchool.Abjuration:
					{
						SpellSchool[] schools = new SpellSchool[1];
						schools[0] = SpellSchool.Transmutation;
						return schools;
					}
				case SpellSchool.Conjuration:
					{
						SpellSchool[] schools = new SpellSchool[1];
						schools[0] = SpellSchool.Divination;
						return schools;
					}
				case SpellSchool.Divination:
					{
						SpellSchool[] schools = new SpellSchool[1];
						schools[0] = SpellSchool.Conjuration;
						return schools;
					}
				case SpellSchool.Enchantment:
					{
						SpellSchool[] schools = new SpellSchool[1];
						schools[0] = SpellSchool.Evocation;
						return schools;
					}
				case SpellSchool.Evocation:
					{
						SpellSchool[] schools = new SpellSchool[2];
						schools[0] = SpellSchool.Enchantment;
						schools[1] = SpellSchool.Conjuration;
						return schools;
					}
				case SpellSchool.Illusion:
					{
						SpellSchool[] schools = new SpellSchool[1];
						schools[0] = SpellSchool.Necromancy;
						return schools;
					}
				case SpellSchool.Necromancy:
					{
						SpellSchool[] schools = new SpellSchool[1];
						schools[0] = SpellSchool.Illusion;
						return schools;
					}
				case SpellSchool.Transmutation:
					{
						SpellSchool[] schools = new SpellSchool[1];
						schools[0] = SpellSchool.Abjuration;
						return schools;
					}
				default:
					{
                        return null;
					}
			}
		}
		

		public SpellHolder()
		{
			KnownSpellTypes = new ArrayList();
			
			LevelOne = new WizardSpellPrep[15];
			LevelTwo = new WizardSpellPrep[13];
			LevelThree = new WizardSpellPrep[10];
			LevelFour = new WizardSpellPrep[8];
			LevelFive = new WizardSpellPrep[6];
			LevelSix = new WizardSpellPrep[5];
			LevelSeven = new WizardSpellPrep[3];
			LevelEight = new WizardSpellPrep[2];

            m_Specialized = SpellSchool.Universal;
			
			
			for( int i = 0; i < LevelOne.Length; i++ )
			{
				LevelOne[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelTwo.Length; i++ )
			{
				LevelTwo[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelThree.Length; i++ )
			{
				LevelThree[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelFour.Length; i++ )
			{
				LevelFour[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelFive.Length; i++ )
			{
				LevelFive[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelSix.Length; i++ )
			{
				LevelSix[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelSeven.Length; i++ )
			{
				LevelSeven[i] = new WizardSpellPrep();
			}
			
			for( int i = 0; i < LevelEight.Length; i++ )
			{
				LevelEight[i] = new WizardSpellPrep();
			}	
		
		}
		
		public SpellHolder( GenericReader reader, PolyGlotMobile Caster )
		{
			KnownSpellTypes = new ArrayList();
			
			LevelOne = new WizardSpellPrep[15];
			LevelTwo = new WizardSpellPrep[13];
			LevelThree = new WizardSpellPrep[10];
			LevelFour = new WizardSpellPrep[8];
			LevelFive = new WizardSpellPrep[6];
			LevelSix = new WizardSpellPrep[5];
			LevelSeven = new WizardSpellPrep[3];
			LevelEight = new WizardSpellPrep[2];

            for (int i = 0; i < LevelOne.Length; i++)
            {
                LevelOne[i] = new WizardSpellPrep();
            }

            for (int i = 0; i < LevelTwo.Length; i++)
            {
                LevelTwo[i] = new WizardSpellPrep();
            }

            for (int i = 0; i < LevelThree.Length; i++)
            {
                LevelThree[i] = new WizardSpellPrep();
            }

            for (int i = 0; i < LevelFour.Length; i++)
            {
                LevelFour[i] = new WizardSpellPrep();
            }

            for (int i = 0; i < LevelFive.Length; i++)
            {
                LevelFive[i] = new WizardSpellPrep();
            }

            for (int i = 0; i < LevelSix.Length; i++)
            {
                LevelSix[i] = new WizardSpellPrep();
            }

            for (int i = 0; i < LevelSeven.Length; i++)
            {
                LevelSeven[i] = new WizardSpellPrep();
            }

            for (int i = 0; i < LevelEight.Length; i++)
            {
                LevelEight[i] = new WizardSpellPrep();
            }

            m_Specialized = SpellSchool.Universal;
			
			Deserialize( reader, Caster );
		}
		
		private void Deserialize( GenericReader reader, PolyGlotMobile Caster )
		{
			int version = reader.ReadInt();
			
			switch ( version )
			{
				case 1:
				{
                    m_Specialized = (SpellSchool)reader.ReadInt();
					goto case 0;
				}
				
				case 0:
				{
					int arrayListCount = reader.ReadInt();
					for( int i = 0; i < arrayListCount; i++ )
					{
						int type = reader.ReadInt();
						KnownSpellTypes.Add( type );
					}
					
					for( int i = 0; i < LevelOne.Length; i++ )
					{
						LevelOne[i] = new WizardSpellPrep(reader, Caster);
					}
					
					for( int i = 0; i < LevelTwo.Length; i++ )
					{
						LevelTwo[i] = new WizardSpellPrep(reader, Caster);
					}
					
					for( int i = 0; i < LevelThree.Length; i++ )
					{
						LevelThree[i] = new WizardSpellPrep(reader, Caster);
					}
					
					for( int i = 0; i < LevelFour.Length; i++ )
					{
						LevelFour[i] = new WizardSpellPrep(reader, Caster);
					}
					
					for( int i = 0; i < LevelFive.Length; i++ )
					{
						LevelFive[i] = new WizardSpellPrep(reader, Caster);
					}
					
					for( int i = 0; i < LevelSix.Length; i++ )
					{
						LevelSix[i] = new WizardSpellPrep(reader, Caster);
					}
					
					for( int i = 0; i < LevelSeven.Length; i++ )
					{
						LevelSeven[i] = new WizardSpellPrep(reader, Caster);
					}
					
					for( int i = 0; i < LevelEight.Length; i++ )
					{
						LevelEight[i] = new WizardSpellPrep(reader, Caster);
					}
					break;
				}
			}
		}
		
		public void Serialize( GenericWriter writer )
		{
			writer.Write( (int) 1 ); // version
			// version 1:

            writer.Write((int)m_Specialized);
			
			
			// version 0:
			writer.Write( (int)KnownSpellTypes.Count );
			for ( int i = 0; i < KnownSpellTypes.Count; ++i )
			{
				int Spelltype = (int)KnownSpellTypes[i];
				writer.Write( (int)Spelltype );
			}
				
			
//			IEnumerator contents = KnownSpellTypes.GetEnumerator();
//			while(contents.MoveNext())
//			{
//				int Spelltype = (int)contents.Current;
//				writer.Write( Spelltype );
//			}
			
			////////////////////////////////////
			
			for( int i = 0; i < this.LevelOne.Length; i++ )
			{
				this.LevelOne[i].Serialize( writer );
			}
			
			for( int i = 0; i < this.LevelTwo.Length; i++ )
			{
				this.LevelTwo[i].Serialize( writer );
			}
			
			for( int i = 0; i < this.LevelThree.Length; i++ )
			{
				this.LevelThree[i].Serialize( writer );
			}
			
			for( int i = 0; i < this.LevelFour.Length; i++ )
			{
				this.LevelFour[i].Serialize( writer );
			}
			
			for( int i = 0; i < this.LevelFive.Length; i++ )
			{
				this.LevelFive[i].Serialize( writer );
			}
			
			for( int i = 0; i < this.LevelSix.Length; i++ )
			{
				this.LevelSix[i].Serialize( writer );
			}
			
			for( int i = 0; i < this.LevelSeven.Length; i++ )
			{
				this.LevelSeven[i].Serialize( writer );
			}
					
			for( int i = 0; i < this.LevelEight.Length; i++ )
			{
				this.LevelEight[i].Serialize( writer );
			}
	
		}
		
	}
}
