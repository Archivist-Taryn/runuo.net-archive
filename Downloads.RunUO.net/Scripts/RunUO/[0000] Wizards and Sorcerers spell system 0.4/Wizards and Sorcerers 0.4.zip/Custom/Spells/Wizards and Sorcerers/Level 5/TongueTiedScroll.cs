using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class TongueTiedScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public TongueTiedScroll() : this( 1 )
		{
		}

		[Constructable]
		public TongueTiedScroll( int amount ) : base( 325, 0x1F2E, amount )
		{
			Name = "Tongue Tied";
		}
		
		public TongueTiedScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
