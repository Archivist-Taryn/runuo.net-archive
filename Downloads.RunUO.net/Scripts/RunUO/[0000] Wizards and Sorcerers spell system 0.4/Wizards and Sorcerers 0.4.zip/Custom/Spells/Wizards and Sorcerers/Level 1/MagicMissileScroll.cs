using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class MagicMissileScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public MagicMissileScroll() : this( 1 )
		{
		}

		[Constructable]
		public MagicMissileScroll( int amount ) : base( 300, 0x1F2E, amount )
		{
			Name = "Magic Missile";
		}
		
		public MagicMissileScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
