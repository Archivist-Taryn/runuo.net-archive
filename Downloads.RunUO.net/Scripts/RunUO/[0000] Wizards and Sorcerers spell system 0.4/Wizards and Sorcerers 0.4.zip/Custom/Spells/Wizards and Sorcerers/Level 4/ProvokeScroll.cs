using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ProvokeScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public ProvokeScroll() : this( 1 )
		{
		}

		[Constructable]
		public ProvokeScroll( int amount ) : base( 364, 0x1F2E, amount )
		{
			Name = "Provoke";
		}
		
		public ProvokeScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}

