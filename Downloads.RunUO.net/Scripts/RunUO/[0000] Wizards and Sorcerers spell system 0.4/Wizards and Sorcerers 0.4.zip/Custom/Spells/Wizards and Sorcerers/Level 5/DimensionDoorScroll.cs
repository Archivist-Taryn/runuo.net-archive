using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class DimensionDoorScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public DimensionDoorScroll() : this( 1 )
		{
		}

		[Constructable]
		public DimensionDoorScroll( int amount ) : base( 363, 0x1F2E, amount )
		{
			Name = "Dimension Door";
		}
		
		public DimensionDoorScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}

