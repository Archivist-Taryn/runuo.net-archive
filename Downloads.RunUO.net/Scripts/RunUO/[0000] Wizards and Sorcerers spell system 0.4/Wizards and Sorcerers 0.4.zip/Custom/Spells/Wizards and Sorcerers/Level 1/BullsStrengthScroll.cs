using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class BullsStrengthScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public BullsStrengthScroll() : this( 1 )
		{
		}

		[Constructable]
		public BullsStrengthScroll( int amount ) : base( 335, 0x1F2E, amount )
		{
			Name = "Bull's Strength";
		}
		
		public BullsStrengthScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
