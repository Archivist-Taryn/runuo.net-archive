using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class SummonMonster1Spell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Summon Monster One", "Culloth Minrae Ki",
				Reagent.BloodSpawn
			);

        public override int SpellNumber { get{ return 321; } }
        public override SpellCircle SpellLevel { get{ return SpellCircle.Second; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 20.0; } }
		public override int RequiredMana{ get{ return 25; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Conjuration; } }
        public override string Desc { get { return "Summons a lower creature to attack your enemies."; } }
        public override string ReagentsDesc { get { return "One BloodSpawn."; } }

		public SummonMonster1Spell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
				return false;

			if ( (Caster.Followers + 1) > Caster.FollowersMax )
			{
				Caster.SendLocalizedMessage( 1049645 ); // You have too many followers to summon that creature.
				return false;
			}

			return true;
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
                //switch( Utility.Random( 3 ) )
                //{
                //    case 0:
                //        SpellHelper.Summon( new DSOrc(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
                //    break;
                //    case 1:
                //        SpellHelper.Summon( new DSGibberling(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
                //    break;
                //    case 2:
                //        SpellHelper.Summon( new DSBeholderLarva(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
                //    break;
                //    default:
                //        SpellHelper.Summon( new DSGibberling(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
                //    break;
                //}
			}

			FinishSequence();
		}
	}
}
