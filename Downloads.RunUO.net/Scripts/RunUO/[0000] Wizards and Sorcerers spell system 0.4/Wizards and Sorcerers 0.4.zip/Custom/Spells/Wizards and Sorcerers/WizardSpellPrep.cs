using System;
using Server;
using System.Collections;
using Server.Mobiles;
using Server.Items;

namespace Server.Spells
{
	public class WizardSpellPrep
	{
		public int spell;
		private int Level;
		private int Slot;
		public bool IsPrepared;
		private DateTime m_End;
		private PrepareTimer preptimer;
		
		public void SpellPrepInitialize(PolyGlotMobile Caster, int Spelltype, TimeSpan ugh, int level, int slot)
		{
			spell = Spelltype;
			Level = level;
			Slot = slot;
			IsPrepared = false;
            Spell mspell = SpellRegistry.NewSpell(spell, Caster as Mobile, null);

            Container pack = Caster.Backpack;

            if ((pack != null)&&(pack.ConsumeTotal(mspell.Info.Reagents, mspell.Info.Amounts) == -1))
            {
                preptimer = new PrepareTimer(Caster, Spelltype, ugh, level, slot);
                preptimer.Start();
                m_End = DateTime.Now + ugh;
            }
            else
                Caster.SendMessage("You do not have reagents for this preparation!");
		}
		
		public void TimerStop()
		{
			if (preptimer != null)
				preptimer.Stop();
		}
		
		public WizardSpellPrep()
		{
			spell = 0;
		    Level = 1;
		    Slot = 1;
		    IsPrepared = false;
		    m_End = DateTime.Now;
		}
		
		public WizardSpellPrep( GenericReader reader, PolyGlotMobile Caster )
		{
			Deserialize( reader, Caster );
		}
		
		
		private class PrepareTimer : Timer
		{
			private PolyGlotMobile Wiz;
			private int spell;
			private int spelllevel;
			private int slot;
			
			public PrepareTimer(PolyGlotMobile Caster, int Spelltype, TimeSpan Prep, int level, int levelslot) : base(Prep)
			{
				Wiz = Caster;
				spell = Spelltype;
				spelllevel = level;
				slot = levelslot;
			}
			
			protected override void OnTick()
			{
				switch ( spelllevel )
				{
					case 1:
					Wiz.SpellsKnown.LevelOne[slot].IsPrepared = true;
					break;
					
					case 2:
					Wiz.SpellsKnown.LevelTwo[slot].IsPrepared = true;
					break;
					
					case 3:
					Wiz.SpellsKnown.LevelThree[slot].IsPrepared = true;
					break;
					
					case 4:
					Wiz.SpellsKnown.LevelFour[slot].IsPrepared = true;
					break;
					
					case 5:
					Wiz.SpellsKnown.LevelFive[slot].IsPrepared = true;
					break;
					
					case 6:
					Wiz.SpellsKnown.LevelSix[slot].IsPrepared = true;
					break;
					
					case 7:
					Wiz.SpellsKnown.LevelSeven[slot].IsPrepared = true;
					break;
					
					case 8:
					Wiz.SpellsKnown.LevelEight[slot].IsPrepared = true;
					break;
					
					default:
					break;
				}
			
			}
		}
		
		private void Deserialize( GenericReader reader, PolyGlotMobile Caster )
		{
			m_End = reader.ReadDeltaTime();
			spell = reader.ReadInt();
			Level = reader.ReadInt();
			Slot = reader.ReadInt();
			IsPrepared = reader.ReadBool();
			
			preptimer = new PrepareTimer( Caster, spell, m_End - DateTime.Now, Level, Slot );
			
			if ((!IsPrepared)&&(m_End > DateTime.Now))
			{
				preptimer.Start();
			}
		}
		
		public void Serialize( GenericWriter writer )
		{
			
			writer.WriteDeltaTime( m_End );
			
			writer.Write( (int)spell);
			writer.Write( (int)Level);
			writer.Write( (int)Slot);
			writer.Write( (bool)IsPrepared);

		}
	}
}
