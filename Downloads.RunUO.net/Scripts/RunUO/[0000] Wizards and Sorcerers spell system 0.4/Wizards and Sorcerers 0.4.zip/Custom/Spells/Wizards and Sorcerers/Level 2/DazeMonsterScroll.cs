using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class DazeMonsterScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public DazeMonsterScroll() : this( 1 )
		{
		}

		[Constructable]
		public DazeMonsterScroll( int amount ) : base( 340, 0x1F2E, amount )
		{
			Name = "Daze Monster";
		}
		
		public DazeMonsterScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
