using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class FlameStrikeMSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Flame Strike", "Flam Merse Masse",
				Reagent.Garlic,
				Reagent.SpidersSilk,
				Reagent.SulfurousAsh
			);
		public override string Desc{ get{ return "Produces a horizontal column of fire that consumes a target."; } }
		public override string ReagentsDesc{ get{ return "SulfurousAsh, SpidersSilk, Garlic"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fourth; } }
        public override int SpellNumber { get { return 305; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 60.0; } }
		public override int RequiredMana{ get{ return 40; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }

		public FlameStrikeMSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return true; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				SpellHelper.Turn( Caster, m );

				SpellHelper.CheckReflect( (int)this.SpellLevel, Caster, ref m );

				int damage = Utility.Random( 27, 22 );;

				m.FixedParticles( 0x3709, 10, 30, 5052, EffectLayer.LeftFoot );
				m.PlaySound( 0x208 );

				Caster.DoHarmful( m );
				//damage = AbsorbDamage(m, ResistType.Fire, damage);
				m.Damage( damage );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private FlameStrikeMSpell m_Owner;

			public InternalTarget( FlameStrikeMSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
