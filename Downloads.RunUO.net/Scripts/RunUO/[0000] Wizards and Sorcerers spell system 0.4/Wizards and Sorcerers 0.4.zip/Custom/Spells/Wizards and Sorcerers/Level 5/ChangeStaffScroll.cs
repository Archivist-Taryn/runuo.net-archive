using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ChangeStaffScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public ChangeStaffScroll() : this( 1 )
		{
		}

		[Constructable]
		public ChangeStaffScroll( int amount ) : base( 336, 0x1F2E, amount )
		{
			Name = "Change Staff";
		}
		
		public ChangeStaffScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
