using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class OpenCloseScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public OpenCloseScroll() : this( 1 )
		{
		}

		[Constructable]
		public OpenCloseScroll( int amount ) : base( 331, 0x1F2E, amount )
		{
			Name = "Open/Close";
		}
		
		public OpenCloseScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
