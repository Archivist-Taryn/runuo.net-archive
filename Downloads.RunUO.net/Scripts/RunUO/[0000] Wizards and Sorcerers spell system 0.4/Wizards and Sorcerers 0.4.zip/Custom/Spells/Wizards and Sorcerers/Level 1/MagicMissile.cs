using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class MagicMissileSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Magic Missile", "Mythos Simit'",
				Reagent.SulfurousAsh
			);
		
        public override string Desc{ get{ return "A missile of magical energy darts forth from your fingertips."; } } 
		public override string ReagentsDesc{ get{ return "One Sulfurous Ash."; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }
        public override SpellCircle SpellLevel { get{ return SpellCircle.First; } }
        public override int SpellNumber { get { return 300; } }

		public MagicMissileSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return true; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				Mobile source = Caster;

				SpellHelper.Turn( source, m );

				SpellHelper.CheckReflect( (int)this.SpellLevel, ref source, ref m );

				int damage = Utility.Random( 4, 4 );

				source.MovingParticles( m, 0x36E4, 5, 0, false, true, 3006, 4006, 0 );
				source.PlaySound( 0x1E5 );
				
				Caster.DoHarmful( m );
				//damage = AbsorbDamage(m, ResistType.Fire, damage);
				m.Damage( damage );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private MagicMissileSpell m_Owner;

			public InternalTarget( MagicMissileSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
