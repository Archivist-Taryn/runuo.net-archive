using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ConeOfColdScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public ConeOfColdScroll() : this( 1 )
		{
		}

		[Constructable]
		public ConeOfColdScroll( int amount ) : base( 337, 0x1F2E, amount )
		{
			Name = "Cone of Cold";
		}
		
		public ConeOfColdScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
