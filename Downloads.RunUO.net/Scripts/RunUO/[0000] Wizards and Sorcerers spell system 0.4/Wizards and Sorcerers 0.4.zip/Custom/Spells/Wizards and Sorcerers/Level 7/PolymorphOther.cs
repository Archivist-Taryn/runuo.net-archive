using System;
using System.Collections;
using Server;
using Server.Items;
using Server.Gumps;
using Server.Spells;
using Server.Spells.Fifth;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class PolymorphOtherSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Polymorph Other", "Tris Inloc",
				17,
				Reagent.Emerald,
				Reagent.PigIron,
				Reagent.PigIron,
				Reagent.PigIron,
				Reagent.Nightshade,
				Reagent.Ginseng
			);
		public override string Desc{ get{ return "Changes a target other than yourself into another form of creature.."; } }
		public override string ReagentsDesc{ get{ return "One emerals, three PigIron, one Nightshade, Ginseng"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Seventh; } }
        public override int SpellNumber { get { return 343; } }
		public override double CastDelay{ get{ return 5.0; } }
		public override double RequiredSkill{ get{ return 70.0; } }
		public override int RequiredMana{ get{ return 70; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Transmutation; } }
		private int m_NewBody;
		private Mobile targetmobile;

		public PolymorphOtherSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		
		public void Target( Mobile m )
		{
			targetmobile = m;
			
			if ( !m.CanBeginAction( typeof( PolymorphOtherSpell ) ) )
			{
				Caster.SendLocalizedMessage( 1005559 ); // This spell is already in effect.
			}
            else if ( TransformationSpellHelper.UnderTransformation(m) )
			{
				Caster.SendMessage("Another spell was in effect on your target.");
			}
			else if ( CheckSequence() )
			{
				if ( Caster.BeginAction( typeof( PolymorphOtherSpell ) ) )
				{
					Caster.SendGump( new PolymorphOtherGump( Caster, Scroll, this ) );
				}
				else
				{
					Caster.SendLocalizedMessage( 1005559 ); // This spell is already in effect.
				}
			}

			FinishSequence();
		}
		
		public void OnGumpPick(int body)
		{
			m_NewBody = body;
			
			if ( m_NewBody != 0 )
			{
				if ( !((Body)m_NewBody).IsHuman )
				{
					Mobiles.IMount mt = targetmobile.Mount;
					
					if ( mt != null )
						mt.Rider = null;
				}
				
				targetmobile.BodyMod = m_NewBody;
				
				if ( m_NewBody == 400 || m_NewBody == 401 )
					targetmobile.HueMod = Utility.RandomSkinHue();
				else
					targetmobile.HueMod = 0;
				
				BaseArmor.ValidateMobile( targetmobile );
				
				StopTimer( targetmobile );
				
				Timer t = new InternalTimer( targetmobile );
				
				m_Timers[targetmobile] = t;
				
				t.Start();
			}
			
			FinishSequence();
		}
		
		private class InternalTarget : Target
		{
			private PolymorphOtherSpell m_Owner;

			public InternalTarget( PolymorphOtherSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			} 

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

		}
		
		

		private static Hashtable m_Timers = new Hashtable();

		public static bool StopTimer( Mobile m )
		{
			Timer t = (Timer)m_Timers[m];

			if ( t != null )
			{
				t.Stop();
				m_Timers.Remove( m );
			}

			return ( t != null );
		}

		private class InternalTimer : Timer
		{
			private Mobile m_Owner;

			public InternalTimer( Mobile owner ) : base( TimeSpan.FromSeconds( 0 ) )
			{
				m_Owner = owner;

				int val = (int)owner.Skills[SkillName.Magery].Value;

				if ( val > 120 )
					val = 120;

				Delay = TimeSpan.FromSeconds( val );
				Priority = TimerPriority.OneSecond;
			}

			protected override void OnTick()
			{
				if ( !m_Owner.CanBeginAction( typeof( PolymorphOtherSpell ) ) )
				{
					m_Owner.BodyMod = 0;
					m_Owner.HueMod = -1;
					m_Owner.EndAction( typeof( PolymorphOtherSpell ) );

					BaseArmor.ValidateMobile( m_Owner );
				}
			}
		}
	}
}
