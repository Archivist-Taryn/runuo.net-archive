using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class TeleportMScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public TeleportMScroll() : this( 1 )
		{
		}

		[Constructable]
		public TeleportMScroll( int amount ) : base( 361, 0x1F2E, amount )
		{
			Name = "Teleport";
		}
		
		public TeleportMScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}

