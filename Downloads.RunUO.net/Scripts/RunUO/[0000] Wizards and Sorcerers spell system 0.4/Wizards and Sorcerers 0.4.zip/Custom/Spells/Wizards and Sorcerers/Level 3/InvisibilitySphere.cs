using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;

namespace Server.Spells.Magician
{
	public class InvisibilitySphereSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Invisibility Sphere", "Totar Iniratos Lorlocrener",
				Reagent.Bone,
				Reagent.BlackPearl,
				Reagent.Nightshade
			);

		public override string Desc{ get{ return "Grants invisibility upon all creatures near you."; } }
		public override string ReagentsDesc{ get{ return "One Bone, BlackPearl, Nightshade"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 328; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 50.0; } }
		public override int RequiredMana{ get{ return 25; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Illusion; } }

		public InvisibilitySphereSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			ArrayList list = new ArrayList();
			foreach ( Mobile mob in Caster.Map.GetMobilesInRange( Caster.Location, 5 ) )
			{
				list.Add(mob);
			}
			for(int i = 0; i < list.Count; i++)
			{
				Mobile m = list[i] as Mobile;
				Target( m );
			}
			
			FinishSequence();
		}

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckBSequence( m ) )
			{
				Effects.SendLocationParticles( EffectItem.Create( new Point3D( m.X, m.Y, m.Z + 16 ), Caster.Map, EffectItem.DefaultDuration ), 0x376A, 10, 15, 5045 );
				m.PlaySound( 0x3C4 );

				m.Hidden = true;

				RemoveTimer( m );

				TimeSpan duration = TimeSpan.FromSeconds((2 * Caster.Skills.Magery.Fixed) + 10 );

				Timer t = new InternalTimer( m, duration );

				m_Table[m] = t;

				t.Start();
			}
		}

		private static Hashtable m_Table = new Hashtable();

		public static void RemoveTimer( Mobile m )
		{
			Timer t = (Timer)m_Table[m];

			if ( t != null )
			{
				t.Stop();
				m_Table.Remove( m );
			}
		}

		private class InternalTimer : Timer
		{
			private Mobile m_Mobile;

			public InternalTimer( Mobile m, TimeSpan duration ) : base( duration )
			{
				Priority = TimerPriority.OneSecond;
				m_Mobile = m;
			}

			protected override void OnTick()
			{
				m_Mobile.RevealingAction();
				RemoveTimer( m_Mobile );
			}
		}
	}
}
