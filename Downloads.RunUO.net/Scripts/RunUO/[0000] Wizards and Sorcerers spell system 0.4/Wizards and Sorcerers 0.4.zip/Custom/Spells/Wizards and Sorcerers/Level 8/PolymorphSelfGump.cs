using System;
using Server;
using Server.Network;
using Server.Targets;
using Server.Spells;
using Server.Spells.Magician;

namespace Server.Gumps
{
	public class PolymorphSelfGump : Gump
	{
		private class PolymorphSelfEntry
		{
			private int m_Art, m_Body, m_Num;

			public PolymorphSelfEntry( int Art, int Body, int LocNum )
			{
				m_Art = Art;
				m_Body = Body;
				m_Num = LocNum;
			}

			public int ArtID { get { return m_Art; } }
			public int BodyID { get { return m_Body; } }
			public int LocNumber{ get { return m_Num; } }
		}

		private class PolymorphSelfCategory
		{
			private int m_Num;
			private PolymorphSelfEntry[] m_Entries;

			public PolymorphSelfCategory( int num, PolymorphSelfEntry[] entries )
			{
				m_Num = num;
				m_Entries = entries;
			}

			public PolymorphSelfEntry[] Entries{ get { return m_Entries; } }
			public int LocNumber{ get { return m_Num; } }
		}

		private static PolymorphSelfCategory[] Categories = new PolymorphSelfCategory[]
		{
			new PolymorphSelfCategory( 1015235, new PolymorphSelfEntry[] //Animals
			{
				new PolymorphSelfEntry( 8401, 0xD0, 1015236 ),//Chicken
				new PolymorphSelfEntry( 8405, 0xD9, 1015237 ),//Dog
				new PolymorphSelfEntry( 8426, 0xE1, 1015238 ),//Wolf
				new PolymorphSelfEntry( 8473, 0xD6, 1015239 ),//Panther
				new PolymorphSelfEntry( 8437, 0x1D, 1015240 ),//Gorilla
				new PolymorphSelfEntry( 8399, 0xD3, 1015241 ),//Black Bear
				new PolymorphSelfEntry( 8411, 0xD4, 1015242 ),//Grizzly Bear
				new PolymorphSelfEntry( 8417, 0xD5, 1015243 ),//Polar Bear
				new PolymorphSelfEntry( 8397, 0x190, 1015244 )//Human Male
			} ),

			new PolymorphSelfCategory( 1015245, new PolymorphSelfEntry[] //Monsters
			{
				new PolymorphSelfEntry( 8424, 0x33, 1015246 ),//Slime
				new PolymorphSelfEntry( 8416, 0x11, 1015247 ),//Orc
				new PolymorphSelfEntry( 8414, 0x21, 1015248 ),//Lizard Man
				new PolymorphSelfEntry( 8409, 0x04, 1015249 ),//Gargoyle
				new PolymorphSelfEntry( 8415, 0x01, 1015250 ),//Orge
				new PolymorphSelfEntry( 8425, 0x36, 1015251 ),//Troll
				new PolymorphSelfEntry( 8408, 0x02, 1015252 ),//Ettin
				new PolymorphSelfEntry( 8403, 0x09, 1015253 ),//Daemon
				new PolymorphSelfEntry( 8398, 0x191, 1015254 ),//Human Female
			} )
		};

		private Mobile m_Caster;
		private Item m_Scroll;

		public PolymorphSelfGump( Mobile caster, Item scroll ) : base( 50, 50 )
		{
			m_Caster = caster;
			m_Scroll = scroll;

			int x,y;
			AddPage( 0 );
			AddBackground( 0, 0, 585, 393, 5054 );
			AddBackground( 195, 36, 387, 275, 3000 );
			AddHtmlLocalized( 0, 0, 510, 18, 1015234, false, false ); // <center>Polymorph Selection Menu</center>
			AddHtmlLocalized( 60, 355, 150, 18, 1011036, false, false ); // OKAY
			AddButton( 25, 355, 4005, 4007, 1, GumpButtonType.Reply, 1 );
			AddHtmlLocalized( 320, 355, 150, 18, 1011012, false, false ); // CANCEL
			AddButton( 285, 355, 4005, 4007, 0, GumpButtonType.Reply, 2 );

			y = 35;
			for ( int i=0;i<Categories.Length;i++ )
			{
				PolymorphSelfCategory cat = (PolymorphSelfCategory)Categories[i];
				AddHtmlLocalized( 5, y, 150, 25, cat.LocNumber, true, false );
				AddButton( 155, y, 4005, 4007, 0, GumpButtonType.Page, i+1 );
				y += 25;
			}

			for ( int i=0;i<Categories.Length;i++ )
			{
				PolymorphSelfCategory cat = (PolymorphSelfCategory)Categories[i];
				AddPage( i+1 );

				for ( int c=0;c<cat.Entries.Length;c++ )
				{
					PolymorphSelfEntry entry = (PolymorphSelfEntry)cat.Entries[c];
					x = 198 + (c%3)*129;
					y = 38 + (c/3)*67;

					AddHtmlLocalized( x, y, 100, 18, entry.LocNumber, false, false );
					AddItem( x+20, y+25, entry.ArtID );
					AddRadio( x, y+20, 210, 211, false, (c<<8) + i );
				}
			}
		}

		public override void OnResponse( NetState state, RelayInfo info )
		{
			if ( info.ButtonID == 1 && info.Switches.Length > 0 )
			{
				int cnum = info.Switches[0];
				int cat = cnum%256;
				int ent = cnum>>8;

				if ( cat < Categories.Length )
				{
					if ( ent < Categories[cat].Entries.Length )
					{
						Spell spell = new PolymorphSelfSpell( m_Caster, m_Scroll, Categories[cat].Entries[ent].BodyID );
						spell.Cast();
					}
				}
			}
		}
	}
}
