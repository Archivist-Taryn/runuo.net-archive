using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Gumps;
using Server.Prompts;

namespace Server.Spells.Magician
{
	public class TeleportMSpell : MagicianSpell
	{
		public static void TeleportAction( Mobile mob, RunebookEntry entry )
		{
			Map map = entry.Map;
			Point3D p =entry.Location;
			mob.PlaySound( 0x1FC );
			mob.MoveToWorld( p, map );
			mob.PlaySound( 0x1FC );
		}
		
		
		private static SpellInfo m_Info = new SpellInfo(
				"Teleport", "Tosinos",
				Reagent.SpidersSilk,
				Reagent.SpidersSilk,
				Reagent.SpidersSilk,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss
			);
		
		public override string Desc{ get{ return "Saves 5 locations that you can teleport between."; } }
		public override string ReagentsDesc{ get{ return "Three Spider's Silk, Three Bloodmoss."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Sixth; } }
        public override int SpellNumber { get { return 361; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Transmutation; } }

		public TeleportMSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
			
		}
		
		public override void OnCast()
		{
			if(CheckSequence())
			{
				Caster.SendGump( new TeleportGump( Caster ) );
			}
			FinishSequence();
		}
	}

	public class PlaceNamePrompt : Prompt
	{
		private int n;
		
		public PlaceNamePrompt( int i )
		{
			n = i;
		}
		
		public override void OnResponse( Mobile from, string text )
		{
			from.SendMessage("You've saved a location to your memory.");
			PolyGlotMobile dark = from as PolyGlotMobile;
			
			if(text.Length > 15)
				text = text.Substring(0, 15);
			
			dark.TeleportEntries[n] = new RunebookEntry(dark.Location, dark.Map, text, null);
		}
	}
	
	
	public class AddTeleportGump : Gump
	{
		private Mobile m_Caster;
		private int m_Spot;
		public AddTeleportGump(Mobile Caster, int Spot)
			: base( 50, 50 )
		{
			m_Caster = Caster;
			m_Spot = Spot;
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			this.AddPage(0);
			this.AddBackground(144, 119, 209, 190, 9300);
			this.AddImage(154, 133, 57);
			this.AddImageTiled(182, 133, 134, 15, 58);
			this.AddImage(310, 133, 59);
			this.AddImage(154, 282, 57);
			this.AddImageTiled(182, 282, 134, 15, 58);
			this.AddImage(310, 282, 59);
			this.AddLabel(178, 161, 0, @"Are you sure you want to");
			this.AddLabel(163, 179, 0, @"add your current location to");
			this.AddLabel(161, 197, 0, @"your list of memorized locations?");
			this.AddButton(178, 250, 247, 248, 1, GumpButtonType.Reply, 1);
			this.AddButton(258, 250, 241, 242, 0, GumpButtonType.Reply, 0);

		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			switch ( info.ButtonID )
			{
			
				case 1:
					{
						state.Mobile.SendMessage("Please name your new location. (15 character max)");
						state.Mobile.Prompt = new PlaceNamePrompt(m_Spot);
						break;
					}
				case 0:
					{
						state.Mobile.SendMessage("You've decided not to save a location at this time.");
						state.Mobile.SendGump( new TeleportGump( state.Mobile ) );
						break;
					}
				default:
					{
						break;
					}
			}
		}
	}

	public class TeleportGump : Gump
	{
		private Mobile m_Caster;
		private RunebookEntry[] TeleportEntries;
		public TeleportGump(Mobile Caster) : base( 50, 50 )
		{
			m_Caster = Caster;
			PolyGlotMobile dark = Caster as PolyGlotMobile;
			TeleportEntries = dark.TeleportEntries;
			
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;

			this.AddPage(0);

			this.AddBackground(31, 30, 470, 372, 9300);
			this.AddImage(45, 45, 57);
			this.AddImage(455, 45, 59);
			this.AddImageTiled(70, 45, 390, 12, 58);
			this.AddImage(45, 374, 57);
			this.AddImage(455, 374, 59);
			this.AddImageTiled(70, 374, 390, 12, 58);
			this.AddImage(60, 100, 2087);
			this.AddImage(60, 300, 2087);
			this.AddImage(60, 250, 2087);
			this.AddImage(60, 200, 2087);
			this.AddImage(60, 150, 2087);

			this.AddLabel(189, 68, 50, @"Choose Your Location");
			this.AddLabel(174, 342, 50, @"Teleport Spell Locations");

			if(TeleportEntries[0].Description == "null")
				this.AddLabel(80, 97, 50, @"Empty Location");
			else
			{
				this.AddLabel(80, 97, 50, @TeleportEntries[0].Description);
				this.AddButton(240, 97, 247, 248, 10, GumpButtonType.Reply, 10);
			}
			
			if(TeleportEntries[1].Description == "null")
				this.AddLabel(80, 147, 50, @"Empty Location");
			else
			{
				this.AddLabel(80, 147, 50, @TeleportEntries[1].Description);
				this.AddButton(240, 147, 247, 248, 1, GumpButtonType.Reply, 1);
			}
			
			if(TeleportEntries[2].Description == "null")
				this.AddLabel(80, 197, 50, @"Empty Location");
			else
			{
				this.AddLabel(80, 197, 50, @TeleportEntries[2].Description);
				this.AddButton(240, 197, 247, 248, 2, GumpButtonType.Reply, 2);
			}
			
			if(TeleportEntries[3].Description == "null")
				this.AddLabel(80, 247, 50, @"Empty Location");
			else
			{
				this.AddLabel(80, 247, 50, @TeleportEntries[3].Description);
				this.AddButton(240, 247, 247, 248, 3, GumpButtonType.Reply, 3);
			}
			
			if(TeleportEntries[4].Description == "null")
				this.AddLabel(80, 297, 50, @"Empty Location");
			else
			{
				this.AddLabel(80, 297, 50, @TeleportEntries[4].Description);
				this.AddButton(240, 297, 247, 248, 4, GumpButtonType.Reply, 4);
			}
			
			this.AddButton(400, 97, 22153, 22154, 5, GumpButtonType.Reply, 5);
			this.AddButton(400, 147, 22153, 22154, 6, GumpButtonType.Reply, 6);
			this.AddButton(400, 197, 22153, 22154, 7, GumpButtonType.Reply, 7);
			this.AddButton(400, 247, 22153, 22154, 8, GumpButtonType.Reply, 8);
			this.AddButton(400, 297, 22153, 22154, 9, GumpButtonType.Reply, 9);

			this.AddLabel(345, 97, 50, @"Set");
			this.AddLabel(345, 297, 50, @"Set");
			this.AddLabel(345, 247, 50, @"Set");
			this.AddLabel(345, 197, 50, @"Set");
			this.AddLabel(345, 147, 50, @"Set");
		}

		public override void OnResponse( NetState state, RelayInfo info )
		{
			PlayerMobile m = state.Mobile as PlayerMobile;

			switch ( info.ButtonID )
			{
				case 10:
					{
						TeleportMSpell.TeleportAction( m_Caster, TeleportEntries[0] );
						break;
					}
				case 1:
					{
						TeleportMSpell.TeleportAction( m_Caster, TeleportEntries[1] );
						break;
					}
				case 2:
					{
						TeleportMSpell.TeleportAction( m_Caster, TeleportEntries[2] );
						break;
					}
				case 3:
					{
						TeleportMSpell.TeleportAction( m_Caster, TeleportEntries[3] );
						break;
					}
				case 4:
					{
						TeleportMSpell.TeleportAction( m_Caster, TeleportEntries[4] );
						break;
					}
				case 5:
					{
						m.SendGump( new AddTeleportGump( m_Caster, 0 ) );
						break;
					}
				case 6:
					{
						m.SendGump( new AddTeleportGump( m_Caster, 1 ) );
						break;
					}
				case 7:
					{
						m.SendGump( new AddTeleportGump( m_Caster, 2 ) );
						break;
					}
				case 8:
					{
						m.SendGump( new AddTeleportGump( m_Caster, 3 ) );
						break;
					}
				case 9:
					{
						m.SendGump( new AddTeleportGump( m_Caster, 4 ) );
						break;
					}
				default:
					{
						break;
					}
			}
		}
	}
}

