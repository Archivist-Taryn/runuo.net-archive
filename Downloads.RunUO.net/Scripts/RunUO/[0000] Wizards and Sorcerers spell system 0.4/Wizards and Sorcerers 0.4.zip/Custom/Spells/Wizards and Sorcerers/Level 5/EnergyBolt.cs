using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class EnergyBoltMSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Energy Bolt", "Shrik Vorte",
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.Bone,
				Reagent.Bloodmoss
			);

		public override string Desc{ get{ return "Unleashes great energy forces upon your enemy!"; } }
		public override string ReagentsDesc{ get{ return "Three MandrakeRoot, one Bone, Bloodmoss "; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fifth; } }
        public override int SpellNumber { get { return 308; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 70.0; } }
		public override int RequiredMana{ get{ return 45; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }


		public EnergyBoltMSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return true; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				Mobile source = Caster;

				SpellHelper.Turn( Caster, m );

				SpellHelper.CheckReflect( (int)this.SpellLevel, ref source, ref m );

				int damage = Utility.Random( 24, 18 );

				source.MovingParticles( m, 0x379F, 7, 0, false, true, 3043, 4043, 0x211 );
				source.PlaySound( 0x20A );

				Caster.DoHarmful( m );
				//damage = AbsorbDamage(m, ResistType.Energy, damage);
				m.Damage( damage );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private EnergyBoltMSpell m_Owner;

			public InternalTarget( EnergyBoltMSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
					m_Owner.Target( (Mobile)o );
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
