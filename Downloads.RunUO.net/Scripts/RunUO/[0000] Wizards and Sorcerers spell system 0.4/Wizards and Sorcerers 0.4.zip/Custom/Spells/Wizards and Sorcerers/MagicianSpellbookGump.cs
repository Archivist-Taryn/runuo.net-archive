using System;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Spells;
using Server.Spells.Magician;
using Server.Prompts;
using Server.Mobiles;
using Server.Gumps;

namespace Server.Gumps
{
	public class MagicianSpellbookGump : Gump
	{
		private MagicianSpellbook m_Book;
		private PolyGlotMobile m_Dark;
		private MagicianSpell[] spells;
		
		private ArrayList UniversalSpells;
		private ArrayList AbjurationSpells;
		private ArrayList ConjurationSpells;
		private ArrayList DivinationSpells;
		private ArrayList EnchantmentSpells;
		private ArrayList EvocationSpells;
		private ArrayList IllusionSpells;
		private ArrayList NecromancySpells;
		private ArrayList TransmutationSpells;
		
		int gth = 0x903;
		
		private int Chap1Page = 0;
		private int Chap2Page = 0;
		private int Chap3Page = 0;
		private int Chap4Page = 0;
		private int Chap5Page = 0;
		private int Chap6Page = 0;
		private int Chap7Page = 0;
		private int Chap8Page = 0;
		private int Chap9Page = 0;
		
		
		private void AddBackground()
		{
			AddPage( 0 );
			
			AddImage( 75, 6, 0x8AC, 0 );
			//   AddImage( 255, 10, 0x8AD, 0x48B );
			
			
			
			// AddLabel( 140, 45, gth, "Ohm - Earth" );
			// AddLabel( 140, 60, gth, "Ess - Air" );
			// AddLabel( 140, 75, gth, "Crur - Fire" );
			// AddLabel( 140, 90, gth, "Sepa - Water" );
			// AddLabel( 140, 110, gth, "Kes - One" );
			// AddLabel( 140, 125, gth, "Sec - Whole" );
			// AddLabel( 140, 140, gth, "En  - Call" );
			// AddLabel( 140, 155, gth, "Vauk - Banish" );
			// AddLabel( 140, 170, gth, "Tia - Befoul" );
			// AddLabel( 140, 185, gth, "Ante - Cleanse" );
			
		}
		
		public bool HasSpell( int spellID )
		{
			return m_Dark.SpellsKnown.HasSpell( spellID );
		}
		
		
		public MagicianSpellbookGump( Mobile from, MagicianSpellbook book ) : base( 150, 200 )
		{
			
			m_Book = book;
			m_Dark = from as PolyGlotMobile;
			
			int[] spellnums = m_Dark.SpellsKnown.GenerateArrayOfSpells();
			
			spells = new MagicianSpell[spellnums.Length];
			
			for (int j = 0; j < spellnums.Length; j++ )
			{
				Spell spell = SpellRegistry.NewSpell( spellnums[j], m_Dark as Mobile, null );
				spells[j] = spell as MagicianSpell;
			}
			
			if(spells.Length > 1)
				spells = this.SpellSort(spells);
			
			UniversalSpells = new ArrayList();
			AbjurationSpells = new ArrayList();
			ConjurationSpells = new ArrayList();
			DivinationSpells = new ArrayList();
			EnchantmentSpells = new ArrayList();
			EvocationSpells = new ArrayList();
			IllusionSpells = new ArrayList();
			NecromancySpells = new ArrayList();
			TransmutationSpells = new ArrayList();
			for (int j = 0; j < spells.Length; j++)
			{
				switch(spells[j].SpellSchool)
				{
					case SpellSchool.Universal:
					{
							UniversalSpells.Add(spells[j]);
							break;
					}
					case SpellSchool.Abjuration:
					{
							AbjurationSpells.Add(spells[j]);
							break;
					}	
					case SpellSchool.Conjuration:
					{
							ConjurationSpells.Add(spells[j]);
							break;
					}
					case SpellSchool.Divination:
					{
							DivinationSpells.Add(spells[j]);
							break;
					}
					case SpellSchool.Enchantment:
					{
							EnchantmentSpells.Add(spells[j]);
							break;
					}
					case SpellSchool.Evocation:
					{
							EvocationSpells.Add(spells[j]);
							break;
					}
					case SpellSchool.Illusion:
					{
							IllusionSpells.Add(spells[j]);
							break;
					}
					case SpellSchool.Necromancy:
					{
							NecromancySpells.Add(spells[j]);
							break;
					}
					case SpellSchool.Transmutation:
					{
							TransmutationSpells.Add(spells[j]);
							break;
					}
					default:
						break;
				}
			}
			
			AddBackground();
			AddPage( 1 );
			AddLabel( 155, 17, 0x4C1, "Wizard Tome" );
			AddHtml( 140, 39, 123, 172, "Welcome, Master " + from.Name + ".  I am your magical tome, here to do your bidding.  For a quick jump to a chapter, use the magical stones on the next page." , false, false );
			int sbtn = 0x93A;
			int dby = 20;
			AddButton( 396, 14, 0x89E, 0x89E, 17, GumpButtonType.Page, 2 );
			
			int i = 2;
			
			i = Index( i );
			Chap1Page = i;
			
			i = Chapter1( i );
			Chap2Page = i;
			
			i = Chapter2( i );
			Chap3Page = i;
			
			i = Chapter3( i );
			Chap4Page = i;
			
			i = Chapter4( i );
			Chap5Page = i;
			
			i = Chapter5( i );
			Chap6Page = i;
			
			i = Chapter6( i );
			Chap7Page = i;
			
			i = Chapter7( i );
			Chap8Page = i;
			
			i = Chapter8( i );
			Chap9Page = i;
			
			i = Chapter9( i );
			
			AddPage( i );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			
			AddPage( 1 );
			
			AddLabel( 315, dby, gth, "Universal" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap1Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Abjuration" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap2Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Conjuration" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap3Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Divination" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap4Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Enchantment" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap5Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Evocation" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap6Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Illusion" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap7Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Necromancy" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap8Page );
			dby = dby + 20;
			
			AddLabel( 315, dby, gth, "Transmutation" );
			AddButton( 295, dby + 3, sbtn, sbtn, 0, GumpButtonType.Page, Chap9Page );
			
			
			
			UniversalSpells.Clear();
			AbjurationSpells.Clear();
			ConjurationSpells.Clear();
			DivinationSpells.Clear();
			EnchantmentSpells.Clear();
			EvocationSpells.Clear();
			IllusionSpells.Clear();
			NecromancySpells.Clear();
			TransmutationSpells.Clear();
		}
		
		public MagicianSpell[] SpellSort( MagicianSpell[] spells )
		{
			MagicianSpell tempspell = spells[0];
			
			for( int i=0; i<spells.Length-1; i++ )
			{
				for(int j=i+1; j<spells.Length; j++)
				{
					
					if(spells[i].SpellLevel > spells[j].SpellLevel)
					{
						tempspell = spells[i];
						spells[i] = spells[j];
						spells[j] = tempspell;
					}
				}
			}
			
			return spells;
		}
		
		public string NumberPrepared( int Spelltype )
		{
			Mobile from = m_Dark as Mobile;
			Spell Mspell = SpellRegistry.NewSpell( Spelltype, from, null );
            MagicianSpell spell = Mspell as MagicianSpell;
			int amount = 0;
			
			switch( (int)spell.SpellLevel + 1 )
			{
				case 1:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelOne.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelOne[i].IsPrepared) && (m_Dark.SpellsKnown.LevelOne[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 2:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelTwo.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelTwo[i].IsPrepared) && (m_Dark.SpellsKnown.LevelTwo[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 3:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelThree.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelThree[i].IsPrepared) && (m_Dark.SpellsKnown.LevelThree[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 4:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelFour.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelFour[i].IsPrepared) && (m_Dark.SpellsKnown.LevelFour[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 5:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelFive.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelFive[i].IsPrepared) && (m_Dark.SpellsKnown.LevelFive[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 6:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelSix.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelSix[i].IsPrepared) && (m_Dark.SpellsKnown.LevelSix[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 7:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelSeven.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelSeven[i].IsPrepared) && (m_Dark.SpellsKnown.LevelSeven[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 8:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelEight.Length; i++)
					{
						if ((m_Dark.SpellsKnown.LevelEight[i].IsPrepared) && (m_Dark.SpellsKnown.LevelEight[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				default:
					break;
			}
			return Convert.ToString( amount );
		}
		
		public string NumberPreparing( int Spelltype )
		{
			Mobile from = m_Dark as Mobile;
			MagicianSpell spell = (MagicianSpell) SpellRegistry.NewSpell( Spelltype, from, null );
			int amount = 0;
			
			switch( (int)spell.SpellLevel + 1 )
			{
				case 1:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelOne.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelOne[i].IsPrepared) && (m_Dark.SpellsKnown.LevelOne[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 2:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelTwo.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelTwo[i].IsPrepared) && (m_Dark.SpellsKnown.LevelTwo[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 3:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelThree.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelThree[i].IsPrepared) && (m_Dark.SpellsKnown.LevelThree[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 4:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelFour.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelFour[i].IsPrepared) && (m_Dark.SpellsKnown.LevelFour[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 5:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelFive.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelFive[i].IsPrepared) && (m_Dark.SpellsKnown.LevelFive[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 6:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelSix.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelSix[i].IsPrepared) && (m_Dark.SpellsKnown.LevelSix[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 7:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelSeven.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelSeven[i].IsPrepared) && (m_Dark.SpellsKnown.LevelSeven[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				case 8:
				{
					for(int i = 0; i < m_Dark.SpellsKnown.LevelEight.Length; i++)
					{
						if ((!m_Dark.SpellsKnown.LevelEight[i].IsPrepared) && (m_Dark.SpellsKnown.LevelEight[i].spell == Spelltype))
						{
							amount = amount + 1;
						}
					}
					break;	
				}
				default:
					break;
			}
			return Convert.ToString( amount );
		}

        public string ComputeLevel(SpellCircle circle)
        {
            return ComputeLevel((int)circle + 1);
        }
		
		
		public string ComputeLevel( int level )
		{
			switch( level )
			{
				case 1:
				{
					return "Level One";
				}
				case 2:
				{
					return "Level Two";
				}
				case 3:
				{
					return "Level Three";
				}
				case 4:
				{
					return "Level Four";
				}
				case 5:
				{
					return "Level Five";
				}
				case 6:
				{
					return "Level Six";
				}
				case 7:
				{
					return "Level Seven";
				}
				case 8:
				{
					return "Level Eight";
				}
				default:
				{
					return "";
				}
			}
		}
		
		public int Index( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 174, 17, 0x4C1, "Index" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 155, 37, gth, "Spell Index" );
			AddHtml( 140, 59, 123, 132, "The following is a short introduction to casting spells.  You must first prepare a spell. This is the most important step.", false, false );
			AddHtml( 295, 37, 123, 88, "To do this, use the following magical symbol, or use the magical words [PrepareSpell.", false, false );
			AddButton( 295, 157, 0x5004, 0x5004, 1000, GumpButtonType.Reply, 1 );
			AddLabel( 345, 157, gth, "To prepare" );
			AddLabel( 345, 177, gth, "click symbol" );
			i++;
			
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 174, 17, 0x4C1, "Index" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddHtml( 140, 37, 123, 160, "Preparation is important, but it takes time to prepare a spell.  Also, preparing a spell will only ready one instance of the spell.  Prepare more to cast more often.", false, false );
			AddHtml( 295, 37, 123, 160, "The higher the spell level, the longer the preparation time will take.  Some spells may require reagents of some sort.  The reagents are listed on each particular spell page.", false, false );
			i++;
			
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 174, 17, 0x4C1, "Index" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddHtml( 140, 37, 123, 160, "Lastly, make note of each school's opposite school.  Specialist wizards will not be able to learn any of their opposite school's spells, however can learn all of their", false, false );
			AddHtml( 295, 37, 123, 160, "specialist school's strongest spells.  Any non-specialist wizard can learn up to Level Six of any school, not counting Universal.  Be wise in your decision to specialize.", false, false );
			i++;
			
			return i;
		}
		
		public int Chapter1( int i )
		{
			
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 170, 17, 0x4C1, "Universal" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 150, 37, gth, "Universal Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the universal spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "None" );
			AddHtml( 295, 37, 123, 160, "Universal spells combine elements of several schools, affect magic directly, or involve very basic magic concepts.  Available to all types of wizards.", false, false );
			i++;
			
			for( int j = 0; j < UniversalSpells.Count; j++)
			{
				MagicianSpell mspell = UniversalSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 170, 17, 0x4C1, "Universal" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				//AddLabel( 295, 57, gth, "Ginseng" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter2( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 170, 17, 0x4C1, "Abjuration" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 150, 37, gth, "Abjuration Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the Abjuration spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Transmutation" );
			AddHtml( 295, 37, 123, 160, "Abjuration spells ward, protect, dispel, or are generally defensive for the wizard.", false, false );
			i++;
			
			for( int j = 0; j < AbjurationSpells.Count; j++)
			{
				MagicianSpell mspell = AbjurationSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 170, 17, 0x4C1, "Abjuration" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter3( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 168, 17, 0x4C1, "Conjuration" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 145, 37, gth, "Conjuration Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the Conjuration spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Divination" );
			AddHtml( 295, 37, 123, 160, "Conjuration spells summon entities from other planes, create new temporary objects from thin air, or create passageways to other far away places.", false, false );
			i++;
			
			for( int j = 0; j < ConjurationSpells.Count; j++)
			{
				MagicianSpell mspell = ConjurationSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 168, 17, 0x4C1, "Conjuration" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter4( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 170, 17, 0x4C1, "Divination" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 150, 37, gth, "Divination Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the Divination spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Conjuration" );
			AddHtml( 295, 37, 123, 160, "Divination spells provide information, knowledge, or awareness to the wizard.  This school personifies ultimate knowledge.", false, false );
			i++;
			
			for( int j = 0; j < DivinationSpells.Count; j++)
			{
				MagicianSpell mspell = DivinationSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 170, 17, 0x4C1, "Divination" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter5( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 166, 17, 0x4C1, "Enchantment" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 146, 37, gth, "Enchantment Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the Enchantment spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Evocation" );
			AddHtml( 295, 37, 123, 160, "Enchantment spells affect the minds or behavior of others, either through subtle or overt means.  The intelligence of the wizard consumes the target.", false, false );
			i++;
			
			for( int j = 0; j < EnchantmentSpells.Count; j++)
			{
				MagicianSpell mspell = EnchantmentSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 166, 17, 0x4C1, "Enchantment" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter6( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 170, 17, 0x4C1, "Evocation" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 150, 37, gth, "Evocation Spells" );
			AddHtml( 140, 59, 123, 132, "This chapter contains all the Evocation spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Enchantment" );
			AddLabel( 140, 177, 0x455, "Conjuration");
			AddHtml( 295, 37, 123, 160, "Evocation spells manipulate energy, and pure magical force.  This is the most offensive-based school of all.", false, false );
			i++;
			
			for( int j = 0; j < EvocationSpells.Count; j++)
			{
				MagicianSpell mspell = EvocationSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 170, 17, 0x4C1, "Evocation" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter7( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 170, 17, 0x4C1, "Illusion" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 150, 37, gth, "Illusion Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the Illusion spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Necromancy" );
			AddHtml( 295, 37, 123, 160, "Illusion spells affect the senses of others, by creating false sensory input in the minds of others, or by creating semi-real objects created from shadows.", false, false );
			i++;
			
			for( int j = 0; j < IllusionSpells.Count; j++)
			{
				MagicianSpell mspell = IllusionSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 170, 17, 0x4C1, "Illusion" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter8( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 166, 17, 0x4C1, "Necromancy" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 145, 37, gth, "Necromancy Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the Necromancy spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Illusion" );
			AddHtml( 295, 37, 123, 160, "Necromancy spells manipulate life force, the flesh of organic beings, energies from the negative plane, and all things to do with the undead.", false, false );
			i++;
			
			for( int j = 0; j < NecromancySpells.Count; j++)
			{
				MagicianSpell mspell = NecromancySpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 170, 17, 0x4C1, "Necromancy" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		public int Chapter9( int i )
		{
			AddPage( i );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
			AddLabel( 161, 17, 0x4C1, "Transmutation" );
			AddLabel( 315, 17, 0x4C1, "Introduction" );
			AddLabel( 140, 37, gth, "Transmutation Spells" );
			AddHtml( 140, 59, 123, 88, "This chapter contains all the Transmutation spells you know, master.", false, false );
			AddLabel( 140, 137, gth, "Opposite Schools:");
			AddLabel( 140, 157, 0x455, "Abjuration" );
			AddHtml( 295, 37, 123, 160, "Transmutation spells alter or enhance the properties of objects, creatures, or physical laws of reality.  Unlike illusions, these effects are real, if only temporary.", false, false );
			i++;
			
			for( int j = 0; j < TransmutationSpells.Count; j++)
			{
				MagicianSpell mspell = TransmutationSpells[j] as MagicianSpell;
				AddPage( i );
				AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, i+1 );
				AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, i-1 );
				AddLabel( 161, 17, 0x4C1, "Transmutation" );
				AddLabel( 311, 17, 0x4C1, this.ComputeLevel(mspell.SpellLevel) );
				AddLabel( 150, 37, gth, mspell.Name );
				AddLabel( 140, 157, gth, "Ready to Cast:  " + this.NumberPrepared(mspell.SpellNumber) );
				AddLabel( 140, 177, gth, "Preparing:  " + this.NumberPreparing(mspell.SpellNumber) );
				AddHtml( 140, 59, 123, 88, mspell.Desc, false, false );
				AddLabel( 295, 37, gth, "Reagents:" );
				AddHtml( 295, 59, 123, 88, mspell.ReagentsDesc, false, false );
				AddButton( 295, 157, 0x8DD, 0x8DD, mspell.SpellNumber, GumpButtonType.Reply, 1 );
				AddLabel( 345, 157, gth, "To cast," );
				AddLabel( 345, 177, gth, "click symbol" );
				i++;
			}
			
			return i;
		}
		
		
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			if ((info.ButtonID >= 300)&&(info.ButtonID <=400))
			{
				Spell spell = SpellRegistry.NewSpell( info.ButtonID, state.Mobile, null );
				spell.Cast();
			}
			else if (info.ButtonID == 1000)
			{
				m_Dark.CloseGump( typeof( PrepareSpellGump ) );
				m_Dark.SendGump( new PrepareSpellGump(m_Dark) );
			}
		}
	}
}
