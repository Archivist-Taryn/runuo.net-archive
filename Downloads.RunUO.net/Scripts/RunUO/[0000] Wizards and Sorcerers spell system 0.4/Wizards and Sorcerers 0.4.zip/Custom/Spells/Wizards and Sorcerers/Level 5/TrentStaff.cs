using System;
using Server.Network;
using Server.Items;
using Server.Mobiles;
using Server.Spells;

namespace Server.Items
{
	[FlipableAttribute( 0x13F8, 0x13F9 )]
	public class TrentStaff : BaseTransmuteStaff
	{

		[Constructable]
		public TrentStaff() : base( 0x13F8 )
		{
			Weight = 3.0;
		}

		public TrentStaff( Serial serial ) : base( serial )
		{
		}

		public override void OnTransmute( Mobile from )
		{
			BaseCreature creature = new SummonedTreefellow();
			TimeSpan duration;
			duration = TimeSpan.FromMinutes( (2 * from.Skills.Magery.Fixed));
			SpellHelper.Summon( creature, from, 0x215, duration, false, false );
			this.Delete();
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
