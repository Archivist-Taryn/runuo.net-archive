using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class BoneWallScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public BoneWallScroll() : this( 1 )
		{
		}

		[Constructable]
		public BoneWallScroll( int amount ) : base( 314, 0x1F2E, amount )
		{
			Name = "Wall of Bone";
		}
		
		public BoneWallScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
