using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Gumps;
using Server.Prompts;
using Server.Multis;
using Server.Misc;
using Server.Regions;

namespace Server.Spells.Magician
{
	public class DimensionDoorSpell : MagicianSpell
	{
		public static void MoonGateAction( Mobile mob, RunebookEntry entry )
		{
			Map map = entry.Map;
			Point3D p = entry.Location;
			mob.SendMessage( "You've opened a door from a memorized location." ); 

			Effects.PlaySound( mob.Location, mob.Map, 0x20E );

			DimensionDoor firstdoor = new DimensionDoor( p, map );
			firstdoor.MoveToWorld( mob.Location, mob.Map );

			Effects.PlaySound( p, map, 0x20E );

			DimensionDoor seconddoor = new DimensionDoor( mob.Location, mob.Map );
			seconddoor.MoveToWorld( p, map );
		}
		
		
		private static SpellInfo m_Info = new SpellInfo(
				"Dimension Door", "Lor Tosinos",
				Reagent.SpidersSilk,
				Reagent.SpidersSilk,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss
			);
		
		public override string Desc{ get{ return "Saves 2 locations that you can open a door between."; } }
		public override string ReagentsDesc{ get{ return "Two Spider's Silk, Three Bloodmoss."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fifth; } }
        public override int SpellNumber { get { return 363; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Conjuration; } }

		public DimensionDoorSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
			
		}
		
		public override void OnCast()
		{
			if(CheckSequence())
			{
				Caster.SendGump( new MoonGateGump( Caster ) );
			}
			FinishSequence();
		}
	}

	public class PlaceNamePrompt2 : Prompt
	{
		private int n;
		
		public PlaceNamePrompt2( int i )
		{
			n = i;
		}
		
		public override void OnResponse( Mobile from, string text )
		{
			from.SendMessage("You've saved a location to your memory.");
			PolyGlotMobile dark = from as PolyGlotMobile;
			
			if(text.Length > 15)
				text = text.Substring(0, 15);
			
			dark.MoonGateEntries[n] = new RunebookEntry(dark.Location, dark.Map, text, null);
		}
	}
	
	
	public class AddMoonGateGump : Gump
	{
		private Mobile m_Caster;
		private int m_Spot;
		public AddMoonGateGump(Mobile Caster, int Spot)
			: base( 50, 50 )
		{
			m_Caster = Caster;
			m_Spot = Spot;
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			this.AddPage(0);
			this.AddBackground(144, 119, 209, 190, 9300);
			this.AddImage(154, 133, 57);
			this.AddImageTiled(182, 133, 134, 15, 58);
			this.AddImage(310, 133, 59);
			this.AddImage(154, 282, 57);
			this.AddImageTiled(182, 282, 134, 15, 58);
			this.AddImage(310, 282, 59);
			this.AddLabel(178, 161, 0, @"Are you sure you want to");
			this.AddLabel(163, 179, 0, @"add your current location to");
			this.AddLabel(161, 197, 0, @"your list of memorized locations?");
			this.AddButton(178, 250, 247, 248, 0, GumpButtonType.Reply, 0);
			this.AddButton(258, 250, 241, 242, 1, GumpButtonType.Reply, 1);

		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			switch ( info.ButtonID )
			{
			
				case 0:
					{
						state.Mobile.SendMessage("Please name your new location. (15 character max)");
						state.Mobile.Prompt = new PlaceNamePrompt2(m_Spot);
						break;
					}
				case 1:
					{
						state.Mobile.SendMessage("You've decided not to save a location at this time.");
						state.Mobile.SendGump( new MoonGateGump( state.Mobile ) );
						break;
					}
				default:
					{
						break;
					}
			}
		}
	}

	public class MoonGateGump : Gump
	{
		private Mobile m_Caster;
		private RunebookEntry[] MoonGateEntries;
		public MoonGateGump(Mobile Caster) : base( 50, 50 )
		{
			m_Caster = Caster;
			PolyGlotMobile dark = Caster as PolyGlotMobile;
			MoonGateEntries = dark.MoonGateEntries;
			
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;

			this.AddPage(0);

			this.AddBackground(31, 30, 470, 372, 9300);
			this.AddImage(45, 45, 57);
			this.AddImage(455, 45, 59);
			this.AddImageTiled(70, 45, 390, 12, 58);
			this.AddImage(45, 374, 57);
			this.AddImage(455, 374, 59);
			this.AddImageTiled(70, 374, 390, 12, 58);
			this.AddImage(60, 100, 2087);
			this.AddImage(60, 300, 2087);
			this.AddImage(60, 250, 2087);
			this.AddImage(60, 200, 2087);
			this.AddImage(60, 150, 2087);

			this.AddLabel(189, 68, 50, @"Choose Your Location");
			this.AddLabel(174, 342, 50, @"Dimension Door Spell Locations");

			if(MoonGateEntries[0].Description == "null")
				this.AddLabel(80, 97, 50, @"Empty Location");
			else
			{
				this.AddLabel(80, 97, 50, @MoonGateEntries[0].Description);
				this.AddButton(240, 97, 247, 248, 0, GumpButtonType.Reply, 0);
			}
			
			if(MoonGateEntries[1].Description == "null")
				this.AddLabel(80, 147, 50, @"Empty Location");
			else
			{
				this.AddLabel(80, 147, 50, @MoonGateEntries[1].Description);
				this.AddButton(240, 147, 247, 248, 1, GumpButtonType.Reply, 1);
			}

			this.AddButton(400, 97, 22153, 22154, 2, GumpButtonType.Reply, 2);
			this.AddButton(400, 147, 22153, 22154, 3, GumpButtonType.Reply, 3);

			this.AddLabel(345, 97, 50, @"Set");
			this.AddLabel(345, 147, 50, @"Set");
		}

		public override void OnResponse( NetState state, RelayInfo info )
		{
			PlayerMobile m = state.Mobile as PlayerMobile;

			switch ( info.ButtonID )
			{
				case 0:
					{
						DimensionDoorSpell.MoonGateAction( m_Caster, MoonGateEntries[0] );
						break;
					}
				case 1:
					{
						DimensionDoorSpell.MoonGateAction( m_Caster, MoonGateEntries[1] );
						break;
					}
				case 2:
					{
						m.SendGump( new AddMoonGateGump( m_Caster, 0 ) );
						break;
					}
				case 3:
					{
						m.SendGump( new AddMoonGateGump( m_Caster, 1 ) );
						break;
					}

				default:
					{
						break;
					}
			}
		}
	}

		[DispellableField]
		public class DimensionDoor : Moongate
		{
			public DimensionDoor( Point3D target, Map map ) : base( target, map )
			{
				Map = map;

				Dispellable = true;

				DimensionDoorTimer t = new DimensionDoorTimer( this );
				t.Start();
			}

			public DimensionDoor( Serial serial ) : base( serial )
			{
			}

			public override void Serialize( GenericWriter writer )
			{
				base.Serialize( writer );
			}

			public override void Deserialize( GenericReader reader )
			{
				base.Deserialize( reader );

				Delete();
			}

			private class DimensionDoorTimer : Timer
			{
				private Item m_Item;

				public DimensionDoorTimer( Item item ) : base( TimeSpan.FromSeconds( 30.0 ) )
				{
					Priority = TimerPriority.OneSecond;
					m_Item = item;
				}

				protected override void OnTick()
				{
					m_Item.Delete();
				}
			}
		}
}


