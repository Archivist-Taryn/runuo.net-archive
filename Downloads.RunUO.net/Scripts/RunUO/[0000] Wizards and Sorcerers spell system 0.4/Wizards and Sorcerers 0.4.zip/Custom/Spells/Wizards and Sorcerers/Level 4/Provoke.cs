using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class ProvokeSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Provoke", "Intre Sanrae",
				Reagent.BlackPearl,
				Reagent.Garlic,
				Reagent.MandrakeRoot
			);

		public override string Desc{ get{ return "Provokes a creature."; } } 
		public override string ReagentsDesc{ get{ return "One BlackPearl, Garlic, Mandrake Root."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fourth; } }
        public override int SpellNumber { get { return 364; } }
		public override double CastDelay{ get{ return 7.0; } }
		public override double RequiredSkill{ get{ return 50.0; } }
		public override int RequiredMana{ get{ return 30; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Enchantment; } }

		public ProvokeSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			if(CheckSequence())
			{
				Caster.SendMessage("Whom do you wish to provoke?");
				Caster.Target = new InternalFirstTarget( this );
				Caster.RevealingAction();
			}
			FinishSequence();
		}

		public void Target(Mobile creature)
		{
			if ( creature is BaseCreature && Caster.CanBeHarmful(creature, true ))
			{
				BaseCreature m = (BaseCreature)creature;

				if ( m.Controlled )
				{
					Caster.SendLocalizedMessage( 501590 ); // They are too loyal to their master to be provoked.
				}
				else
				{
					Caster.RevealingAction();
					Caster.SendMessage("Whom do you wish your target to attack?");
					Caster.Target = new InternalSecondTarget( this, m );
				}
			}
			else
				Caster.SendMessage("You can't provoke that!");
		}

		public void Target2(Mobile screature, BaseCreature creature)
		{
			if ( screature is BaseCreature )
			{
				BaseCreature m_creature = creature;
				BaseCreature m_screature = (BaseCreature)screature;

				if ( m_creature.Unprovokable || m_screature.Unprovokable )
				{
					Caster.SendLocalizedMessage( 1049446 ); // You have no chance of provoking those creatures.
				}
				else if ( m_creature.Map != m_screature.Map || !m_creature.InRange( m_screature, 12 ) )
				{
					Caster.SendMessage( "Those creatures are too far apart to provoke!" ); 
				}
				else if ( m_creature != m_screature )
				{
					if ( Caster.CanBeHarmful( m_creature, true ) && Caster.CanBeHarmful( m_screature, true ) )
					{
								Caster.SendMessage( "Your magic starts a fight!" ); 
								m_creature.Provoke( Caster, m_screature, true );
					}
				}
				else
				{
					Caster.SendLocalizedMessage( 501593 ); // You can't tell someone to attack themselves!
				}
			}
		}


		public class InternalFirstTarget : Target
		{
			
			private ProvokeSpell m_Owner;
			public InternalFirstTarget(  ProvokeSpell owner ) : base( 10, false, TargetFlags.None )
			{
				m_Owner = owner;
			}
			protected override void OnTarget( Mobile Caster, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}
			protected override void OnTargetFinish( Mobile Caster )
			{
				m_Owner.FinishSequence();
			}
		}

		public class InternalSecondTarget : Target
		{
			
			private ProvokeSpell m_Owner;
			private BaseCreature m_creature;
			public InternalSecondTarget(  ProvokeSpell owner, BaseCreature m ) : base( 10, false, TargetFlags.None )
			{
				m_Owner = owner;
				m_creature = m;
			}
			protected override void OnTarget( Mobile Caster, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target2( (Mobile)o, m_creature );
				}
			}
			protected override void OnTargetFinish( Mobile Caster )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}


