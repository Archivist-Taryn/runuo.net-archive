using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class SimulacrumSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Simulacrum", "Nurea Inloc",
				17,
				Reagent.BloodSpawn,
				Reagent.BloodSpawn,
				Reagent.BloodSpawn,
				Reagent.SpidersSilk,
				Reagent.NoxCrystal,
				Reagent.NoxCrystal
			);
        public override string Desc { get { return "Creates an illusionary clone of a target other than yourself."; } }
        public override string ReagentsDesc { get { return "Three BloodSpawn, one SpidersSilk, and two NoxCrystals"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Seventh; } }
        public override int SpellNumber { get { return 362; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 30.0; } }
		public override int RequiredMana{ get{ return 20; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Illusion; } }

		public SimulacrumSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		
		public void Target( PolyGlotMobile m )
		{
			if ( !Caster.CanSee( m as Mobile ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( Caster == m )
			{
				Caster.SendMessage("You cannot target yourself with this spell.");
			}
			else if ( CheckSequence() )
			{
				SpellHelper.Summon( new DSSimulacrum( m ), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
			}
			
			FinishSequence();
		}
		
		public class InternalTarget : Target
		{
			private SimulacrumSpell m_Owner;

			public InternalTarget( SimulacrumSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is PolyGlotMobile )
					m_Owner.Target( (PolyGlotMobile)o );
				else
					m_Owner.Caster.SendMessage("You cannot target that.");
			}

		}
		
	}
}

