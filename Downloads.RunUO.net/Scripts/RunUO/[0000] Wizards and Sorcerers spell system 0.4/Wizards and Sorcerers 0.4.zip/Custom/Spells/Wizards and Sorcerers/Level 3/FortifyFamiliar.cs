using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using System.Collections;

namespace Server.Spells.Magician
{
	public class FortifyFamiliarSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
		        "Fortify Familiar", "Mit Viver Similt",
		        Reagent.Bloodmoss,
		        Reagent.PigIron,
		        Reagent.PigIron
		    );
		
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override string Desc{ get{ return "Enhances your familiar's defenses."; } }
		public override string ReagentsDesc{ get{ return "One Bloodmoss, One BloodSpawn."; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Universal; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 355; } }
		
		private bool permy;
		
		public FortifyFamiliarSpell( Mobile caster, Item scroll, bool perm ) : base( caster, scroll, m_Info )
		{
			permy = perm;
		}
		
		public FortifyFamiliarSpell( Mobile caster, Item scroll ) : this( caster, scroll, false )
		{
			
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		
		public void Target( Mobile m )
		{
			int time = 200; //Utility.Random(0,((int)(Caster.Skills[SkillName.EvalInt].Value + Caster.Skills[SkillName.Magery].Value + Caster.Int) / 3) ); // The length of the spell is the Caster's Int plus the Caster's Magery plus the Caster's Evaluate Intelligence skills added together then divided by 3
			TimeSpan span = TimeSpan.FromSeconds((int)time);
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckBSequence( m ) )
			{
				if( m is Familiar) // Checks to see if the target is a Familiar
				{
					Familiar fam = m as Familiar;
					if(fam.ControlMaster == Caster) // Checks to see if the target is the Caster's Familiar
					{
						if(permy)
						{
							if(!fam.Fortified)
							{
                                //fam.FireResist += 25;
                                //fam.AcidResist += 25;
                                //fam.ColdResist += 25;
                                //fam.EnergyResist += 25;
                                //fam.PoisonResist += 25;
                                //fam.BludgeoningResist += 25;
                                //fam.PiercingResist += 25;
                                //fam.SlashingResist += 25;
								fam.Fortified = true;
							}
							else
							{
								Caster.SendMessage("That familiar already is Fortified!");
							}
						}
						else
						{
                            //CustomResistanceMod fire = new CustomResistanceMod( fam, ResistType.Fire, "Fire", 25, span, false);
                            //fam.AddResistMod( fire );
                            //CustomResistanceMod cold = new CustomResistanceMod( fam, ResistType.Cold, "Cold", 25, span, false);
                            //fam.AddResistMod( cold );
                            //CustomResistanceMod energy = new CustomResistanceMod( fam, ResistType.Energy, "Energy", 25, span, false);
                            //fam.AddResistMod( energy );
                            //CustomResistanceMod acid = new CustomResistanceMod( fam, ResistType.Acid, "Acid", 25, span, false);
                            //fam.AddResistMod( acid );
                            //CustomResistanceMod poison = new CustomResistanceMod( fam, ResistType.Poison, "Poison", 25, span, false);
                            //fam.AddResistMod( poison );
                            //CustomResistanceMod piercing = new CustomResistanceMod( fam, ResistType.Piercing, "Piercing", 25, span, false);
                            //fam.AddResistMod( piercing );
                            //CustomResistanceMod bludgeoning = new CustomResistanceMod( fam, ResistType.Bludgeoning, "Bludgeoning", 25, span, false);
                            //fam.AddResistMod( bludgeoning );
                            //CustomResistanceMod slashing = new CustomResistanceMod( fam, ResistType.Slashing, "Slashing", 25, span, false);
                            //fam.AddResistMod( slashing );
						}
						SpellHelper.Turn( Caster, fam as Mobile );
						fam.Emote("You see "+fam.Name+"'s skin grow hard");
						fam.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
						fam.PlaySound( 0x1EE );
					}
					else
					{
						Caster.SendMessage("This is not your familiar!");
					}
				}
				else
				{
					Caster.SendMessage("You can not fortify this!");
				}
			}
			FinishSequence();		

		}
		
		private class InternalTarget : Target
		{
			private FortifyFamiliarSpell m_Owner;
			
			public InternalTarget( FortifyFamiliarSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			}
			
			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}
			
			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	} // end spell class
} // end namespace

