using System;
using Server;
using Server.Network;
using Server.Targets;
using Server.Spells;
using Server.Spells.Magician;

namespace Server.Gumps
{
	public class PolymorphOtherGump : Gump
	{
		private class PolymorphOtherEntry
		{
			private int m_Art, m_Body, m_Num;

			public PolymorphOtherEntry( int Art, int Body, int LocNum )
			{
				m_Art = Art;
				m_Body = Body;
				m_Num = LocNum;
			}

			public int ArtID { get { return m_Art; } }
			public int BodyID { get { return m_Body; } }
			public int LocNumber{ get { return m_Num; } }
		}

		private class PolymorphOtherCategory
		{
			private int m_Num;
			private PolymorphOtherEntry[] m_Entries;

			public PolymorphOtherCategory( int num, PolymorphOtherEntry[] entries )
			{
				m_Num = num;
				m_Entries = entries;
			}

			public PolymorphOtherEntry[] Entries{ get { return m_Entries; } }
			public int LocNumber{ get { return m_Num; } }
		}

		private static PolymorphOtherCategory[] Categories = new PolymorphOtherCategory[]
		{
			new PolymorphOtherCategory( 1015235, new PolymorphOtherEntry[] //Animals
			{
				new PolymorphOtherEntry( 8401, 0xD0, 1015236 ),//Chicken
				new PolymorphOtherEntry( 8405, 0xD9, 1015237 ),//Dog
				new PolymorphOtherEntry( 8426, 0xE1, 1015238 ),//Wolf
				new PolymorphOtherEntry( 8473, 0xD6, 1015239 ),//Panther
				new PolymorphOtherEntry( 8437, 0x1D, 1015240 ),//Gorilla
				new PolymorphOtherEntry( 8399, 0xD3, 1015241 ),//Black Bear
				new PolymorphOtherEntry( 8411, 0xD4, 1015242 ),//Grizzly Bear
				new PolymorphOtherEntry( 8417, 0xD5, 1015243 ),//Polar Bear
				new PolymorphOtherEntry( 8397, 0x190, 1015244 )//Human Male
			} ),

			new PolymorphOtherCategory( 1015245, new PolymorphOtherEntry[] //Monsters
			{
				new PolymorphOtherEntry( 8424, 0x33, 1015246 ),//Slime
				new PolymorphOtherEntry( 8416, 0x11, 1015247 ),//Orc
				new PolymorphOtherEntry( 8414, 0x21, 1015248 ),//Lizard Man
				new PolymorphOtherEntry( 8409, 0x04, 1015249 ),//Gargoyle
				new PolymorphOtherEntry( 8415, 0x01, 1015250 ),//Orge
				new PolymorphOtherEntry( 8425, 0x36, 1015251 ),//Troll
				new PolymorphOtherEntry( 8408, 0x02, 1015252 ),//Ettin
				new PolymorphOtherEntry( 8403, 0x09, 1015253 ),//Daemon
				new PolymorphOtherEntry( 8398, 0x191, 1015254 ),//Human Female
			} )
		};

		private Mobile m_Target;
		private Item m_Scroll;
		private PolymorphOtherSpell m_Spell;

		public PolymorphOtherGump( Mobile targ, Item scroll, PolymorphOtherSpell spell ) : base( 50, 50 )
		{
			m_Target = targ;
			m_Scroll = scroll;
			m_Spell = spell;
			
			Closable = false;
			Disposable = false;
			Dragable = false;
			Resizable = false;

			int x,y;
			AddPage( 0 );
			AddBackground( 0, 0, 585, 393, 5054 );
			AddBackground( 195, 36, 387, 275, 3000 );
			AddHtmlLocalized( 0, 0, 510, 18, 1015234, false, false ); // <center>Polymorph Selection Menu</center>
			AddHtmlLocalized( 60, 355, 150, 18, 1011036, false, false ); // OKAY
			AddButton( 25, 355, 4005, 4007, 1, GumpButtonType.Reply, 1 );
			AddHtmlLocalized( 320, 355, 150, 18, 1011012, false, false ); // CANCEL
			AddButton( 285, 355, 4005, 4007, 0, GumpButtonType.Reply, 2 );

			y = 35;
			for ( int i=0;i<Categories.Length;i++ )
			{
				PolymorphOtherCategory cat = (PolymorphOtherCategory)Categories[i];
				AddHtmlLocalized( 5, y, 150, 25, cat.LocNumber, true, false );
				AddButton( 155, y, 4005, 4007, 0, GumpButtonType.Page, i+1 );
				y += 25;
			}

			for ( int i=0;i<Categories.Length;i++ )
			{
				PolymorphOtherCategory cat = (PolymorphOtherCategory)Categories[i];
				AddPage( i+1 );

				for ( int c=0;c<cat.Entries.Length;c++ )
				{
					PolymorphOtherEntry entry = (PolymorphOtherEntry)cat.Entries[c];
					x = 198 + (c%3)*129;
					y = 38 + (c/3)*67;

					AddHtmlLocalized( x, y, 100, 18, entry.LocNumber, false, false );
					AddItem( x+20, y+25, entry.ArtID );
					AddRadio( x, y+20, 210, 211, false, (c<<8) + i );
				}
			}
		}

		public override void OnResponse( NetState state, RelayInfo info )
		{
			if ( info.ButtonID == 1 && info.Switches.Length > 0 )
			{
				int cnum = info.Switches[0];
				int cat = cnum%256;
				int ent = cnum>>8;

				if ( cat < Categories.Length )
				{
					if ( ent < Categories[cat].Entries.Length )
					{
						m_Spell.OnGumpPick(Categories[cat].Entries[ent].BodyID);
					}
				}
			}
		}
	}
}
