using System;
using System.Collections;
using Server.Network;
using Server.Items;
using Server.Targeting;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class ChainLightningMSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Chain Lightning", "Lin Shrik Masse",
				17,
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss
			);

		public override string Desc{ get{ return "Unleash chain lightning upon your enemies."; } }
		public override string ReagentsDesc{ get{ return "Four MandrakeRoots, Two Bloodmoss"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Sixth; } }
        public override int SpellNumber { get { return 306; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 75.0; } }
		public override int RequiredMana{ get{ return 50; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }
		
		public ChainLightningMSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return true; } }

		public void Target( IPoint3D p )
		{
			if ( !Caster.CanSee( p ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( SpellHelper.CheckTown( p, Caster ) && CheckSequence() )
			{
				SpellHelper.Turn( Caster, p );

				if ( p is Item )
					p = ((Item)p).GetWorldLocation();

				int damage = Utility.Random( 27, 22 );

				ArrayList targets = new ArrayList();

				Map map = Caster.Map;

				if ( map != null )
				{
					IPooledEnumerable eable = map.GetMobilesInRange( new Point3D( p ), 2 );

					foreach ( Mobile m in eable )
					{
						if ( Core.AOS && m == Caster )
							continue;

						if ( SpellHelper.ValidIndirectTarget( Caster, m ) && Caster.CanBeHarmful( m, false ) )
							targets.Add( m );
					}

					eable.Free();
				}

				if ( targets.Count > 0 )
				{

					for ( int i = 0; i < targets.Count; ++i )
					{
						Mobile m = (Mobile)targets[i];
						
						m.BoltEffect( 0 );
						
						Caster.DoHarmful( m );
						//damage = AbsorbDamage(m, ResistType.Energy, damage);
						m.Damage( damage );

						
					}
				}
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private ChainLightningMSpell m_Owner;

			public InternalTarget( ChainLightningMSpell owner ) : base( 12, true, TargetFlags.None )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				IPoint3D p = o as IPoint3D;

				if ( p != null )
					m_Owner.Target( p );
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
