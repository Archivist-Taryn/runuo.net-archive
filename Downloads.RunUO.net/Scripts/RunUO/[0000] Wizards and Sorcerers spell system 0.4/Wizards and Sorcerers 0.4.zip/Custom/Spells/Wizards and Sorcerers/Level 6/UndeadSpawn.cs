using System;
using System.Collections;
using Server.Items;
using Server.Targeting;

namespace Server.Mobiles
{
	[CorpseName( "an Ghostly Corpse" )]
	public class UndeadSpawn : BaseCreature
	{
		public override double DispelDifficulty{ get{ return 85.0; } }
		public override double DispelFocus{ get{ return 45.0; } }
		[Constructable]
		public UndeadSpawn(string name, int body, int hits, int karma, int fame, int damage, int va ) : base( AIType.AI_Melee, FightMode.Closest, 10, 1, 0.3, 0.5 )
		{
			Container pack = this.Backpack;

			if ( pack != null )
				pack.Delete();

			NoKillAwards = true;

			Name = (name + "'s Shade");
			Body = body;
			BaseSoundID = 0x482;
			Hue = 0x4001;
			SetStr( 63, 80 );
			SetDex( 56, 95 );
			SetInt( 30, 60 );

			SetHits( hits, (hits + 10) );
			SetMana( 0 );

			SetDamage( 5, (damage + 5) );

			SetSkill( SkillName.Poisoning, 45.1, 75.0 );
			SetSkill( SkillName.MagicResist, 15.1, 35.0 );
			SetSkill( SkillName.Tactics, 45.3, 70.0 );
			SetSkill( SkillName.Wrestling, 40.3, 55.0 );

			Fame = fame;
			Karma = karma;

			VirtualArmor = va;

			Tamable = false;
			ControlSlots = 1;

		}
		public override Poison PoisonImmune{ get{ return Poison.Deadly; } } // TODO: Immune to poison?

		public UndeadSpawn( Serial serial ) : base( serial )
		{
		}

		public override void OnDeath( Container c )
		{
			base.OnDeath( c );

			c.Delete();
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}