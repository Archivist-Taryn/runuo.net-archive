using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class ExplosionMSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Explosion", "Flam Vorte",
				Reagent.SulfurousAsh,
				Reagent.GraveDust,
				Reagent.MandrakeRoot
			);
		public override string Desc{ get{ return "The target goes... Boom!"; } }
		public override string ReagentsDesc{ get{ return "SulfurousAsh, MandrakeRoot, GraveDust"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fourth; } }
        public override int SpellNumber { get { return 304; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 60.0; } }
		public override int RequiredMana{ get{ return 40; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }

		public ExplosionMSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return false; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( Caster.CanBeHarmful( m ) && CheckSequence() )
			{
				Mobile attacker = Caster, defender = m;

				SpellHelper.Turn( Caster, m );

				SpellHelper.CheckReflect( (int)this.SpellLevel, Caster, ref m );

				InternalTimer t = new InternalTimer( this, attacker, defender, m );
				t.Start();
			}

			FinishSequence();
		}

		private class InternalTimer : Timer
		{
			private Spell m_Spell;
			private Mobile m_Target;
			private Mobile m_Attacker, m_Defender;

			public InternalTimer( Spell spell, Mobile attacker, Mobile defender, Mobile target ) : base( TimeSpan.FromSeconds( Core.AOS ? 3.0 : 2.5 ) )
			{
				m_Spell = spell;
				m_Attacker = attacker;
				m_Defender = defender;
				m_Target = target;

				Priority = TimerPriority.FiftyMS;
			}

			protected override void OnTick()
			{
				//if ( m_Attacker.HarmfulCheck( m_Defender ) )
				
				int damage = Utility.Random( 23, 22 );
				
				m_Target.FixedParticles( 0x36BD, 20, 10, 5044, EffectLayer.Head );
				m_Target.PlaySound( 0x307 );

				m_Attacker.DoHarmful( m_Target );
				//damage = AbsorbDamage(m_Target, ResistType.Fire, damage);
				m_Target.Damage( damage );
			}
		}

		private class InternalTarget : Target
		{
			private ExplosionMSpell m_Owner;

			public InternalTarget( ExplosionMSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
					m_Owner.Target( (Mobile)o );
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
