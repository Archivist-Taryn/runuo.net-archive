using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class FireBlastScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public FireBlastScroll() : this( 1 )
		{
		}

		[Constructable]
		public FireBlastScroll( int amount ) : base( 301, 0x1F2E, amount )
		{
			Name = "Fire Blast";
		}
		
		public FireBlastScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
