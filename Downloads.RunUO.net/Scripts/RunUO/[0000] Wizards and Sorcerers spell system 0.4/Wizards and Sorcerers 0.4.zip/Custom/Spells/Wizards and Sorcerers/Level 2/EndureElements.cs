using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Gumps;

namespace Server.Spells.Magician
{
	public class EndureElementsSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Endure Elements", "Mit Combinrae Mor",
				Reagent.Ginseng,
				Reagent.BatWing
			);
		public override string Desc{ get{ return "Grants a creature limited protection from your choice of damage."; } }
		public override string ReagentsDesc{ get{ return "One Ginseng, Bat Wing."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Second; } }
        public override int SpellNumber { get { return 348; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 15.0; } }
		public override int RequiredMana{ get{ return 10; } }
	
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Abjuration; } }

		public EndureElementsSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( Mobile m )
		{
			if ( m is PolyGlotMobile )
			{
				if ( !Caster.CanSee( m ) )
				{
					Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
				}
				else if ( CheckBSequence( m ) )
				{
					SpellHelper.Turn( Caster, m );
					
					Caster.SendGump( new EndureElementsGump(Caster, m) );
					m.PlaySound( 0x1EE );
				}
			}
			else
				Caster.SendMessage("Cannot cast on that creature.");

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private EndureElementsSpell m_Owner;

			public InternalTarget( EndureElementsSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			} 

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
