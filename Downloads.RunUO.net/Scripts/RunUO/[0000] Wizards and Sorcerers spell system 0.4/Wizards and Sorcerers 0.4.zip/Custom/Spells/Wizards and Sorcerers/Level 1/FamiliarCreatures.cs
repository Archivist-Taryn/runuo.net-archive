using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;
using Server.Gumps;
using Server.Items;
using Server.Spells.Magician;

namespace Server.Mobiles
{
	public abstract class Familiar : BaseCreature
	{	
		#region public/private variable declarations
		
		private Mobile m_FamMaster;
		
		public Mobile FamMaster
		{
			get{ return m_FamMaster; }
		}
		
		private bool m_MasterBonus;
		
		public bool MasterBonus
		{
			get{ return m_MasterBonus; }
			set
			{ 
				m_MasterBonus = value;
				if (m_MasterBonus)
					this.MasterSpecial();
				else
					this.UnMasterSpecial();
			}
		}
		
		private bool m_Enchanced;
		
		public bool Enhanced
		{
			get{ return m_Enchanced; }
			set
			{ 
				m_Enchanced = (value || m_Permanence[0]); 
				this.Enhance();
			}
		}
		
		private bool m_Imbued;
		
		public bool Imbued
		{
			get{ return m_Imbued; }
			set
			{ 
				m_Imbued = (value || m_Permanence[1]); 
				this.Imbue();
			}
		}
		
		private bool m_Fortified;
		
		public bool Fortified
		{
			get{ return m_Fortified; }
			set
			{ 
				m_Fortified = (value || m_Permanence[2]); 
				this.Fortify();
			}
		}
		
		private bool m_Pocket;
		
		public bool Pocket
		{
			get{ return ( m_Pocket ); }
			set{ m_Pocket = value; }
		}
		
		private bool[] m_Permanence;
		
		public bool[] Permanence
		{
			get{ return m_Permanence; }
			set{ m_Permanence = value; }
		}
		
		private FamiliarType m_Type = FamiliarType.None;
		
		[CommandProperty( AccessLevel.GameMaster )]
		public FamiliarType FType
		{
			get {return m_Type;}
			set { m_Type = value;}
		}
		#endregion
		
		#region virtual function declarations

		public virtual void MasterSpecial()
		{
			
		}
		
		public virtual void UnMasterSpecial()
		{
			
		}
		
		public virtual void Fortify()
		{
			
		}
		
		public virtual void UnFortify()
		{
			
		}
		
		public virtual void Imbue()
		{
			
		}
		
		public virtual void UnImbue()
		{
			
		}
		
		public virtual void Enhance()
		{
			
		}
		
		public virtual void UnEnhance()
		{
			
		}
		
		public virtual void InPocket()
		{
			
		}
		
		public virtual void OutPocket()
		{
			
		}
		#endregion
		
		public Familiar(Mobile m) : base( AIType.AI_Melee, FightMode.Weakest , 10, 1, 0.2, 0.4 )
		{
			SetDamage( 10, 20 );
			
			SetSkill( SkillName.Wrestling, 40.1, 70.0 );
			SetSkill( SkillName.Tactics, 50.0 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			if (dark.FamiliarName != null)
				this.Name = dark.FamiliarName;
			else
				this.Name = "Familiar of " + m.Name;
			
			dark.FamiliarName = this.Name;
			
			SpeechHue = 1170;
			CanHearGhosts = true;
			
			m_MasterBonus = false;
			m_Enchanced = false;
			m_Imbued = false;
			m_Fortified = false;
			m_Pocket = false;
			
			Permanence = new bool[3];
			for( int i=0; i < Permanence.Length; i++)
			{
				Permanence[i] = false;
			}
			
			
			Summoned = false;
			SummonMaster = null;
			
			Map = m.Map;
			Location = m.Location;
			Controlled = true;
			ControlMaster = m;
			IsBonded = true;
			ControlTarget = m;
			ControlOrder = OrderType.Follow;
			
			ControlSlots = 0;
			
			m_FamMaster = m;
			MasterSpecial();
		}
		
		public Familiar( Serial serial ) : base( serial )
		{
		}	
		
		public override void OnThink()
		{
			base.OnThink();
			
			TimeSpan ugh = new TimeSpan(1, 0, 0);
			OwnerAbandonTime = DateTime.Now + ugh;
			
			Mobile master = ControlMaster;

			if ( master == null )
			{
				return;
			}
			
			if (master.Hidden)
				Hidden = true;

			Mobile toAttack = null;

			if ( !Hidden )
			{
				toAttack = master.Combatant;

				if ( toAttack == this )
					this.Combatant = null;
				else
					this.Combatant = toAttack;
			}
			else if (ControlOrder != OrderType.Stay)
			{
				if((ControlOrder != OrderType.Follow)&&(ControlOrder != OrderType.Come)&&(ControlOrder != OrderType.Attack)&&(ControlOrder != OrderType.Guard))
				{
					ControlTarget = null;
					ControlOrder = OrderType.Stay;
				}
			}

			if ( Combatant != toAttack )
				Combatant = null;

			if (( toAttack == null )&&(!Hidden)&&(ControlOrder != OrderType.Stay))
			{
				if ( ControlTarget != master || ControlOrder != OrderType.Follow )
				{
					ControlTarget = master;
					ControlOrder = OrderType.Follow;
				}
			}
		}
		
		public override void Delete()
		{
			if (this.CheckAlive())
					UnMasterSpecial();
			
			PolyGlotMobile dark = m_FamMaster as PolyGlotMobile;
			dark.FamiliarName = this.Name;
			base.Delete();
		}
		
		public override void OnDeath( Container c )
		{
			PolyGlotMobile dark = m_FamMaster as PolyGlotMobile;
			dark.FamiliarName = this.Name;
			m_FamMaster.Damage( m_FamMaster.HitsMax / 2 );
			UnMasterSpecial();
			base.OnDeath(c);
		}
		
		public override void OnAfterResurrect()
		{
			MasterSpecial();
			base.OnAfterResurrect();
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
			
			writer.Write( (Mobile) m_FamMaster );
			
			writer.Write( (int) Permanence.Length );
			for( int i=0; i < Permanence.Length; i++)
			{
				writer.Write( (bool) Permanence[i] );
			}
			
			writer.Write( (bool)m_MasterBonus );
			writer.Write( (bool)m_Pocket );
			writer.Write( (bool)m_Fortified );
			writer.Write( (bool)m_Enchanced );
			writer.Write( (bool)m_Imbued );
			writer.Write( (int)m_Type );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			switch( version )
			{
				case 0:	
				{
					m_FamMaster = reader.ReadMobile();
					
					Permanence = new bool[reader.ReadInt()];
					for( int i=0; i < Permanence.Length; i++)
					{
						Permanence[i] = reader.ReadBool();
					}
					
					m_MasterBonus = reader.ReadBool();
					m_Pocket = reader.ReadBool();
					m_Fortified = reader.ReadBool();
					m_Enchanced = reader.ReadBool();
					m_Imbued = reader.ReadBool();
					m_Type = (FamiliarType) reader.ReadInt();
					break;
				}
				
			}
		}
		
	}
	
	public class FamiliarBat : Familiar
	{
		public FamiliarBat(Mobile m) : base( m )
		{
			Body = 317;
			BaseSoundID = 0x270;
			this.FType = FamiliarType.Bat;
			
			SetStr( 40 );
			SetDex( 50 );
			SetInt( 50 );
			SetHits( 150 );
			SetStam( 150 );
			SetMana( 100 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			dark.Familiar = this as Familiar;
		}
		
		public override void MasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
			//dark.HitsMod += 30;
			//dark.StamMod -= 10;
			
			//int temphits = dark.Hits;
			//dark.Hits = dark.HitsMax;
			//dark.Hits = temphits;
			
			//int tempstam = dark.Stam;
			//dark.Stam = dark.StamMax;
			//dark.Stam = tempstam;
			
		}
		
		public override void UnMasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
			//dark.HitsMod -= 30;
			//dark.StamMod += 10;
			
			//int temphits = dark.Hits;
			//dark.Hits = dark.HitsMax;
			//dark.Hits = temphits;
			
			//int tempstam = dark.Stam;
			//dark.Stam = dark.StamMax;
			//dark.Stam = tempstam;
		}

		public override int GetIdleSound()
		{
			return 0x29B;
		}

		public FamiliarBat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
	
	public class FamiliarCat : Familiar
	{
		public FamiliarCat(Mobile m) : base( m )
		{
			Body = 0xC9;
			Hue = Utility.RandomAnimalHue();
			BaseSoundID = 0x69;
			this.FType = FamiliarType.Cat;
			
			SetStr( 50 );
			SetDex( 50 );
			SetInt( 40 );
			SetHits( 150 );
			SetStam( 200 );
			SetMana( 50 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			dark.Familiar = this as Familiar;
		}
		
		public override void MasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
			//dark.HitsMod += 20;
			
			//int temphits = dark.Hits;
			//dark.Hits = dark.HitsMax;
			//dark.Hits = temphits;
		}
		
		public override void UnMasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
			//dark.HitsMod -= 20;
			
			//int temphits = dark.Hits;
			//dark.Hits = dark.HitsMax;
			//dark.Hits = temphits;
		}

		public FamiliarCat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
	
	public class FamiliarRat : Familiar
	{
		public FamiliarRat(Mobile m) : base( m )
		{
			Body = 238;
			BaseSoundID = 0xCC;
			this.FType = FamiliarType.Rat;
			
			SetStr( 50 );
			SetDex( 60 );
			SetInt( 30 );
			SetHits( 200 );
			SetStam( 210 );
			SetMana( 40 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			dark.Familiar = this as Familiar;
		}

		public FamiliarRat( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
	
	public class FamiliarHawk : Familiar
	{
		public FamiliarHawk(Mobile m) : base( m )
		{
			Body = 5;
			BaseSoundID = 0x2EE;
			this.FType = FamiliarType.Hawk;
			
			SetStr( 60 );
			SetDex( 50 );
			SetInt( 30 );
			SetHits( 215 );
			SetStam( 200 );
			SetMana( 30 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			dark.Familiar = this as Familiar;
		}
		
		public override void MasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
			//dark.HitsMod += 30;
			//dark.StamMod -= 10;
			
			//int temphits = dark.Hits;
			//dark.Hits = dark.HitsMax;
			//dark.Hits = temphits;
			
			//int tempstam = dark.Stam;
			//dark.Stam = dark.StamMax;
			//dark.Stam = tempstam;
			
		}
		
		public override void UnMasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
            //dark.HitsMod -= 30;
            //dark.StamMod += 10;
			
            //int temphits = dark.Hits;
            //dark.Hits = dark.HitsMax;
            //dark.Hits = temphits;
			
            //int tempstam = dark.Stam;
            //dark.Stam = dark.StamMax;
            //dark.Stam = tempstam;
		}

		public FamiliarHawk( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
	
	public class FamiliarRaven : Familiar
	{
		public FamiliarRaven(Mobile m) : base( m )
		{
			Body = 6;
			BaseSoundID = 0x1B;
			this.FType = FamiliarType.Raven;
			
			SetStr( 50 );
			SetDex( 40 );
			SetInt( 50 );
			SetHits( 150 );
			SetStam( 100 );
			SetMana( 100 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			dark.Familiar = this as Familiar;
		}
		
		public override void MasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
            //dark.HitsMod += 10;
            //dark.StamMod += 10;
            //dark.ManaMod += 10;
			
            //int temphits = dark.Hits;
            //dark.Hits = dark.HitsMax;
            //dark.Hits = temphits;
			
            //int tempstam = dark.Stam;
            //dark.Stam = dark.StamMax;
            //dark.Stam = tempstam;
			
            //int tempmana = dark.Mana;
            //dark.Mana = dark.ManaMax;
            //dark.Mana = tempmana;
		}
		
		public override void UnMasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
            //dark.HitsMod -= 10;
            //dark.StamMod -= 10;
            //dark.ManaMod -= 10;
			
            //int temphits = dark.Hits;
            //dark.Hits = dark.HitsMax;
            //dark.Hits = temphits;
			
            //int tempstam = dark.Stam;
            //dark.Stam = dark.StamMax;
            //dark.Stam = tempstam;
			
            //int tempmana = dark.Mana;
            //dark.Mana = dark.ManaMax;
            //dark.Mana = tempmana;
		}

		public FamiliarRaven( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
	
	public class FamiliarSnake : Familiar
	{
		public FamiliarSnake(Mobile m) : base( m )
		{
			Body = 52;
			Hue = Utility.RandomSnakeHue();
			BaseSoundID = 0xDB;
			this.FType = FamiliarType.Snake;
			
			SetStr( 50 );
			SetDex( 60 );
			SetInt( 30 );
			SetHits( 200 );
			SetStam( 200 );
			SetMana( 30 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			dark.Familiar = this as Familiar;
		}

		public FamiliarSnake( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
	
	public class FamiliarToad : Familiar
	{
		public FamiliarToad(Mobile m) : base( m )
		{
			Body = 81;
			Hue = Utility.RandomList( 0x5AC,0x5A3,0x59A,0x591,0x588,0x57F );
			BaseSoundID = 0x266;
			this.FType = FamiliarType.Toad;
			
			SetStr( 60 );
			SetDex( 20 );
			SetInt( 60 );
			SetHits( 250 );
			SetStam( 50 );
			SetMana( 175 );
			
			PolyGlotMobile dark = m as PolyGlotMobile;
			dark.Familiar = this as Familiar;
		}
		
		public override void MasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
            //dark.HitsMod += 50;
            //dark.StamMod -= 10;
            //dark.ManaMod -= 10;
			
            //int temphits = dark.Hits;
            //dark.Hits = dark.HitsMax;
            //dark.Hits = temphits;
			
            //int tempstam = dark.Stam;
            //dark.Stam = dark.StamMax;
            //dark.Stam = tempstam;
			
            //int tempmana = dark.Mana;
            //dark.Mana = dark.ManaMax;
            //dark.Mana = tempmana;
		}
		
		public override void UnMasterSpecial()
		{
			if (ControlMaster == null)
				ControlMaster = FamMaster;
			
			PlayerMobile dark = this.ControlMaster as PlayerMobile;
			
            //dark.HitsMod -= 50;
            //dark.StamMod += 10;
            //dark.ManaMod += 10;
			
            //int temphits = dark.Hits;
            //dark.Hits = dark.HitsMax;
            //dark.Hits = temphits;
			
            //int tempstam = dark.Stam;
            //dark.Stam = dark.StamMax;
            //dark.Stam = tempstam;
			
            //int tempmana = dark.Mana;
            //dark.Mana = dark.ManaMax;
            //dark.Mana = tempmana;
		}

		public FamiliarToad( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
