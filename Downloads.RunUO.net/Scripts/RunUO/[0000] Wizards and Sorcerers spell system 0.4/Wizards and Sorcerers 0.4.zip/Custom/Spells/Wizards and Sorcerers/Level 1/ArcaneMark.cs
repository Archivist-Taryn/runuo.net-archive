using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using System.Collections;
using Server.Prompts;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ArcaneMarkSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
		        "Arcane Mark", "Mythos Merse",
		        Reagent.PigIron
		    );
		
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 354; } }
		public override string Desc{ get{ return "Magically etches the name into an item"; } }
		public override string ReagentsDesc{ get{ return "One PigIron."; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Universal; } }
		
		public ArcaneMarkSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
			
		}
		
		public override void OnCast()
		{

				Caster.Target = new InternalTarget( this );
		}
		
		public void Target( Item item )
		{
			if ( !item.IsChildOf( Caster.Backpack ) )
			{
				Caster.SendMessage("This item must be in your backpack to magically inscribe it.");
			}
			else if (!(item is BaseArmor) && !(item is BaseWeapon) && !(item is Spellbook))
			{
				Caster.SendMessage("You may only rename equippable items.");
			}
			else if ( CheckSequence() )
			{
				Caster.SendMessage("Choose a new name for the object. (max 20 characters)");
				Caster.Prompt = new RenamePrompt( item );
			}
			FinishSequence();		
		}

		private class RenamePrompt : Prompt
		{
			private Item m_item;

			public RenamePrompt( Item item )
			{
				m_item = item;
			}

			public override void OnResponse( Mobile from, string text )
			{
				if (text.Length > 20)
				{
					from.SendMessage("Name is too large, please enter in again. (max 20 characters)");
					from.Prompt = new RenamePrompt( m_item );
				}
				else
				{
					m_item.Name = text;
					from.SendMessage("The etching on the item has been completed.");
				}
			}
		}
		
		private class InternalTarget : Target
		{
			private ArcaneMarkSpell m_Owner;
			
			public InternalTarget( ArcaneMarkSpell owner ) : base( 12, false, TargetFlags.None )
			{
				m_Owner = owner;
			}
			
			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Item )
				{
					m_Owner.Target( (Item)o );
				}
			}
			
			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	} // end spell class
} // end namespace

