using System;
using Server;
using Server.Gumps;
using Server.Spells.Magician;
using Server.Spells;
using Server.Items;

namespace Server.Gumps
{
	public class InfoSpellGump : Gump
	{
		public InfoSpellGump( SpellScroll Scroll )
			: base( 0, 0 )
		{
		    string Effect;
			string Name;
			string School;
			string Level;
			string Mana;
			string Reagents;
			
		  


			Spell spell = SpellRegistry.NewSpell( Scroll.SpellID, null, null );

			if (spell is MagicianSpell)

			{

				MagicianSpell magspell = spell as MagicianSpell;

				Effect = magspell.Desc;
				Reagents = magspell.ReagentsDesc;
				Name = magspell.Name;
				School = this.FindSchool( magspell.SpellSchool );
				Level = Convert.ToString( magspell.SpellLevel );
				Mana = Convert.ToString( magspell.RequiredMana );
			}
 			else
 			{
 				Effect = "";
 				Reagents = "";
 				Name = "";
  				School = "";
				Level = "";
				Mana = "";
  			}
  			
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			this.AddPage(0);
			this.AddBackground(40, 40, 370, 280, 3500);
			this.AddBackground(40, 40, 370, 280, 3500);
			this.AddLabel(172, 62, 2707, @"Spell Information");
			this.AddLabel(170, 60, 2694, @"Spell Information");
			this.AddButton(210, 280, 4023, 4025, (int)Buttons.BTN_Ok, GumpButtonType.Reply, 0);
			//this.AddLabel(60, 170, 0, @"Effect: "+Effect);
			this.AddHtml( 60, 170, 340, 140, "Effect: " + Effect + "<br>Reagents: " + Reagents, false, false );
			this.AddLabel(60, 90, 0, @"Name: "+Name);
			this.AddLabel(60, 130, 0, @"School: "+School);
			this.AddLabel(60, 110, 0, @"Level: "+Level);
			this.AddLabel(60, 150, 0, @"Mana Cost: "+Mana);
			
		}

	public string FindSchool( SpellSchool school )
	{
		switch( school )
		{
  			case SpellSchool.Universal:
  			{
  				return "Universal";
  			}
  
			case SpellSchool.Abjuration:
			{
				return "Abjuration";
  			}
  			
  			case SpellSchool.Conjuration:
  			{
  				return "Conjuration";
  			}
  
			case SpellSchool.Divination:
  			{
  				return "Divination";
  			}
  
  			case SpellSchool.Enchantment:
  			{
  				return "Enchantment";
  			}
  			
  			case SpellSchool.Evocation:
  			{
  				return "Evocation";
  			}
  	
  			case SpellSchool.Illusion:
  			{
  				return "Illusion";
  			}
  
  			case SpellSchool.Necromancy:
  			{
  				return "Necromancy";
  			}
  
			case SpellSchool.Transmutation:
  			{
  				return "Transmutation";
  			}
  			
  			default:
 			return "";
  
		}
	}
	
	public enum Buttons
		{
			BTN_Ok,
		}

	}
}
