using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class MelfsAcidArrowSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Melf's Acid Arrow", "Aquas Simit",
				Reagent.BloodSpawn,
				Reagent.BloodSpawn,
				Reagent.Garlic
			);
		public override string Desc{ get{ return "A magical arrow of acid shoots towards your target."; } } 
		public override string ReagentsDesc{ get{ return "Two BloodSpawn, One Garlic."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Second; } }
        public override int SpellNumber { get { return 316; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 45.0; } }
		public override int RequiredMana{ get{ return 20; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Conjuration; } }

		public MelfsAcidArrowSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return true; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				Mobile source = Caster;

				SpellHelper.Turn( source, m );

				SpellHelper.CheckReflect( (int)this.SpellLevel, ref source, ref m );

				int damage = Utility.Random( 5, 16 );
				source.MovingEffect( m, 0x1BFE, 18, 1, false, false, 0x8A3, 0 );
				source.PlaySound( 0x2B2 );
				
				Caster.DoHarmful( m );
				//damage = AbsorbDamage(m, ResistType.Acid, damage);
				m.Damage( damage );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private MelfsAcidArrowSpell m_Owner;

			public InternalTarget( MelfsAcidArrowSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
