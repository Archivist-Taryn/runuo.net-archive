using System;
using Server.Network;
using Server.Gumps;
using Server.Spells;
using Server.Mobiles;
using Server.Items;
using Server.Spells.Magician;

namespace Server.Items
{
	public class MagicianSpellbook : Spellbook
	{
		public override SpellbookType SpellbookType{ get{ return SpellbookType.Magician; } }
		public override int BookOffset{ get{ return 300; } }
		public override int BookCount{ get{ return 100; } }
		
		[Constructable]
		public MagicianSpellbook() : this( (ulong)0 )
		{
		}
		
		[Constructable]
		public MagicianSpellbook( ulong content ) : base( content, 0xEFA )
		{
			Name = "Wizard Tome";
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			PolyGlotMobile dark = from as PolyGlotMobile;
			
			if ((dark.Class == ClassType.Wizard))
			{
				MagicianSpellbook book = new MagicianSpellbook();
				
				int[] spells = dark.SpellsKnown.GenerateArrayOfSpells();
				int val;
				for (int i=0; i < spells.Length; i++)
				{
					val = spells[i] - book.BookOffset;
					book.Content |= (ulong)1 << val;
					
					book.InvalidateProperties();
				}
				this.Content = book.Content;
				book.Delete();
				
				if ( from.InRange( GetWorldLocation(), 1 ) )
				{
					from.CloseGump( typeof( MagicianSpellbookGump ) );
					from.SendGump( new MagicianSpellbookGump( from, this ) );
				}
			}
			else
			    dark.SendMessage("You are unable to decipher what is in the book.");
		}
		
		public SpellSchool ScrollSpellSchool( int SpellID, Mobile from )
		{
			MagicianSpell spell = SpellRegistry.NewSpell( SpellID, from, this ) as MagicianSpell;
			return spell.SpellSchool;
		}
		
		public int ScrollSpellLevel( int SpellID, Mobile from )
		{
			MagicianSpell spell = SpellRegistry.NewSpell( SpellID, from, this ) as MagicianSpell;
			return (int)spell.SpellLevel;
		}
		
		public bool IsOppositeSchool( int SpellID, Mobile from )
		{
			PolyGlotMobile dark = from as PolyGlotMobile;
			MagicianSpell spell = SpellRegistry.NewSpell( SpellID, from, this ) as MagicianSpell;
			SpellSchool testschool = spell.SpellSchool;
			SpellSchool[] schools = dark.SpellsKnown.OppositeSchool();
			
			if (schools == null)
			{
				return false;
			}
			else
			{
				for (int i = 0; i < schools.Length; i++)
				{
					if (testschool == schools[i])
						return true;
				}
			}
			
			return false;
			
		}
		
		public override bool OnDragDrop( Mobile from, Item dropped )
		{
			PolyGlotMobile dark = from as PolyGlotMobile;
            if ((dark.Class == ClassType.Wizard)||(dark.Class == ClassType.Sorcerer)) // take out Sorcerer check later
            {
				if ( dropped is SpellScroll && dropped.Amount == 1 )
				{
					SpellScroll scroll = (SpellScroll)dropped;
					
					SpellbookType type = GetTypeForSpell( scroll.SpellID );
					
					if ( type != SpellbookType.Magician )
					{
						return false;
					}
					else if ( dark.SpellsKnown.HasSpell( scroll.SpellID ) )
					{
						from.SendLocalizedMessage( 500179 ); // That spell is already present in that spellbook.
						return false;
					}
					else if (( dark.SpellsKnown.Specialized != this.ScrollSpellSchool( scroll.SpellID, from )&&(this.ScrollSpellLevel(scroll.SpellID, from) > 6)&&(this.ScrollSpellSchool( scroll.SpellID, from )!= SpellSchool.Universal) ) || ( this.IsOppositeSchool( scroll.SpellID, from )) )
					{
						from.SendMessage("You cannot write this in your book due to your restriction of education.");
						return false;
					}
					else
					{
						dark.SpellsKnown.Add( dark, scroll.SpellID );
						scroll.Delete();
						from.Send( new PlaySound( 0x249, GetWorldLocation() ) );
						return true;
					}
				}
				else
				{
					return false;
				}
            }
            else
                return false;
		}
		
		
		public MagicianSpellbook( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();
		}
	}
}
