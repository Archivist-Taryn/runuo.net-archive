using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ControlDeadSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Control Dead", "Larvae Mortevis",
				17,
				Reagent.NoxCrystal,
				Reagent.NoxCrystal,
				Reagent.Garlic,
				Reagent.Garlic,
				Reagent.MandrakeRoot
			);
		public override string Desc{ get{ return "Take control of nearby undead."; } }
		public override string ReagentsDesc{ get{ return "Two NoxCrystals, Two Garlics, one MandrakeRoot "; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fifth; } }
        public override int SpellNumber { get { return 358; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 65.0; } }
		public override int RequiredMana{ get{ return 35; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Necromancy; } }

		public ControlDeadSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
				return false;

			if ( (Caster.Followers + 1) > Caster.FollowersMax )
			{
				Caster.SendLocalizedMessage( 1049645 ); // You have too many followers to summon that creature.
				return false;
			}

			return true;
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckSequence() )
			{
				if (m is BaseCreature )
				{
					BaseCreature pm = m as BaseCreature;
					if( pm.ControlMaster == null )
					{
						TimeSpan duration;
						if(Caster.Int > (pm.Int * 2))
						{
							duration = TimeSpan.FromSeconds(Utility.Random(120,180));
						}
						else
						{
							duration = TimeSpan.FromSeconds(Utility.Random(60,120));
						}
						if(pm.Int < Caster.Int)
						{
							new ControlDeadTimer( pm, Caster, duration ).Start();
							Caster.SendMessage("You've taken control of " + pm.Name + "'s actions.");
						}
						else
						{
							Caster.SendMessage("You feel a mental force pushing you out of the creature's mind.");
							pm.Combatant = Caster;
						}
					}
					else
					{
						Caster.SendMessage("You feel a mental force pushing you out of the creature's mind.");
						pm.Combatant = Caster;
					}
				}
				else
				{
					Caster.SendMessage("You can't control that!.");
				}
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private ControlDeadSpell m_Owner;

			public InternalTarget( ControlDeadSpell owner ) : base( 12, false, TargetFlags.None )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
		private class ControlDeadTimer : Timer
		{
			private BaseCreature ma;
			private Mobile c;

			public ControlDeadTimer( BaseCreature m, Mobile Caster, TimeSpan duration ) : base( duration )
			{
				c = Caster;
				ma = m;
				m.SetControlMaster( Caster );
				m.ControlOrder = OrderType.Follow;// I need to check for *is this Creature Undead but not sure there is a bool for that.
			}
				
			protected override void OnTick()
			{
				ma.SetControlMaster( null );
				c.SendMessage("You've lost control of " + ma.Name + "'s actions.");
				ma.Combatant = c;
			}
		}
	}
}

