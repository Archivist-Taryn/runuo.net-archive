using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using System.Collections;

namespace Server.Spells.Magician
{
	public class EnhanceFamiliarSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
		        "Enhance Familiar", "Visre Similt",
		        Reagent.Bloodmoss,
		        Reagent.BloodSpawn
		    );
		
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override string Desc{ get{ return "Enhances your familiar's defenses."; } }
		public override string ReagentsDesc{ get{ return "One Bloodmoss, One BloodSpawn."; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Universal; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Second; } }
        public override int SpellNumber { get { return 353; } }
		
		private bool permy;
		
		public EnhanceFamiliarSpell( Mobile caster, Item scroll, bool perm ) : base( caster, scroll, m_Info )
		{
			permy = perm;
		}
		
		public EnhanceFamiliarSpell( Mobile caster, Item scroll ) : this( caster, scroll, false )
		{
			
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		
		public void Target( Mobile m )
		{
			int time = 200; //Utility.Random(0,((int)(Caster.Skills[SkillName.EvalInt].Value + Caster.Skills[SkillName.Magery].Value + Caster.Int) / 3) ); // The length of the spell is the Caster's Int plus the Caster's Magery plus the Caster's Evaluate Intelligence skills added together then divided by 3
			TimeSpan span = TimeSpan.FromSeconds((int)time);
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckBSequence( m ) )
			{
				if( m is Familiar) // Checks to see if the target is a Familiar
				{
					Familiar fam = m as Familiar;
					if(fam.ControlMaster == Caster) // Checks to see if the target is the Caster's Familiar
					{
						if(permy)
						{
							if(!fam.Enhanced)
							{
								fam.Str += 25;
								fam.Dex += 25;
								fam.Int += 25;
								fam.Enhanced = true;
							}
							else
							{
								Caster.SendMessage("That familiar already is Enhanced!");
							}
						}
						else
						{
							SpellHelper.AddStatBonus( Caster, fam, StatType.Str, 25, span );
							SpellHelper.AddStatBonus( Caster, fam, StatType.Dex, 25, span );
							SpellHelper.AddStatBonus( Caster, fam, StatType.Int, 25, span );
						}
						SpellHelper.Turn( Caster, fam as Mobile );
						fam.Emote("You see "+fam.Name+"'s skin glow.");
						fam.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
						fam.PlaySound( 0x1EE );
					}
					else
					{
						Caster.SendMessage("This is not your familiar!");
					}
				}
				else
				{
					Caster.SendMessage("You can not enhance this!");
				}
			}
			FinishSequence();		

		}
		
		private class InternalTarget : Target
		{
			private EnhanceFamiliarSpell m_Owner;
			
			public InternalTarget( EnhanceFamiliarSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			}
			
			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}
			
			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	} // end spell class
} // end namespace

