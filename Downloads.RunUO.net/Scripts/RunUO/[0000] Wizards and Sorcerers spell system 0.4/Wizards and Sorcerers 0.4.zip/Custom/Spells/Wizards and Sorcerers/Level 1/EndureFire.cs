using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class EndureFireSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Endure Fire", "Mit Combinrae Mor",
				Reagent.Ginseng,
				Reagent.BatWing
			);
		public override string Desc{ get{ return "Grants limited protection to damage from fire."; } }
		public override string ReagentsDesc{ get{ return "One Ginseng, Batwing."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 351; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 15.0; } }
		public override int RequiredMana{ get{ return 10; } }
	
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Abjuration; } }

		public EndureFireSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( Mobile m )
		{
            //if ( m is PolyGlotMobile )
            //{
            //    if ( !Caster.CanSee( m ) )
            //    {
            //        Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
            //    }
            //    else if ( CheckBSequence( m ) )
            //    {
            //        SpellHelper.Turn( Caster, m );
					
            //        TimeSpan span = TimeSpan.FromSeconds( 30 );
            //        PolyGlotMobile dark = m as PolyGlotMobile;
            //        CustomResistanceMod mod = new CustomResistanceMod( dark, ResistType.Fire, "MagicBuff", 25, span, false);
            //        dark.AddResistMod( mod );
					
            //        m.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
            //        m.PlaySound( 0x1EE );
            //    }
            //}
            //else
            //    Caster.SendMessage("Cannot cast on that creature.");

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private EndureFireSpell m_Owner;

			public InternalTarget( EndureFireSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			} 

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
