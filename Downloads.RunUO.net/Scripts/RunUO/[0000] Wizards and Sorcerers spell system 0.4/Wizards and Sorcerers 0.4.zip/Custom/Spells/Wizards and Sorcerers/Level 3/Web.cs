using System;
using Server;
using Server.Targeting;
using Server.Network;
using Server.Misc;
using Server.Items;
using System.Collections;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class WebSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
		      			"Web",
		      			"Locrener Silte De Norto",
						Reagent.SpidersSilk,
		                Reagent.MandrakeRoot,
		                Reagent.PigIron
		                                                );
		public override string Desc{ get{ return "Creates a many-layered mass of strong, sticky strands."; } }
		public override string ReagentsDesc{ get{ return "SpidersSilk, MandrakeRoot, PigIron "; }  }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 317; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 55.0; } }
		public override int RequiredMana{ get{ return 35; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Conjuration; } }
		
		public WebSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		
		public void Target( IPoint3D p )
		{
			if ( !Caster.CanSee( p ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( SpellHelper.CheckTown( p, Caster ) && CheckSequence() )
			{
				SpellHelper.Turn( Caster, p );
				
				SpellHelper.GetSurfaceTop( ref p );
				
				Effects.PlaySound( p, Caster.Map, 0x1F6 );
				Point3D loc = new Point3D( p.X, p.Y , p.Z );
				new WebCenter( loc, Caster.Map, Caster, 0xEE3 );
			}
			
			FinishSequence();
		}
		
		
		// done above
		
		
		
		[DispellableField]
		private class InternalItem : Item
		{
			private Timer m_Timer;
			private DateTime m_End;
			private ArrayList StuckMobiles = new ArrayList();
			
			public override bool BlocksFit{ get{ return true; } }
			
			public override bool OnMoveOver(Mobile m)
			{
				PolyGlotMobile dark = m as PolyGlotMobile;
				
				if((!StuckMobiles.Contains(m) || !dark.FreeMovement )&& !m.Frozen)
				{
					new FreezingTimer(m, TimeSpan.FromSeconds(15));
				}
				return true;
			}
			
			public override void OnDelete()
			{
				StuckMobiles.Clear();
				base.OnDelete();
			}
			
			public InternalItem( Point3D loc, Map map, Mobile caster, int ItemNumber ) : base( ItemNumber )
			{
				Visible = false;
				Movable = false;
				
				MoveToWorld( loc, map );
				
				if ( caster.InLOS( this ) )
					Visible = true;
				else
					Delete();
				
				if ( Deleted )
					return;
				
				m_Timer = new InternalTimer( this, TimeSpan.FromSeconds( 15.0 ) );
				m_Timer.Start();
				
				m_End = DateTime.Now + TimeSpan.FromSeconds( 15.0 );
			}
			
			public InternalItem( Serial serial ) : base( serial )
			{
			}
			
			public override void Serialize( GenericWriter writer )
			{
				base.Serialize( writer );
				
				writer.Write( (int) 1 ); // version
				
				writer.WriteDeltaTime( m_End );
			}
			
			public override void Deserialize( GenericReader reader )
			{
				base.Deserialize( reader );
				
				int version = reader.ReadInt();
				
				switch ( version )
				{
					case 1:
						{
							m_End = reader.ReadDeltaTime();
							
							m_Timer = new InternalTimer( this, m_End - DateTime.Now );
							m_Timer.Start();
							
							break;
						}
					case 0:
						{
							TimeSpan duration = TimeSpan.FromSeconds( 15.0 );
							
							m_Timer = new InternalTimer( this, duration );
							m_Timer.Start();
							
							m_End = DateTime.Now + duration;
							
							break;
						}
				}
			}
			
			private class FreezingTimer : Timer
			{
				private Mobile target;
				
				public FreezingTimer( Mobile m, TimeSpan duration ) : base( duration )
				{
					target = m;
					m.Frozen = true;
					Start();
				}
				
				protected override void OnTick()
				{
					target.Frozen = false;
				}
			}
			
			private class InternalTimer : Timer
			{
				private InternalItem m_Item;
				
				public InternalTimer( InternalItem item, TimeSpan duration ) : base( duration )
				{
					Priority = TimerPriority.OneSecond;
					m_Item = item;
				}
				
				protected override void OnTick()
				{
					m_Item.Delete();
				}
			}
		}
		
		private class InternalTarget : Target
		{
			private WebSpell m_Owner;
			
			public InternalTarget( WebSpell owner ) : base( 12, true, TargetFlags.None )
			{
				m_Owner = owner;
			}
			
			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is IPoint3D )
					m_Owner.Target( (IPoint3D)o );
			}
			
			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
		
		private class WebCenter : Item
		{
			private Timer m_Timer;
			private DateTime m_End;
			public ArrayList StuckMobiles = new ArrayList();
			private Mobile m_Caster;
			
			public override bool BlocksFit{ get{ return true; } }
			
			public override bool OnMoveOver(Mobile m)
			{
				PolyGlotMobile dark = m as PolyGlotMobile;
				
				if((!StuckMobiles.Contains(m) || !dark.FreeMovement )&& !m.Frozen)
				{
					new FreezingTimer(m, TimeSpan.FromSeconds(15));
				}
				return true;
			}
			
			public override bool HandlesOnMovement{ get{ return true; } }
			
			public override void OnMovement( Mobile m, Point3D oldLocation )
			{
				base.OnMovement( m, oldLocation );
				
				PolyGlotMobile dark = m as PolyGlotMobile;
				if ( !dark.FreeMovement && dark.InRange( this.Location, 5 ) && !StuckMobiles.Contains(m) )
				{
					StuckMobiles.Add(m);
					
					int rand = Utility.Random( 1, 4 );
					int ItemNumber=0;
					
					switch(rand)
					{
						case 1:
							ItemNumber = 0xEE3;
						break;
						case 2:
							ItemNumber = 0xEE4;
						break;
						case 3:
							ItemNumber = 0xEE5;
						break;
						case 4:
							ItemNumber = 0xEE6;
						break;
						default:
							ItemNumber = 0xEE3;
						break;
					}
					new InternalItem(m.Location, m.Map, m_Caster, ItemNumber);
					new FreezingTimer( m, TimeSpan.FromSeconds( 15 ) );
				}
				
			}
			
			public override void OnDelete()
			{
				StuckMobiles.Clear();
				base.OnDelete();
			}
			
			public WebCenter( Point3D loc, Map map, Mobile caster, int ItemNumber ) : base( ItemNumber )
			{
				Visible = false;
				Movable = false;
				m_Caster = caster;
				
				MoveToWorld( loc, map );
				
				if ( caster.InLOS( this ) )
					Visible = true;
				else
					Delete();
				
				if ( Deleted )
				{
					caster.SendMessage("You cannot see the target");
					return;
				}
				
				for ( int i = 1; i <= 10; ++i )
				{
					
					int k = Utility.Random(0, 9);
					int j = Utility.Random(0, 9);
					
					Point3D p = new Point3D( loc.X + (k-5), loc.Y + (j-5), loc.Z );
					bool canFit = SpellHelper.AdjustField( ref p, m_Caster.Map, 22, true );
					
					if ( !canFit )
						continue;
					
					int rand = Utility.Random( 1, 4 );
					int ItemNum = 0;
					
					switch(rand)
					{
						case 1:
							ItemNum = 0xEE3;
						break;
						case 2:
							ItemNum = 0xEE4;
						break;
						case 3:
							ItemNum = 0xEE5;
						break;
						case 4:
							ItemNum = 0xEE6;
						break;
						default:
							ItemNum = 0xEE3;
						break;
					}
					
					
					Item item = new InternalItem( p, m_Caster.Map, m_Caster, ItemNum );
					
					Effects.SendLocationParticles( item, 0x376A, 9, 15, 5025 );
				}
				
				TimeSpan duration = TimeSpan.FromSeconds( 15.0 );
				TimeSpan interval = TimeSpan.FromSeconds( 15.0 );
								
				m_Timer = new InternalTimer( m_Caster, this, duration, interval, 4 );
				m_Timer.Start();
				
				m_End = DateTime.Now + TimeSpan.FromSeconds( 60.0 );
			}
			
			public WebCenter( Serial serial ) : base( serial )
			{
			}
			
			public override void Serialize( GenericWriter writer )
			{
				base.Serialize( writer );
				
				writer.Write( (int) 0 ); // version
				
				writer.WriteDeltaTime( m_End );
				writer.Write( (Mobile)m_Caster );
			}
			
			public override void Deserialize( GenericReader reader )
			{
				base.Deserialize( reader );
				
				int version = reader.ReadInt();
				
				switch ( version )
				{
					case 0:
					{
						m_End = reader.ReadDeltaTime();
						m_Caster = (Mobile)reader.ReadMobile();
						
						m_Timer = new InternalTimer( m_Caster, this, m_End - DateTime.Now, TimeSpan.FromSeconds( 15 ), 1);
						m_Timer.Start();
						
						break;
					}
				}
			}
			
			private class FreezingTimer : Timer
			{
				private Mobile target;
				
				public FreezingTimer( Mobile m, TimeSpan duration ) : base( duration )
				{
					target = m;
					m.Frozen = true;
					Start();
				}
				
				protected override void OnTick()
				{
					target.Frozen = false;
				}
			}
			
			private class InternalTimer : Timer
			{
				private WebCenter m_Item;
				private int counter;
				private int endcount;
				private Mobile m_Caster;
				
				public InternalTimer( Mobile caster, WebCenter item, TimeSpan duration, TimeSpan interval, int count ) : base( duration, interval, count )
				{
					m_Caster = caster;
					Priority = TimerPriority.OneSecond;
					m_Item = item;
					counter = 0;
					endcount = count;
				}
				
				protected override void OnTick()
				{
					m_Item.StuckMobiles.Clear();
					counter++;
					if (counter == endcount)
						m_Item.Delete();
					else
					{
						for ( int i = 1; i <= 10; ++i )
						{
							
							int k = Utility.Random(0, 9);
							int j = Utility.Random(0, 9);
							
							Point3D loc = new Point3D( m_Item.X + (k-5), m_Item.Y + (j-5), m_Item.Z );
							bool canFit = SpellHelper.AdjustField( ref loc, m_Item.Map, 22, true );
							
							if ( !canFit )
								continue;
							
							int rand = Utility.Random( 1, 4 );
							int ItemNumber=0;
							
							switch(rand)
							{
								case 1:
									ItemNumber = 0xEE3;
									break;
								case 2:
									ItemNumber = 0xEE4;
									break;
								case 3:
									ItemNumber = 0xEE5;
									break;
								case 4:
									ItemNumber = 0xEE6;
									break;
								default:
									ItemNumber = 0xEE3;
									break;
							}
							Item item = new InternalItem( loc, m_Caster.Map, m_Caster, ItemNumber );
							Effects.SendLocationParticles( item, 0x376A, 9, 15, 5025 );
							
						}
					}
				}	
			}
		}
	}
}
