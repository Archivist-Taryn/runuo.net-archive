using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Gumps;

namespace Server.Spells.Magician
{
	public class AnalyzeDweomerSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Analyze Dweomer", "Locter Vinrae Nor Be Mor",
				Reagent.PigIron,
				Reagent.PigIron,
				Reagent.PigIron,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss,
				Reagent.Bone
			);

		public override string Desc{ get{ return "You can find out many things about a target creature or humanoid."; } }
		public override string ReagentsDesc{ get{ return "Three PigIron, Two Bloodmoss, one bone "; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Sixth; } }
        public override int SpellNumber { get { return 338; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Divination; } }

		public AnalyzeDweomerSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( PolyGlotMobile m )
		{
			if ( !Caster.CanSee( m as Mobile ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if (CheckSequence())
			{
				Mobile source = Caster;

				m.FixedParticles( 0x376A, 9, 32, 5030, EffectLayer.Waist );
				source.PlaySound( 0x1E5 );

				Caster.SendGump( new AnalyzeDweomerGump(m) );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private AnalyzeDweomerSpell m_Owner;

			public InternalTarget( AnalyzeDweomerSpell owner ) : base(12, false, TargetFlags.None)
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is PolyGlotMobile )
				{
					m_Owner.Target( (PolyGlotMobile)o );
				}
				else
				{
					from.SendMessage("You cannot target that.");
					m_Owner.FinishSequence();
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
