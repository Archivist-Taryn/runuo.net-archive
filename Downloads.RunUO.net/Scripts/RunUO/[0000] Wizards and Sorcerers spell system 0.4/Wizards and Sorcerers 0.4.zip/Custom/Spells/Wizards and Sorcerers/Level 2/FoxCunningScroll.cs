using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class FoxsCunningScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public FoxsCunningScroll() : this( 1 )
		{
		}

		[Constructable]
		public FoxsCunningScroll( int amount ) : base( 334, 0x1F2E, amount )
		{
			Name = "Fox's Cunning";
		}
		
		public FoxsCunningScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
