using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class EnergyBoltMScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public EnergyBoltMScroll() : this( 1 )
		{
		}

		[Constructable]
		public EnergyBoltMScroll( int amount ) : base( 308, 0x1F2E, amount )
		{
			Name = "Energy Bolt";
		}
		
		public EnergyBoltMScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
