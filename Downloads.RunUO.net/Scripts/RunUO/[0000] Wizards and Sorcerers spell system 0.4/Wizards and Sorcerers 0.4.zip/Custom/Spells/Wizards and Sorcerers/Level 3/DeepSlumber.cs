using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using System.Collections;

namespace Server.Spells.Magician
{
	public class DeepSlumberSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
		        "Deep Slumber", "Lor Insitre",
		        Reagent.BatWing,
				Reagent.Bloodmoss,
				Reagent.Garlic
		    );

	    public override string Desc{ get{ return "Drains target's energy forcing him to deep sleep."; } }
		public override string ReagentsDesc{ get{ return "One BatWing, Bloodmoss, Garlic."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 346; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Enchantment; } }

		public DeepSlumberSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		public void Target( Mobile mob )
		{
			if ( !Caster.CanSee( mob ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckSequence() )
			{
				if( mob.Player )
				{
					PolyGlotMobile m = mob as PolyGlotMobile;
					TimeSpan duration = TimeSpan.Zero;
					
					switch (m.Tired)
					{
						case 0:
						{
							if(m.TireLevel < Utility.Random(0,200))
							{
								m.TireLevel = m.TireLevel * 2;
								m.Stam -= Utility.Random(10,20);
								m.SendMessage(Caster.Name+" has failed to put you to sleep, but you feel drained slightly");
								Caster.SendMessage("You have failed to put " + m.Name + " to sleep magically, but have sapped some of their energy");
							}
							else
							{
								if (Caster.Int > m.Stam)
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(30, 40) );
								}
								else
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(20, 30) );
								}
								Mobile source = Caster;
								SpellHelper.Turn( source, m );
								m.Sleep( duration );
								m.PlaySound( 0x204 );
								m.SendMessage(Caster.Name+" has put you to sleep");
								Caster.SendMessage("You have put " + m.Name + " to sleep magically");
							}
							break;
						}
						case 1:
						{
							if(m.TireLevel < Utility.Random(0,150))
							{
								m.TireLevel = m.TireLevel * 2;
								m.Stam -= Utility.Random(10,20);
								m.SendMessage(Caster.Name+" has failed to put you to sleep, but you feel drained slightly");
								Caster.SendMessage("You have failed to put " + m.Name + " to sleep magically, but have sapped some of their energy");
							}
							else
							{
								if (Caster.Int > m.Stam)
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(30, 40) );
								}
								else
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(20, 30) );
								}
								
								Mobile source = Caster;
								SpellHelper.Turn( source, m );
								m.Sleep( duration );
								m.PlaySound( 0x204 );
								m.SendMessage(Caster.Name+" has put you to sleep");
								Caster.SendMessage("You have put " + m.Name + " to sleep magically");
							}
							break;
						}
						case 2:
						{
							if(m.TireLevel < Utility.Random(0,100))
							{
								m.TireLevel = m.TireLevel * 2;
								m.Stam -= Utility.Random(10,20);
								m.SendMessage(Caster.Name+" has failed to put you to sleep, but you feel drained slightly");
								Caster.SendMessage("You have failed to put " + m.Name + " to sleep magically, but have sapped some of their energy");
							}
							else
							{
								if (Caster.Int > m.Stam)
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(30, 40) );
								}
								else
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(20, 30) );
								}
								
								Mobile source = Caster;
								SpellHelper.Turn( source, m );
								m.Sleep( duration  );
								m.PlaySound( 0x204 );
								m.SendMessage(Caster.Name+" has put you to sleep");
								Caster.SendMessage("You have put " + m.Name + " to sleep magically");
							}
							break;
						}
						default:
						{
							if(m.TireLevel < Utility.Random(0,50))
							{
								m.TireLevel = m.TireLevel * 2;
								m.Stam -= Utility.Random(10,20);
								m.SendMessage(Caster.Name+" has failed to put you to sleep, but you feel drained slightly");
								Caster.SendMessage("You have failed to put " + m.Name + " to sleep magically, but have sapped some of their energy");
							}
							else
							{
								if (Caster.Int > m.Stam)
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(30, 40) );
								}
								else
								{
									duration = TimeSpan.FromSeconds( (int)Utility.Random(20, 30) );
								}
								
								Mobile source = Caster;
								SpellHelper.Turn( source, m );
								m.Sleep( duration );
								m.PlaySound( 0x204 );
								m.SendMessage(Caster.Name+" has put you to sleep");
								Caster.SendMessage("You have put " + m.Name + " to sleep magically");
							}
							break;
						}
					}  // end switch
				}
				else // npc case
				{
					TimeSpan duration;
					if (Caster.Int > mob.Stam)
					{
						duration = TimeSpan.FromSeconds( Utility.Random(30, 40) );
					}
					else
					{
						duration = TimeSpan.FromSeconds( Utility.Random(20, 30) );
					}
					new DeepSlumberTimer( Caster, mob, duration);
				}
			}
		}
		
		private class DeepSlumberTimer : Timer
		{
			private Mobile ma;
			private string m_name;
			
			public DeepSlumberTimer( Mobile Caster, Mobile m, TimeSpan duration ) : base( duration )
			{
				ma = m;
				m_name = m.Name;
				if(m.Int < Caster.Int)
				{
					Caster.SendMessage("You have put " + m.Name + " to sleep magically");
					m.Squelched = true;
					m.Name += " [Sleeping]";
					//~ m.Animate(int action, int frameCount, int repeatCount, bool forward, bool repeat, int delay);
					m.Paralyzed = true;
				}
				else
				{
					Caster.SendMessage("You have failed to put " + m.Name + " to sleep magically, but have sapped some of their energy");
					m.Stam = m.Stam / 2;
				}
				Start();
			}
			
			protected override void OnTick()
			{
				ma.Squelched = false;
				ma.Name = m_name;
				ma.Paralyzed = false;
			}
		}
		
		private class InternalTarget : Target
		{
			private DeepSlumberSpell m_Owner;
			
			public InternalTarget( DeepSlumberSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}
			
			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}
			
			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	} // end spell class
} // end namespace

