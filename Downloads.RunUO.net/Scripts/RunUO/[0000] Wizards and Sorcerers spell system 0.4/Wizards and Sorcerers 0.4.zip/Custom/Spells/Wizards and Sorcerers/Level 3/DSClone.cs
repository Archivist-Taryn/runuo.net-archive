using System;
using System.Collections;
using Server.Items;
using Server.Targeting;
using Server.Misc;
using System.Reflection;
using Server;
using Server.Mobiles;
using Server.Network;
using Server.Regions;

namespace Server.Mobiles
{
	[CorpseName( "null" )]
	public class DSClone : BaseCreature
	{
		private PolyGlotMobile original;
		
		public DSClone(PolyGlotMobile m) : base( AIType.AI_Vendor, FightMode.None, 10, 1, 0.2, 0.4 )
		{
			original = m;
			
			Name = m.Name;
			Body = m.Body;
			BaseSoundID = m.BaseSoundID;
			
			Dex = m.Dex;
			Int = m.Int;
			Str = m.Str;
			Fame = m.Fame;
			Karma = m.Karma;
			NameHue = m.NameHue;
			SpeechHue = m.SpeechHue;
			Criminal = m.Criminal;
			Title = m.Title;
			Female = m.Female;
			Hue = m.Hue;
			Hits = m.Hits;
			Mana = m.Mana;
			Stam = m.Stam;
			
			ArrayList items = new ArrayList( m.Items );
			for (int i=0; i<items.Count; i++)
			{
				Item item = (Item)items[i];
				if((( item != null ) && ( item.Parent == m as Mobile ) && ( item != m.Backpack )))
				{
					Type type = item.GetType();
					Item newitem = Loot.Construct( type );
					CopyProperties( newitem, item );
					AddItem( newitem );
				}
			}
		}
		
		private static void CopyProperties ( Item dest, Item src )
		{
			PropertyInfo[] props = src.GetType().GetProperties();
			
			for ( int i = 0; i < props.Length; i++ )
			{
				try
				{
					if ( props[i].CanRead && props[i].CanWrite )
					{
						props[i].SetValue( dest, props[i].GetValue( src, null ), null );
					}
				}
				catch
				{
				}
			}
		}
		
		public override bool HandlesOnSpeech( Mobile from )
		{
			if( from == original as Mobile )
				return true;
			else
				return base.HandlesOnSpeech(from);
		}
		
		public override void OnSpeech( SpeechEventArgs e )
		{
			if( e.Mobile == original as Mobile )
				this.Say(e.Speech);

			base.OnSpeech( e );
		}
		
		public override void Damage (int amount)
		{
			this.Delete();
		}

		public DSClone( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			
			if (original == null)
				this.Delete();
		}
	}
}
