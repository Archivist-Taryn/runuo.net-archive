using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class CatsGraceScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public CatsGraceScroll() : this( 1 )
		{
		}

		[Constructable]
		public CatsGraceScroll( int amount ) : base( 333, 0x1F2E, amount )
		{
			Name = "Cat's Grace";
		}
		
		public CatsGraceScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
