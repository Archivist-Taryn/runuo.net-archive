using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class AnalyzeDweomerScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public AnalyzeDweomerScroll() : this( 1 )
		{
		}

		[Constructable]
		public AnalyzeDweomerScroll( int amount ) : base( 338, 0x1F2E, amount )
		{
			Name = "Analyze Dweomer";
		}
		
		public AnalyzeDweomerScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
