using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class SummonSwarm1Spell : MagicianSpell
	{
		private int j = Utility.Random(2,5);
		private static SpellInfo m_Info = new SpellInfo(
				"Summon Swarm 1", "Culloth Locrener Minrae Ki",
				Reagent.Bloodmoss,
				Reagent.Nightshade,
				Reagent.Nightshade
			);
		public override string Desc{ get{ return "Summon several lower creatures to do your bidding."; } } 
		public override string ReagentsDesc{ get{ return "Two Nightshade, Bloodmoss"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 323; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 55.0; } }
		public override int RequiredMana{ get{ return 35; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Conjuration; } }

		public SummonSwarm1Spell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
				return false;

			if ( (Caster.Followers + j) > Caster.FollowersMax )
			{
				Caster.SendLocalizedMessage( 1049645 ); // You have too many followers to summon that creature.
				return false;
			}

			return true;
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				switch( Utility.Random( 3 ) )
				{
					case 0:
						for ( int i = 1; i <= j; ++i )
						{
							SpellHelper.Summon( new Orc(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
						}
					break;
					case 1:
						for ( int i = 1; i <= j; ++i )
						{
							SpellHelper.Summon( new GazerLarva(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
						}
					break;
					case 2:
						for ( int i = 1; i <= j; ++i )
						{
							SpellHelper.Summon( new Gibberling(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
						}
					break;
					default:
						for ( int i = 1; i <= j; ++i )
						{
							SpellHelper.Summon( new Gibberling(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
						}
					break;
				}
			}

			FinishSequence();
		}
	}
}
