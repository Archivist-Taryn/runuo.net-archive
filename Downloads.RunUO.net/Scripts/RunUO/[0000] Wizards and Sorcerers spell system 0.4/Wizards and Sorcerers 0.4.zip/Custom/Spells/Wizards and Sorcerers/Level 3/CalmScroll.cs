using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class CalmScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public CalmScroll() : this( 1 )
		{
		}

		[Constructable]
		public CalmScroll( int amount ) : base( 319, 0x1F2E, amount )
		{
			Name = "Calm";
		}
		
		public CalmScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
