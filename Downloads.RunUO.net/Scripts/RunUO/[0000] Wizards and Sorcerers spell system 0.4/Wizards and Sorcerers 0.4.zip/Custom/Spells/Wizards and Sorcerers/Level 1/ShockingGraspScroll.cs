using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ShockingGraspScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public ShockingGraspScroll() : this( 1 )
		{
		}

		[Constructable]
		public ShockingGraspScroll( int amount ) : base( 339, 0x1F2E, amount )
		{
			Name = "Shocking Grasp";
		}
		
		public ShockingGraspScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
