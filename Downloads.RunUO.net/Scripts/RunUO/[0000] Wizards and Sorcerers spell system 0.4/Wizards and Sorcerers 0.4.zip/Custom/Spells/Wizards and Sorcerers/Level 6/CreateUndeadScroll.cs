using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class CreateUndeadScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public CreateUndeadScroll() : this( 1 )
		{
		}

		[Constructable]
		public CreateUndeadScroll( int amount ) : base( 318, 0x1F2E, amount )
		{
			Name = "Create Undead";
		}
		
		public CreateUndeadScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
