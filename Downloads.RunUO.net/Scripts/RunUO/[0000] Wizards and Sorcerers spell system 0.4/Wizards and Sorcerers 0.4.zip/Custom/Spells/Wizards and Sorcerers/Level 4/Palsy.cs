using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using System.Collections;

namespace Server.Spells.Magician
{
	public class PalsySpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
		                                                "Palsy", "Hun Larvae",
		                                                Reagent.BatWing,
		                                                Reagent.Nightshade,
		                                                Reagent.MandrakeRoot
		                                               );
		public override string Desc{ get{ return "Unleashes a horrible spasm upon your target!"; } }
		public override string ReagentsDesc{ get{ return "One Bat Wing, Nightshade, Mandrage Root. "; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fourth; } }
        public override int SpellNumber { get { return 347; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Necromancy; } }
		public PalsySpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		public void Target( Mobile mob )
		{
			int time = Utility.Random(15, 30);
			if ( !Caster.CanSee( mob ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckSequence() )
			{
				if( mob.Player )
				{
					if (mob is PolyGlotMobile)
					{
						PolyGlotMobile m = mob as PolyGlotMobile;
						TimeSpan duration = TimeSpan.FromSeconds((int)time);
						if(((m.Skills[SkillName.MagicResist].Value * 3)+m.Int) > (Caster.Skills[SkillName.EvalInt].Value + Caster.Skills[SkillName.Magery].Value + Caster.Int))
						{
							m.SendMessage("You feel a tingle in your scalp but thats all.");
							Caster.SendMessage(m.Name +" is too strong for your Palsy Spell to take effect!");
						}
						else
						{
							m.Emote("You see "+m.Name+" have a spasm!");
							new PauseTimer(m, time, duration ).Start();
							m.Squelched = false;
						}
					}
					

				}
				else // npc case
				{

				}
			}
		}
		

		private class PauseTimer : Timer
		{
			private Mobile ma;
			
			private int counter = 0;
			private int count;
			
			public PauseTimer( Mobile m, int time, TimeSpan duration ) : base( TimeSpan.Zero, TimeSpan.FromSeconds( 1 ), time )
			{
				ma = m;
				count = time;
			}
			protected override void OnTick()
			{
				counter++;
				if (counter < count)
					ma.Squelched = true;
				else
					ma.Squelched = false;
				
				Direction direction;
				direction = (Direction)Utility.Random( 1, 7 );
				ma.PlaySound( ma.Female ? 0x32B : 0x43C );
				ma.Move(direction);
				ma.Move(direction);
				ma.DisruptiveAction();
				ma.RevealingAction();
				ma.Damage(Utility.Random(0,3));
			}
		}
		
		private class InternalTarget : Target
		{
			private PalsySpell m_Owner;
			
			public InternalTarget( PalsySpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}
			
			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}
			
			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	} // end spell class
} // end namespace

