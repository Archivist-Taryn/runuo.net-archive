using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class MirrorImageSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Mirror Image", "Nurae Iratos Loc",
				Reagent.BlackPearl,
				Reagent.BatWing,
				Reagent.NoxCrystal
			);
		public override string Desc{ get{ return "Several illusory duplicates of a target are created to confuse enemies."; } }
		public override string ReagentsDesc{ get{ return "One BlackPearl, Batwing, NoxCrystal"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 344; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 30.0; } }
		public override int RequiredMana{ get{ return 20; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Illusion; } }

		public MirrorImageSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}
		
		public void Target( PolyGlotMobile m )
		{
			if ( !Caster.CanSee( m as Mobile ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckSequence() )
			{
				for (int i = 0; ((i < (int)(Caster.Skills[SkillName.Magery].Value)) && (i < 6)); i++)
				{
					SpellHelper.Summon( new DSClone( m ), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
				}
			}
			
			FinishSequence();
		}
		
		public class InternalTarget : Target
		{
			private MirrorImageSpell m_Owner;

			public InternalTarget( MirrorImageSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is PolyGlotMobile )
					m_Owner.Target( (PolyGlotMobile)o );
				else
					m_Owner.Caster.SendMessage("You cannot target that.");
			}

		}
		
	}
}
