using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class IncognitoMScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public IncognitoMScroll() : this( 1 )
		{
		}

		[Constructable]
		public IncognitoMScroll( int amount ) : base( 310, 0x1F2E, amount )
		{
			Name = "Incognito";
		}
		
		public IncognitoMScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
