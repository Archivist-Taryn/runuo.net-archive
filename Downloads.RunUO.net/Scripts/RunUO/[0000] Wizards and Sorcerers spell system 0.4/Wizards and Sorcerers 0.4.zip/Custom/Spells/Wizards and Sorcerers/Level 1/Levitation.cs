using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Misc;
using Server.Items;
using System.Collections;

namespace Server.Spells.Magician
{
	public class LevitationSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
            "Levitation", "Mit Sisen",
            Reagent.SulfurousAsh
            );
		public override string Desc{ get{ return "Levitates you slightly above the ground."; } }
		public override string ReagentsDesc{ get{ return "One SulfurousAsh."; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 15.0; } }
		public override int RequiredMana{ get{ return 10; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 366; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }
		
		public LevitationSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Target( Caster );
		}
		
		public void Target( Mobile m )
		{
			if ( m is PolyGlotMobile )
			{
				if ( !Caster.CanSee( m ) )
				{
					Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
				}
				else if ( CheckBSequence( m ) )
				{
					SpellHelper.Turn( Caster, m );
					
					TimeSpan span = TimeSpan.FromSeconds( Caster.Int );
					PolyGlotMobile dark = m as PolyGlotMobile;
					new LevitationTimer(Caster, span).Start();
					m.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
					m.PlaySound( 0x1EE );
				}
			}
			else
				Caster.SendMessage("Cannot cast on that creature.");
			
			FinishSequence();
		}
		
		public class LevitationTimer : Timer
		{
			public ArrayList steps = new ArrayList();
			
			public Mobile Caster;
			
			public LevitationTimer( Mobile caster, TimeSpan duration ) : base( duration )
			{
				caster.Z += 35;
				Caster = caster;
				
				InvisibleStep step1 = new InvisibleStep( this );
				step1.Location = this.Caster.Location;
				
				InvisibleStep step2 = new InvisibleStep( this );
				step2.Map = this.Caster.Map;
				step2.X = this.Caster.X - 1;
				step2.Y = this.Caster.Y - 1;
				step2.Z = this.Caster.Z;
				
				InvisibleStep step3 = new InvisibleStep( this );
				step3.Map = this.Caster.Map;
				step3.X = this.Caster.X - 1;
				step3.Y = this.Caster.Y;
				step3.Z = this.Caster.Z;
				
				InvisibleStep step4 = new InvisibleStep( this );
				step4.Map = this.Caster.Map;
				step4.X = this.Caster.X - 1;
				step4.Y = this.Caster.Y + 1;
				step4.Z = this.Caster.Z;
				
				InvisibleStep step5 = new InvisibleStep( this );
				step5.Map = this.Caster.Map;
				step5.X = this.Caster.X;
				step5.Y = this.Caster.Y - 1;
				step5.Z = this.Caster.Z;
				
				InvisibleStep step6 = new InvisibleStep( this );
				step6.Map = this.Caster.Map;
				step6.X = this.Caster.X;
				step6.Y = this.Caster.Y + 1;
				step6.Z = this.Caster.Z;
				
				InvisibleStep step7 = new InvisibleStep( this );
				step7.Map = this.Caster.Map;
				step7.X = this.Caster.X + 1;
				step7.Y = this.Caster.Y - 1;
				step7.Z = this.Caster.Z;
				
				InvisibleStep step8 = new InvisibleStep( this );
				step8.Map = this.Caster.Map;
				step8.X = this.Caster.X + 1;
				step8.Y = this.Caster.Y;
				step8.Z = this.Caster.Z;
				
				InvisibleStep step9 = new InvisibleStep( this );
				step9.Map = this.Caster.Map;
				step9.X = this.Caster.X + 1;
				step9.Y = this.Caster.Y + 1;
				step9.Z = this.Caster.Z;
			}
			protected override void OnTick()
			{
				for (int i = 0; i < steps.Count; i++)
				{
					if (steps[i] is InvisibleStep)
					{
						InvisibleStep step = steps[i] as InvisibleStep;
						step.Delete();
					}
				}
				
				steps.Clear();
			}
		}
		
		public class InvisibleStep : Item
		{
			LevitationTimer m_time;
			
			
			public InvisibleStep(LevitationTimer time) : base ( 0x2198 )
			{
				this.Hue = 1;
				m_time = time;
				m_time.steps.Add( this );
			}
			
			public InvisibleStep( Serial s) : base (s)
			{
				
			}
			
			//public override bool HandlesOnMovement{ get{ return true; } }
			
			public override bool OnMoveOver( Mobile m )
			{
				if (m == m_time.Caster)
				{
					for( int i = 0; i < m_time.steps.Count; i++)
					{
						if ( m_time.steps[i] is InvisibleStep)
						{
							InvisibleStep step = m_time.steps[i] as InvisibleStep;
							step.Delete();
						}
						
					}
					
					m_time.steps.Clear();
					
					InvisibleStep step1 = new InvisibleStep( m_time );
					step1.Map = m_time.Caster.Map;
					step1.Location = m_time.Caster.Location;
					
					InvisibleStep step2 = new InvisibleStep( m_time );
					step2.Map = m_time.Caster.Map;
					step2.X = m_time.Caster.X - 2;
					step2.Y = m_time.Caster.Y - 2;
					step2.Z = m_time.Caster.Z;
					
					InvisibleStep step3 = new InvisibleStep( m_time );
					step3.Map = m_time.Caster.Map;
					step3.X = m_time.Caster.X - 2;
					step3.Y = m_time.Caster.Y - 1;
					step3.Z = m_time.Caster.Z;
					
					InvisibleStep step4 = new InvisibleStep( m_time );
					step4.Map = m_time.Caster.Map;
					step4.X = m_time.Caster.X - 2;
					step4.Y = m_time.Caster.Y;
					step4.Z = m_time.Caster.Z;
					
					InvisibleStep step5 = new InvisibleStep( m_time );
					step5.Map = m_time.Caster.Map;
					step5.X = m_time.Caster.X - 2;
					step5.Y = m_time.Caster.Y + 1;
					step5.Z = m_time.Caster.Z;
					
					InvisibleStep step6 = new InvisibleStep( m_time );
					step6.Map = m_time.Caster.Map;
					step6.X = m_time.Caster.X - 2;
					step6.Y = m_time.Caster.Y + 2;
					step6.Z = m_time.Caster.Z;
					
					InvisibleStep step7 = new InvisibleStep( m_time );
					step7.Map = m_time.Caster.Map;
					step7.X = m_time.Caster.X - 1;
					step7.Y = m_time.Caster.Y - 2;
					step7.Z = m_time.Caster.Z;
					
					InvisibleStep step8 = new InvisibleStep( m_time );
					step8.Map = m_time.Caster.Map;
					step8.X = m_time.Caster.X - 1;
					step8.Y = m_time.Caster.Y - 1;
					step8.Z = m_time.Caster.Z;
					
					InvisibleStep step9 = new InvisibleStep( m_time );
					step9.Map = m_time.Caster.Map;
					step9.X = m_time.Caster.X - 1;
					step9.Y = m_time.Caster.Y;
					step9.Z = m_time.Caster.Z;
					
					InvisibleStep step10 = new InvisibleStep( m_time );
					step10.Map = m_time.Caster.Map;
					step10.X = m_time.Caster.X - 1;
					step10.Y = m_time.Caster.Y + 1;
					step10.Z = m_time.Caster.Z;
					
					InvisibleStep step11 = new InvisibleStep( m_time );
					step11.Map = m_time.Caster.Map;
					step11.X = m_time.Caster.X - 1;
					step11.Y = m_time.Caster.Y + 2;
					step11.Z = m_time.Caster.Z;
					
					InvisibleStep step12 = new InvisibleStep( m_time );
					step12.Map = m_time.Caster.Map;
					step12.X = m_time.Caster.X;
					step12.Y = m_time.Caster.Y - 2;
					step12.Z = m_time.Caster.Z;
					
					InvisibleStep step13 = new InvisibleStep( m_time );
					step13.Map = m_time.Caster.Map;
					step13.X = m_time.Caster.X;
					step13.Y = m_time.Caster.Y - 1;
					step13.Z = m_time.Caster.Z;
					
					InvisibleStep step14 = new InvisibleStep( m_time );
					step14.Map = m_time.Caster.Map;
					step14.X = m_time.Caster.X;
					step14.Y = m_time.Caster.Y + 1;
					step14.Z = m_time.Caster.Z;
					
					InvisibleStep step15 = new InvisibleStep( m_time );
					step15.Map = m_time.Caster.Map;
					step15.X = m_time.Caster.X;
					step15.Y = m_time.Caster.Y + 2;
					step15.Z = m_time.Caster.Z;
					
					InvisibleStep step16 = new InvisibleStep( m_time );
					step16.Map = m_time.Caster.Map;
					step16.X = m_time.Caster.X + 1;
					step16.Y = m_time.Caster.Y - 2;
					step16.Z = m_time.Caster.Z;
					
					InvisibleStep step17 = new InvisibleStep( m_time );
					step17.Map = m_time.Caster.Map;
					step17.X = m_time.Caster.X + 1;
					step17.Y = m_time.Caster.Y - 1;
					step17.Z = m_time.Caster.Z;
					
					InvisibleStep step18 = new InvisibleStep( m_time );
					step18.Map = m_time.Caster.Map;
					step18.X = m_time.Caster.X + 1;
					step18.Y = m_time.Caster.Y;
					step18.Z = m_time.Caster.Z;
					
					InvisibleStep step19 = new InvisibleStep( m_time );
					step19.Map = m_time.Caster.Map;
					step19.X = m_time.Caster.X + 1;
					step19.Y = m_time.Caster.Y + 1;
					step19.Z = m_time.Caster.Z;
					
					InvisibleStep step20 = new InvisibleStep( m_time );
					step20.Map = m_time.Caster.Map;
					step20.X = m_time.Caster.X + 1;
					step20.Y = m_time.Caster.Y + 2;
					step20.Z = m_time.Caster.Z;
					
					InvisibleStep step21 = new InvisibleStep( m_time );
					step21.Map = m_time.Caster.Map;
					step21.X = m_time.Caster.X + 2;
					step21.Y = m_time.Caster.Y - 2;
					step21.Z = m_time.Caster.Z;
					
					InvisibleStep step22 = new InvisibleStep( m_time );
					step22.Map = m_time.Caster.Map;
					step22.X = m_time.Caster.X + 2;
					step22.Y = m_time.Caster.Y - 1;
					step22.Z = m_time.Caster.Z;
					
					InvisibleStep step23 = new InvisibleStep( m_time );
					step23.Map = m_time.Caster.Map;
					step23.X = m_time.Caster.X + 2;
					step23.Y = m_time.Caster.Y;
					step23.Z = m_time.Caster.Z;
					
					InvisibleStep step24 = new InvisibleStep( m_time );
					step24.Map = m_time.Caster.Map;
					step24.X = m_time.Caster.X + 2;
					step24.Y = m_time.Caster.Y + 1;
					step24.Z = m_time.Caster.Z;
					
					InvisibleStep step25 = new InvisibleStep( m_time );
					step25.Map = m_time.Caster.Map;
					step25.X = m_time.Caster.X + 2;
					step25.Y = m_time.Caster.Y + 2;
					step25.Z = m_time.Caster.Z;
				}
				
				return true;
			}
			
			public override void Serialize( GenericWriter writer )
			{
				base.Serialize( writer );
			}
			
			public override void Deserialize( GenericReader reader )
			{
				base.Deserialize( reader );
				this.Delete();
			}
		}
	}
}
