using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class GateSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Summon Daemon", "Culloth Ingranul Notos",
				17,
				Reagent.DaemonBlood,
				Reagent.Bone,
				Reagent.SpidersSilk,
				Reagent.SulfurousAsh,
				Reagent.BloodSpawn,
				Reagent.BloodSpawn,
				Reagent.BloodSpawn
			);
		
		public override string Desc{ get{ return "A mighty creature from another plane is summoned under your control."; } }
		public override string ReagentsDesc{ get{ return "Three BloodSpawn, one SpidersSilk, SulfurousAsh, Bone, DaemonBlood"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Eighth; } }
        public override int SpellNumber { get { return 313; } }
        public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 90.0; } }
		public override int RequiredMana{ get{ return 60; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Conjuration; } }

		public GateSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
				return false;

			if ( (Caster.Followers + 5) > Caster.FollowersMax )
			{
				Caster.SendLocalizedMessage( 1049645 ); // You have too many followers to summon that creature.
				return false;
			}

			return true;
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				if ( Core.AOS )
					SpellHelper.Summon( new SummonedDaemon(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
				else
					SpellHelper.Summon( new Daemon(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
			}

			FinishSequence();
		}
	}
}
