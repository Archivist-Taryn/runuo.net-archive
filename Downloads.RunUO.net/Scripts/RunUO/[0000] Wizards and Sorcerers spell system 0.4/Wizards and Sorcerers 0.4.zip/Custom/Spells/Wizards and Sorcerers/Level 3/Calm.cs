using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class CalmSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Calm", "Blithre Sanrae",
				Reagent.BlackPearl,
				Reagent.NoxCrystal,
				Reagent.PigIron
			);
		public override string Desc{ get{ return "Calms an angry creature."; } } 
		public override string ReagentsDesc{ get{ return "One BlackPearl, NoxCrystal, PigIron."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 319; } }
		public override double CastDelay{ get{ return 7.0; } }
		public override double RequiredSkill{ get{ return 50.0; } }
		public override int RequiredMana{ get{ return 30; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Enchantment; } }

		public CalmSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.SendLocalizedMessage( 1049525 ); // Whom do you wish to calm?
			Caster.Target = new InternalTarget( this );
			Caster.RevealingAction();
		}

		public void Target( Mobile m )
		{
			// Target mode : pacify a single target for a longer duration

			Mobile targ = m;
			if ( !Caster.CanBeHarmful( targ, false ) )
			{
				Caster.SendLocalizedMessage( 1049528 );
			}
			else if ( targ is BaseCreature && ((BaseCreature)targ).Uncalmable )
			{
				Caster.SendLocalizedMessage( 1049526 ); // You have no chance of calming that creature.
			}
			else if ( targ is BaseCreature && ((BaseCreature)targ).BardPacified )
			{
				Caster.SendLocalizedMessage( 1049527 ); // That creature is already being calmed.
			}
			else if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				SpellHelper.Turn( Caster, m );
			
				// This portion adds a difficulty based on skill, whatever the caster's skill is put a % behind it and thats the chance for success
				int sr;

				double magery = Caster.Skills[SkillName.Magery].Value; //gets the caster's magery skill

				double mageryvalue = (magery * 10); // prepares the double for int'dom

				int srvalue = (int)mageryvalue; //makes the magery value an int for our utility random

				sr = Utility.Random (srvalue, (srvalue + 1000)); // gets a random number based upon our the player's skill

				if (sr < 1000) // checks the success rate to see if they rolled above or below the success line
				{
					Caster.SendLocalizedMessage( 1049531 ); // You attempt to calm your target, but fail.
				}
				else
				{



					if ( targ is BaseCreature )
					{
						BaseCreature bc = (BaseCreature)targ;
						Caster.SendMessage( "You see the creature relaxed and calm, due to your hypnotic spell." ); // Custom Message.
						targ.Combatant = null;
						targ.Warmode = false;

						double seconds = (magery / 10);
						bc.Pacify( Caster, DateTime.Now + TimeSpan.FromSeconds( seconds ) );
					}
					else
					{
						Caster.SendMessage( "You see your target relaxed and calm, due to your hypnotic spell." ); // Custom Message.

						targ.SendMessage( "You feel relaxed and calm, you don't have a care in the world...." ); // Custom Message.
	
						targ.Combatant = null;
						targ.Warmode = false;
					}
				}
			}
			FinishSequence();
		}

		private class InternalTarget : Target
		{
			
			private CalmSpell m_Owner;
			public InternalTarget(  CalmSpell owner ) : base( 10, false, TargetFlags.None )
			{
				m_Owner = owner;
			}
			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}
			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}

