using System;
using System.Collections;
using Server.Network;
using Server.Items;
using Server.Targeting;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class TremorSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Tremor", "In Vas Por",
				17,
				Reagent.Bloodmoss,
				Reagent.Ginseng,
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.SulfurousAsh,
				Reagent.SulfurousAsh,
				Reagent.SulfurousAsh
			);
		
		public override string Desc{ get{ return "Calls upon a mighty earthquake."; } }
		public override string ReagentsDesc{ get{ return "One Bloodmoss, Ginseng, Three MandrakeRoot, Sulfuric Ash  "; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Eighth; } }
        public override int SpellNumber { get { return 307; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 90.0; } }
		public override int RequiredMana{ get{ return 60; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }

		public TremorSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool DelayedDamage{ get{ return !Core.AOS; } }

		public override void OnCast()
		{
			if ( SpellHelper.CheckTown( Caster, Caster ) && CheckSequence() )
			{
				ArrayList targets = new ArrayList();

				Map map = Caster.Map;

				if ( map != null )
				{
					foreach ( Mobile m in Caster.GetMobilesInRange( 15 ) )
					{
						targets.Add( m );
					}
				}

				Caster.PlaySound( 0x2F3 );

				for ( int i = 0; i < targets.Count; ++i )
				{
					Mobile m = (Mobile)targets[i];

					int damage = (int)(m.Hits * 0.6);

					Caster.DoHarmful( m );
					//damage = AbsorbDamage(m, ResistType.Slashing, damage/3) + AbsorbDamage(m, ResistType.Piercing, damage/3) + AbsorbDamage(m, ResistType.Bludgeoning, damage/3);
					m.Damage( damage );
				}
			}

			FinishSequence();
		}
	}
}
