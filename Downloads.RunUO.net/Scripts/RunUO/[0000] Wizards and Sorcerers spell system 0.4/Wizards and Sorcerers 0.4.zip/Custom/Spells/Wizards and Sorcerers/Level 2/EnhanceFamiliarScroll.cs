using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class EnhanceFamiliarScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public EnhanceFamiliarScroll() : this( 1 )
		{
		}

		[Constructable]
		public EnhanceFamiliarScroll( int amount ) : base( 353, 0x1F2E, amount )
		{
			Name = "Enhance Familiar";
		}
		
		public EnhanceFamiliarScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}

