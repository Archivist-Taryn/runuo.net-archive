using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class PolymorphSelfScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public PolymorphSelfScroll() : this( 1 )
		{
		}

		[Constructable]
		public PolymorphSelfScroll( int amount ) : base( 330, 0x1F2E, amount )
		{
			Name = "Polymorph Self";
		}
		
		public PolymorphSelfScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
