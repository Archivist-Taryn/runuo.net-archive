using System;
using System.Collections;
using Server.Network;
using Server.Mobiles;
using Server.Targeting;
using Server.Items;


namespace Server.Spells.Magician
{
	public class CreateUndeadSpell : MagicianSpell
	{
		private Mobile ca;
		private static SpellInfo m_Info = new SpellInfo(
				"Create Dead", "Mit Viver Morte",
				17,
				Reagent.Ginseng,
				Reagent.Ginseng,
				Reagent.Bone,
				Reagent.Bone,
				Reagent.Bone,
				Reagent.Bone,
				Reagent.BloodSpawn,
				Reagent.BloodSpawn,
				Reagent.BloodSpawn
			);
		
		public override string Desc{ get{ return "Allows to create more powerful sorts of undead, when targeting corpses."; } }
		public override string ReagentsDesc{ get{ return "Four Bone, Two Ginseng, Three BloodSpawn"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Sixth; } }
        public override int SpellNumber { get { return 318; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 75.0; } }
		public override int RequiredMana{ get{ return 50; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Necromancy; } }


		public CreateUndeadSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
				return false;

			if ( (Caster.Followers + 1) > Caster.FollowersMax )
			{
				Caster.SendLocalizedMessage( 1049645 ); // You have too many followers to summon that creature.
				return false;
			}

			return true;
		}

		public override void OnCast()
		{
			ca = Caster;
			Caster.Target = new InternalTarget( this );
			Caster.SendLocalizedMessage( 1061083 ); // Animate what corpse?
		}

		
		public void Target( object obj )
		{


			Corpse c = obj as Corpse;

			if ( c == null )
			{
				Caster.SendLocalizedMessage( 1061084 ); // You cannot animate that.
			}
			else
			{
				Type type = null;
				int bv = 0;
				string cname = null;

				if ( c.Owner != null )
					type = c.Owner.GetType();

				if ( c.ItemID != 0x2006 || c.Channeled || type == typeof( PlayerMobile ) || type == null || (c.Owner != null && c.Owner.Fame < 100) || ((c.Owner != null) && (c.Owner is BaseCreature) && (((BaseCreature)c.Owner).Summoned || ((BaseCreature)c.Owner).IsBonded)) )
				{
					Caster.SendLocalizedMessage( 1061085 ); // There's not enough life force there to animate.
				}
				else
				{
					int hits = 0;
					int karma = 0;
					int fame = 0;
					int damage = 0;
					int va = 0;
					bv = c.Owner.BodyValue;
					double magery = ca.Skills[SkillName.Magery].Value; //gets the caster's magery skill
					cname = c.Owner.Name;
					int skill = 0;
					if (magery <= 0)
						skill = 1;
					else if (magery <= 10)
						skill = 2;
					else if (magery <= 20)
						skill = 3;
					else if (magery <= 30)
						skill = 4;
					else if (magery <= 40)
						skill = 5;
					else if (magery <= 50)
						skill = 6;
					else if (magery <= 60)
						skill = 7;
					else if (magery <= 70)
						skill = 8;
					else if (magery <= 80)
						skill = 9;
					else if (magery <= 90)
						skill = 10;
					else if (magery <= 100)
						skill = 11;
					else if (magery > 100)
						skill = 12;
					else
						skill = 0;
					
					switch(skill)
					{
						case 1:
							hits = 15;
							karma = -100;
							fame = 100;
							damage = 5;
							va = 15;
						break;
						case 2:
							hits = 30;
							karma = -200;
							fame = 200;
							damage = 8;
							va = 20;
						break;
						case 3:
							hits = 45;
							karma = -300;
							fame = 300;
							damage = 10;
							va = 25;
						break;
						case 4:
							hits = 60;
							karma = -400;
							fame = 400;
							damage = 12;
							va = 30;
						break;
						case 5:
							hits = 75;
							karma = -500;
							fame = 500;
							damage = 13;
							va = 35;
						break;
						case 6:
							hits = 90;
							karma = -600;
							fame = 600;
							damage = 15;
							va = 40;
						break;
						case 7:
							hits = 105;
							karma = -700;
							fame = 700;
							damage = 16;
							va = 45;
						break;
						case 8:
							hits = 115;
							karma = -800;
							fame = 800;
							damage = 17;
							va = 50;
						break;
						case 9:
							hits = 125;
							karma = -900;
							fame = 900;
							damage = 18;
							va = 55;
						break;
						case 10:
							hits = 135;
							karma = -1000;
							fame = 1000;
							damage = 19;
							va = 60;
						break;
						case 11:
							hits = 145;
							karma = -1100;
							fame = 1100;
							damage = 20;
							va = 65;
						break;
						case 12:
							hits = 150;
							karma = -1200;
							fame = 1200;
							damage = 21;
							va = 70;
						break;
						default:
							hits = 15;
							karma = -100;
							fame = 100;
							damage = 5;
							va = 15;
						break;
					}


					
					if ( CheckSequence() )
					{
						Point3D p = c.GetWorldLocation();
						Map map = c.Map;

						if ( map != null )
						{
								Effects.PlaySound( p, map, 0x1FB );
								Effects.SendLocationParticles( EffectItem.Create( p, map, EffectItem.DefaultDuration ), 0x3789, 1, 40, 0x3F, 3, 9907, 0 );
								SpellHelper.Summon( new UndeadSpawn(cname, bv, hits, karma, fame, damage, va), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
								c.TurnToBones();
						}
					}
					
				}
			}

			FinishSequence();
		}




		private class InternalTarget : Target
		{
			private CreateUndeadSpell m_Owner;

			public InternalTarget( CreateUndeadSpell owner ) : base( 12, false, TargetFlags.None )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				m_Owner.Target( o );
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}

}
