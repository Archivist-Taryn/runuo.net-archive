using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;

namespace Server.Spells.Magician
{
	public class SummonMonster2Spell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Summon Monster Two", "Culloth Minrae Mi",
				Reagent.Nightshade,
				Reagent.Nightshade,
				Reagent.MandrakeRoot
			);

		public override string Desc{ get{ return "Summons a medium sized creature to attack your enemies."; } } 
		public override string ReagentsDesc{ get{ return "Two Nightshade, One MandrakeRoot."; } }	
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 40.0; } }
		public override int RequiredMana{ get{ return 25; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Conjuration; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Second; } }
        public override int SpellNumber { get { return 322; } }

		public SummonMonster2Spell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
				return false;

			if ( (Caster.Followers + 1) > Caster.FollowersMax )
			{
				Caster.SendLocalizedMessage( 1049645 ); // You have too many followers to summon that creature.
				return false;
			}

			return true;
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				switch( Utility.Random( 3 ) )
				{
					case 0:
                        SpellHelper.Summon(new GiantBlackWidow(), Caster, 0x216, TimeSpan.FromSeconds(4.0 * Caster.Skills[SkillName.Magery].Value), false, false);
					break;
					case 1:
                    SpellHelper.Summon(new GiantBlackWidow(), Caster, 0x216, TimeSpan.FromSeconds(4.0 * Caster.Skills[SkillName.Magery].Value), false, false);
					break;
					case 2:
						SpellHelper.Summon( new GiantBlackWidow(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
					break;
					default:
						SpellHelper.Summon( new GiantBlackWidow(), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
					break;
				}
			}

			FinishSequence();
		}
	}
}
