using System;
using Server.Targeting;
using Server.Network;
using Server.Items;
using Server.Gumps;

namespace Server.Spells.Magician
{
	public class ReadMagicSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Read Magic", "Locter Mythos Mistre",
				Reagent.Bone
			);
		public override string Desc{ get{ return "Grants knowledge of unknown magical scrolls."; } } 
		public override string ReagentsDesc{ get{ return "One Bone."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 342; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 15.0; } }
		public override int RequiredMana{ get{ return 10; } }
	
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Divination; } }

		public ReadMagicSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( SpellScroll m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if(CheckSequence())
			{
				Caster.SendGump( new InfoSpellGump(m) );
				FinishSequence();
			}
		}

		private class InternalTarget : Target
		{
			private ReadMagicSpell m_Owner;

			public InternalTarget( ReadMagicSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			} 

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is SpellScroll )
				{
					m_Owner.Target( (SpellScroll)o );
				}
			}
		}
	}
}
