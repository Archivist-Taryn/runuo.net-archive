using System;
using System.Collections;
using Server.Network;
using Server.Mobiles;
using Server.Targeting;
using Server.Items;


namespace Server.Spells.Magician
{
	public class ShadesSpell : MagicianSpell
	{
		private Shade ca;
		private static SpellInfo m_Info = new SpellInfo(
				"Shades", "Culloth Bisrae Inrae",
				Reagent.GraveDust,
				Reagent.SpidersSilk,
				Reagent.BloodSpawn
			);
		
		public override string Desc{ get{ return "Creates a powerful ally that is very resistant to physical attacks."; } }
		public override string ReagentsDesc{ get{ return "One Grave Dust, One Spider's Silk, One BloodSpawn"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fourth; } }
        public override int SpellNumber { get { return 356; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 75.0; } }
		public override int RequiredMana{ get{ return 50; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Illusion; } }


		public ShadesSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
				return false;

			if ( (Caster.Followers + 1) > Caster.FollowersMax )
			{
				Caster.SendLocalizedMessage( 1049645 ); // You have too many followers to summon that creature.
				return false;
			}

			return true;
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				Point3D p = Caster.Location;
				Map map = Caster.Map;

				if ( map != null )
				{
						Effects.PlaySound( p, map, 0x1FB );
						Effects.SendLocationParticles( EffectItem.Create( p, map, EffectItem.DefaultDuration ), 0x3789, 1, 40, 0x3F, 3, 9907, 0 );
						SpellHelper.Summon( new Shade( Caster as PolyGlotMobile ), Caster, 0x216, TimeSpan.FromSeconds( 4.0 * Caster.Skills[SkillName.Magery].Value ), false, false );
				}
			}
			FinishSequence();
		}
	}
	
	public class Shade : BaseCreature
	{
		private PolyGlotMobile Caster;
		public Shade( PolyGlotMobile caster ) : base( AIType.AI_Melee, FightMode.Strongest, 10, 1, 0.2, 0.4 )
		{
			Caster = caster;
			Name = Caster.Name + "'s Shade";
			Body = Caster.Body;
			Hue = 1;
			ControlSlots = 0;
			BaseSoundID = Caster.BaseSoundID;
			
			double magery = Caster.Skills[SkillName.Magery].Value; //gets the caster's magery skill
			int skill = 0;
			if (magery <= 0)
				skill = 1;
			else if (magery <= 10)
				skill = 2;
			else if (magery <= 20)
				skill = 3;
			else if (magery <= 30)
				skill = 4;
			else if (magery <= 40)
				skill = 5;
			else if (magery <= 50)
				skill = 6;
			else if (magery <= 60)
				skill = 7;
			else if (magery <= 70)
				skill = 8;
			else if (magery <= 80)
				skill = 9;
			else if (magery <= 90)
				skill = 10;
			else if (magery <= 100)
				skill = 11;
			else if (magery > 110)
				skill = 12;
			else
				skill = 0;
			
			
			switch(skill)
			{
				case 1:
					SetStr( 20, 30 );
					SetDex( 20, 30 );
					this.Int = Caster.Int;
					this.SetHits( 25, 35 );
					SetSkill( SkillName.Tactics, 50.0 );
					SetSkill( SkillName.Wrestling, 50.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(50, 20);
                    //PiercingResist = Utility.Random(50, 20);
                    //SlashingResist = Utility.Random(50, 20);
				break;
				case 2:
					SetStr( 30, 40 );
					SetDex( 30, 40 );
					this.Int = Caster.Int;
					this.SetHits( 45, 55 );
					SetSkill( SkillName.Tactics, 55.0 );
					SetSkill( SkillName.Wrestling, 55.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(55, 20);
                    //PiercingResist = Utility.Random(55, 20);
                    //SlashingResist = Utility.Random(55, 20);
				break;
				case 3:
					SetStr( 35, 45 );
					SetDex( 35, 45 );
					this.Int = Caster.Int;
					this.SetHits( 65, 75 );
					SetSkill( SkillName.Tactics, 60.0 );
					SetSkill( SkillName.Wrestling, 60.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(60, 20);
                    //PiercingResist = Utility.Random(60, 20);
                    //SlashingResist = Utility.Random(60, 20);
				break;
				case 4:
					SetStr( 40, 50 );
					SetDex( 40, 50 );
					this.Int = Caster.Int;
					this.SetHits( 85, 95 );
					SetSkill( SkillName.Tactics, 65.0 );
					SetSkill( SkillName.Wrestling, 65.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(65, 20);
                    //PiercingResist = Utility.Random(65, 20);
                    //SlashingResist = Utility.Random(65, 20);
				break;
				case 5:
					SetStr( 45, 55 );
					SetDex( 45, 55 );
					this.Int = Caster.Int;
					this.SetHits( 105, 115 );
					SetSkill( SkillName.Tactics, 70.0 );
					SetSkill( SkillName.Wrestling, 70.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(70, 20);
                    //PiercingResist = Utility.Random(70, 20);
                    //SlashingResist = Utility.Random(70, 20);
				break;
				case 6:
					SetStr( 50, 60 );
					SetDex( 50, 60 );
					this.Int = Caster.Int;
					this.SetHits( 125, 135 );
					SetSkill( SkillName.Tactics, 75.0 );
					SetSkill( SkillName.Wrestling, 75.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(75, 20);
                    //PiercingResist = Utility.Random(75, 20);
                    //SlashingResist = Utility.Random(75, 20);
				break;
				case 7:
					SetStr( 55, 65 );
					SetDex( 55, 65 );
					this.Int = Caster.Int;
					this.SetHits( 145, 155 );
					SetSkill( SkillName.Tactics, 80.0 );
					SetSkill( SkillName.Wrestling, 80.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(80, 20);
                    //PiercingResist = Utility.Random(80, 20);
                    //SlashingResist = Utility.Random(80, 20);
				break;
				case 8:
					SetStr( 60, 65 );
					SetDex( 60, 65 );
					this.Int = Caster.Int;
					this.SetHits( 165, 175 );
					SetSkill( SkillName.Tactics, 85.0 );
					SetSkill( SkillName.Wrestling, 85.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(85, 15);
                    //PiercingResist = Utility.Random(85, 15);
                    //SlashingResist = Utility.Random(85, 15);
				break;
				case 9:
					SetStr( 65, 70 );
					SetDex( 65, 70 );
					this.Int = Caster.Int;
					this.SetHits( 185, 195 );
					SetSkill( SkillName.Tactics, 90.0 );
					SetSkill( SkillName.Wrestling, 90.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(90, 10);
                    //PiercingResist = Utility.Random(90, 10);
                    //SlashingResist = Utility.Random(90, 10);
				break;
				case 10:
					SetStr( 70, 75 );
					SetDex( 70, 75 );
					this.Int = Caster.Int;
					this.SetHits( 200 );
					SetSkill( SkillName.Tactics, 95.0 );
					SetSkill( SkillName.Wrestling, 95.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(95, 5);
                    //PiercingResist = Utility.Random(95, 5);
                    //SlashingResist = Utility.Random(95, 5);
				break;
				case 11:
					SetStr( 75, 80 );
					SetDex( 75, 80 );
					this.Int = Caster.Int;
					this.SetHits( 210 );
					SetSkill( SkillName.Tactics, 100.0 );
					SetSkill( SkillName.Wrestling, 100.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = 100;
                    //PiercingResist = 100;
                    //SlashingResist = 100;
				break;
				case 12:
					SetStr( 80, 85 );
					SetDex( 80, 85 );
					this.Int = Caster.Int;
					this.SetHits( 220 );
					SetSkill( SkillName.Tactics, 105.0 );
					SetSkill( SkillName.Wrestling, 105.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = 100;
                    //PiercingResist = 100;
                    //SlashingResist = 100;
				break;
				default:
					SetStr( 35, 45 );
					SetDex( 35, 45 );
					this.Int = Caster.Int;
					this.SetHits( 40, 50 );
					SetSkill( SkillName.Tactics, 60.0 );
					SetSkill( SkillName.Wrestling, 60.0 );
                    //FireResist = 0;
                    //ColdResist = 0;
                    //EnergyResist = 0;
                    //AcidResist = 100;
                    //PoisonResist = 100;
                    //BludgeoningResist = Utility.Random(60, 20);
                    //PiercingResist = Utility.Random(60, 20);
                    //SlashingResist = Utility.Random(60, 20);
				break;
			}
			
		}
		
		public override void OnDeath( Container c )
		{
			this.Delete();
		}
		
		public override void OnHarmfulAction( Mobile target, bool isCriminal )
		{
			if (target.Int > (this.Int/2 + Utility.Random(0, 35)))
			{
				target.SendMessage("You see through the illusion!");
				this.Delete();
				return;
			}
			
			base.OnHarmfulAction(target, isCriminal);
		}

		public Shade( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
	}
}

