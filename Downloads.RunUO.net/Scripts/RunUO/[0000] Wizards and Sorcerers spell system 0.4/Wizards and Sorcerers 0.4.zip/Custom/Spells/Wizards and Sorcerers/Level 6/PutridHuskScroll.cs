using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class PutridHuskScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public PutridHuskScroll() : this( 1 )
		{
		}

		[Constructable]
		public PutridHuskScroll( int amount ) : base( 365, 0x1F2E, amount )
		{
			Name = "Curse of the Putrid Husk";
		}
		
		public PutridHuskScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}

