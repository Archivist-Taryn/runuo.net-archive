using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class LightScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public LightScroll() : this( 1 )
		{
		}

		[Constructable]
		public LightScroll( int amount ) : base( 359, 0x1F2E, amount )
		{
			Name = "Light";
		}
		
		public LightScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}


