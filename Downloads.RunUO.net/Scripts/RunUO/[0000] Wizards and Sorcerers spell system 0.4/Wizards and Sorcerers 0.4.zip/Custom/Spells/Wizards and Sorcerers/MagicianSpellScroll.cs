using System;
using System.Collections;
using System.Collections.Generic;
using Server.Spells;
using Server.ContextMenus;
using Server.Mobiles;

namespace Server.Items
{
	public class MagicianSpellScroll : SpellScroll, ICommodity
	{
		private int m_SpellID;

		public int SpellID
		{
			get
			{
				return m_SpellID;
			}
		}

		int ICommodity.DescriptionNumber { get { return LabelNumber; } }
		bool ICommodity.IsDeedable { get { return (Core.ML); } }

		public MagicianSpellScroll( Serial serial ) : base( serial )
		{
		}

		[Constructable]
		public MagicianSpellScroll( int spellID, int itemID ) : this( spellID, itemID, 1 )
		{
		}

		[Constructable]
        public MagicianSpellScroll(int spellID, int itemID, int amount)
            : base(spellID, itemID)
		{
			Stackable = true;
			Weight = 1.0;
			Amount = amount;

			m_SpellID = spellID;
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version

			writer.Write( (int) m_SpellID );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			switch ( version )
			{
				case 0:
				{
					m_SpellID = reader.ReadInt();

					break;
				}
			}
		}

		public override void GetContextMenuEntries( Mobile from, List<ContextMenuEntry> list )
		{
            return;
		}

        public override bool OnDroppedOnto(Mobile from, Item target)
        {
            if (target is MagicianSpellbook && ((PolyGlotMobile)from).Class == ClassType.Wizard )
            {
                PolyGlotMobile poly = from as PolyGlotMobile;
                if ( m_SpellID>=300 && m_SpellID<400 ) 
                {
                    if (poly.SpellsKnown.HasSpell(m_SpellID))
                    {
                        poly.SendMessage("You already know that spell!");
                        return false;
                    }

                    poly.SpellsKnown.Add( poly, m_SpellID );
                    poly.SendMessage("You copy the spell to your book.");
                    return true;
                }
                return false;
            }

            return false;
        }


		public override void OnDoubleClick( Mobile from )
		{
            if (!IsChildOf(from.Backpack))
            {
                from.SendLocalizedMessage(1042001); // That must be in your pack for you to use it.
                return;
            }

            PolyGlotMobile MageGuy = from as PolyGlotMobile;
            if (MageGuy.Class != ClassType.Wizard && MageGuy.Class != ClassType.Sorcerer)
            {
                MageGuy.SendMessage("You cannot decipher the scroll's strange writings.");
                return;
            }
            else
            {
                Spell spell = SpellRegistry.NewSpell(m_SpellID, from, this);

                if (spell != null)
                    spell.Cast();
            }

		}
	}
}