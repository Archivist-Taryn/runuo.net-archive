using System;
using Server.Targeting;
using Server.Network;

namespace Server.Spells.Magician
{
	public class DrainLifeMSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Drain Life", "Inmit Viver",
				Reagent.Bone,
				Reagent.BlackPearl,
				Reagent.GraveDust
			);
		public override string Desc{ get{ return "This spell sucks out the life force of a target, and gives it to you."; } }
		public override string ReagentsDesc{ get{ return "One Bone, BlackPearl, GraveDust."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 312; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 55.0; } }
		public override int RequiredMana{ get{ return 30; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Necromancy; } }

		public DrainLifeMSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return true; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				Mobile source = Caster;

				SpellHelper.Turn( source, m );

				SpellHelper.CheckReflect( (int)this.SpellLevel, ref source, ref m );

				double damage = Utility.Random( 4, 4 );;
				
                //if ( Core.AOS )
                //{
                //    damage = GetAosDamage( 5, 1, 10.0 );
                //}
                //else
                //{
                //    damage = Utility.Random( 4, 4 );

                //    if ( CheckResisted( m ) )
                //    {
                //        damage *= 0.75;

                //        m.SendLocalizedMessage( 501783 ); // You feel yourself resisting magical energy.
                //    }
                //
				//	damage *= GetDamageScalar( m );
				//}

                damage *= GetDamageScalar(m);

				source.MovingParticles( m, 0x36E4, 5, 0, false, true, 3006, 4006, 0 );
				source.PlaySound( 0x1E5 );

				SpellHelper.Damage( TimeSpan.Zero, m, Caster, damage, 0, 100, 0, 0, 0 );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private DrainLifeMSpell m_Owner;

			public InternalTarget( DrainLifeMSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
