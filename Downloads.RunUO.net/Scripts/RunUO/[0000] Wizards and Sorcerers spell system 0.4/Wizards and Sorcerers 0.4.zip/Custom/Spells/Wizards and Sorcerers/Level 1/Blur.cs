using System;
using Server.Items;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;
using Server.Misc;
using Server;
using System.Collections;

namespace Server.Spells.Magician
{
	public class BlurSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Blur", "Totar Bisen",
				Reagent.SpidersSilk,
				Reagent.NoxCrystal
			);
		
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 25.0; } }
		public override int RequiredMana{ get{ return 20; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Illusion; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 324; } }
        public override string Desc{ get{ return "Blurs your body, hindering physical damage to you."; } } 
		public override string ReagentsDesc{ get{ return "One SpidersSilk, One NoxCrystal"; } }	

		public BlurSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}


		public override void OnCast()
		{
			if ( CheckSequence() )
			{

				new BlurTimer(Caster, TimeSpan.FromSeconds(30));
			}

			FinishSequence();
		}
		private class BlurTimer : Timer
		{
			private Mobile ma;
			private int helm;
			private int neck;
			private int shirt;
			private int gloves;
			private int arms;
			private int pants;
			private int shoes;
			private int itorso;
			private int mtorso;
			private int otorso;
			private int cloak;
			private int fhair;
			private int olegs;
			private int twohanded;
			private int waist;
			private int hair;
			private int h;
			private int blur = 0x4001;

			private Item h_helm;
			private Item h_neck;
			private Item h_shirt;
			private Item h_gloves;
			private Item h_arms;
			private Item h_pants;
			private Item h_shoes;
			private Item h_itorso;
			private Item h_mtorso;
			private Item h_otorso;
			private Item h_cloak;
			private Item h_fhair;
			private Item h_olegs;
			private Item h_twohanded;
			private Item h_waist;
			private Item h_hair;

			public BlurTimer( Mobile m, TimeSpan duration ) : base( duration )
			{
				ma = m;
				h = ma.Hue;
				if(!ma.Player)
				{
					ma.Hue = 0x4001;
				}

				else
				{
					Item m_helm = ma.FindItemOnLayer( Layer.Helm );
					Item m_neck = ma.FindItemOnLayer( Layer.Neck );
					Item m_shirt = ma.FindItemOnLayer( Layer.Shirt );
					Item m_gloves = ma.FindItemOnLayer( Layer.Gloves );
					Item m_arms = ma.FindItemOnLayer( Layer.Arms );
					Item m_pants = ma.FindItemOnLayer( Layer.Pants );
					Item m_shoes = ma.FindItemOnLayer( Layer.Shoes );
					Item m_itorso = ma.FindItemOnLayer( Layer.InnerTorso );
					Item m_mtorso = ma.FindItemOnLayer( Layer.MiddleTorso );
					Item m_otorso = ma.FindItemOnLayer( Layer.OuterTorso );
					Item m_cloak = ma.FindItemOnLayer( Layer.Cloak );
					Item m_fhair = ma.FindItemOnLayer( Layer.FacialHair );
					Item m_olegs = ma.FindItemOnLayer( Layer.OuterLegs );
					Item m_twohanded = ma.FindItemOnLayer( Layer.TwoHanded );
					Item m_waist = ma.FindItemOnLayer( Layer.Waist );
					Item m_hair = ma.FindItemOnLayer( Layer.Hair );

					h_helm = m_helm;
					h_neck = m_neck;
					h_shirt = m_shirt;
					h_gloves = m_gloves;
					h_arms = m_arms;
					h_pants = m_pants;
					h_shoes = m_shoes;
					h_itorso = m_itorso;
					h_mtorso = m_mtorso;
					h_otorso = m_otorso;
					h_cloak = m_cloak;
					h_fhair = m_fhair;
					h_olegs = m_olegs;
					h_twohanded = m_twohanded;
					h_waist = m_waist;
					h_hair = m_hair;

					if(m_helm != null)
					{
						helm = m_helm.Hue;
						m_helm.Hue = blur;
					}
					if(m_neck != null)
					{
						neck = m_neck.Hue;
						m_neck.Hue = blur;
					}
					if(m_shirt != null)
					{
						shirt = m_shirt.Hue;
						m_shirt.Hue = blur;
					}
					if(m_gloves != null)
					{
						gloves = m_gloves.Hue;
						m_gloves.Hue = blur;
					}
					if(m_arms != null)
					{
						arms = m_arms.Hue;
						m_arms.Hue = blur;
					}
					if(m_pants != null)
					{
						pants = m_pants.Hue;
						m_pants.Hue = blur;
					}
					if(m_shoes != null)
					{
						shoes = m_shoes.Hue;
						m_shoes.Hue = blur;
					}
					if(m_itorso != null)
					{
						itorso = m_itorso.Hue;
						m_itorso.Hue = blur;
					}
					if(m_mtorso != null)
					{
						mtorso = m_mtorso.Hue;
						m_mtorso.Hue = blur;
					}
					if(m_otorso != null)
					{
						otorso = m_otorso.Hue;
						m_otorso.Hue = blur;
					}
					if(m_cloak != null)
					{
						cloak = m_cloak.Hue;
						m_cloak.Hue = blur;
					}
					if(m_fhair != null)
					{
						fhair = m_fhair.Hue;
						m_fhair.Hue = blur;
					}
					if(m_olegs != null)
					{
						olegs = m_olegs.Hue;
						m_olegs.Hue = blur;
					}
					if(m_twohanded != null)
					{
						twohanded = m_twohanded.Hue;
						m_twohanded.Hue = blur;
					}
					if(m_waist != null)
					{
						waist = m_waist.Hue;
						m_waist.Hue = blur;
					}
					if(m_hair != null)
					{
						hair = m_hair.Hue;
						m_hair.Hue = blur;
					}
					ma.Hue = blur;

				}
			
				Start();
			}
				
			protected override void OnTick()
			{
				ma.Hue = h;
				if(h_helm != null)
				{
					h_helm.Hue = helm;
				}
				if(h_neck != null)
				{
					h_neck.Hue = neck;
				}
				if(h_shirt != null)
				{
					h_shirt.Hue = shirt;
				}
				if(h_gloves != null)
				{
					h_gloves.Hue = gloves;
				}
				if(h_arms != null)
				{
					h_arms.Hue = arms;
				}
				if(h_pants != null)
				{
					h_pants.Hue = pants;
				}
				if(h_shoes != null)
				{
					h_shoes.Hue = shoes;
				}
				if(h_itorso != null)
				{
					h_itorso.Hue = itorso;
				}
				if(h_mtorso != null)
				{
					h_mtorso.Hue = mtorso;
				}
				if(h_otorso != null)
				{
					h_otorso.Hue = otorso;
				}
				if(h_cloak != null)
				{
					h_cloak.Hue = cloak;
				}
				if(h_fhair != null)
				{
					h_fhair.Hue = fhair;
				}
				if(h_olegs != null)
				{
					h_olegs.Hue = olegs;
				}
				if(h_twohanded != null)
				{
					h_twohanded.Hue = twohanded;
				}
				if(h_waist != null)
				{
					h_waist.Hue = waist;
				}
				if(h_hair != null)
				{
					h_hair.Hue = hair;
				}
			}
		}
	}
}
