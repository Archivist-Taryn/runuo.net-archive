using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class DazeMonsterSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Daze Monster", "Lor Norto Minrae",
				Reagent.BatWing
			);
		public override string Desc{ get{ return "Clouds the mind of a monster so that he takes no actions."; } } 
		public override string ReagentsDesc{ get{ return "One Batwing."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Second; } }
        public override int SpellNumber { get { return 340; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Enchantment; } }

		public DazeMonsterSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return true; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( m.Frozen || m.Paralyzed || (m.Spell != null && m.Spell.IsCasting ) )
			{
				Caster.SendLocalizedMessage( 1061923 ); // The target is already frozen.
			}
			else if ( ( m.Body == 0x190 ) || (m.Body == 0x191) )
			{
				Caster.SendMessage( "You cannot cast on this." );
			}
			else if ( CheckHSequence( m ) )
			{
				double duration;
				if (Caster.Int > m.Int)
				{
					duration = Utility.Random(4, 6);
				}
				else
				{
					duration = Utility.Random(2, 4);
				}
				Mobile source = Caster;
				SpellHelper.Turn( source, m );
				SpellHelper.CheckReflect( (int)this.SpellLevel, ref source, ref m );
				m.Paralyze( TimeSpan.FromSeconds( duration ) );
				m.PlaySound( 0x204 );
				m.FixedEffect( 0x376A, 6, 1 );

			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private DazeMonsterSpell m_Owner;

			public InternalTarget( DazeMonsterSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
