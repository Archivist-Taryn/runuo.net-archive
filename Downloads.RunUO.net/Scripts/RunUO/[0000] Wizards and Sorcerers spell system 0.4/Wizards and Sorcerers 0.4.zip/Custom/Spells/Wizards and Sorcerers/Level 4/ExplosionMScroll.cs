using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ExplosionMScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public ExplosionMScroll() : this( 1 )
		{
		}

		[Constructable]
		public ExplosionMScroll( int amount ) : base( 304, 0x1F2E, amount )
		{
			Name = "Explosion";
		}
		
		public ExplosionMScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
