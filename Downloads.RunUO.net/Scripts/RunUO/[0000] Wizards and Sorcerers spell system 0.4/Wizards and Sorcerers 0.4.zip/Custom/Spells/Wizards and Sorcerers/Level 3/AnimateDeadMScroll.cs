using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class AnimateDeadMScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public AnimateDeadMScroll() : this( 1 )
		{
		}

		[Constructable]
		public AnimateDeadMScroll( int amount ) : base( 311, 0x1F2E, amount )
		{
			Name = "Animate Dead";
		}
		
		public AnimateDeadMScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}
