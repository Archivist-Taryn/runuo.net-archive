using System;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;
using Server.Gumps;

namespace Server.Spells.Magician
{
	public class FamiliarSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Summon Familiar", "Culloth Similt",
				Reagent.BloodSpawn
			);

		public override string Desc{ get{ return "Summons your familiar."; } } 
		public override string ReagentsDesc{ get{ return "One BloodSpawn."; } }
		public override double CastDelay{ get{ return 10.0; } }
		public override double RequiredSkill{ get{ return 25.0; } }
		public override int RequiredMana{ get{ return 25; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Universal; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 326; } }

		public FamiliarSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				MakeFamiliar();
			}

			FinishSequence();
		}
		
		public void MakeFamiliar()
		{
			PolyGlotMobile dark = Caster as PolyGlotMobile;
			if ((dark.FamiliarType == FamiliarType.None))
			{
				Caster.SendGump( new ChooseFamiliarGump( Caster, FamiliarType.None ));
			}
			else if (dark.Familiar == null)
			{
				Create(dark.FamiliarType);
			}
			else if (dark.Familiar.Deleted)
			{
				Create(dark.FamiliarType);
			}
			else
			{
				dark.SendMessage("Did you lose track of your familiar?");
				Familiar fam = dark.Familiar as Familiar;
				
				dark.Familiar.MoveToWorld( dark.Location, dark.Map );
				fam.ControlMaster = Caster;
				fam.IsBonded = true;
				fam.ControlTarget = Caster;
				fam.ControlOrder = OrderType.Follow;
			}
		}
		
		public void Create(FamiliarType type)
		{
					switch ( (int)type ) 
					{ 

						case 1:
						{
							Familiar creature = new FamiliarBat(Caster);
							break;
						}
						
						case 2: 
						{ 
							Familiar creature = new FamiliarHawk(Caster);
							break; 
						} 

						case 3: 
						{ 
							Familiar creature = new FamiliarRat(Caster);
							break; 
						} 

						case 4: 
						{ 
							Familiar creature = new FamiliarCat(Caster);
							break; 
						} 

						case 5: 
						{ 
							Familiar creature = new FamiliarRaven(Caster);
							break; 
						}
						
						case 6:
						{
							Familiar creature = new FamiliarSnake(Caster);
							break;
						}
						
						case 7:
						{
							Familiar creature = new FamiliarToad(Caster);
							break;
						}

						default:
							break;
					}
		}
	}
	
	public enum FamiliarType
	{
		None, Bat, Hawk, Rat, Cat, Raven, Snake, Toad
	}
	
	
	public class ChooseFamiliarGump : Gump 
	{
		private Mobile m_From; 
		private FamiliarType m_Page; 

		private const int White = 0xFFFFFF; 
		private const int Blue = 0x8080FF; 

		public void AddPageButton( int x, int y, int buttonID, string text, FamiliarType page, params FamiliarType[] subpage ) 
		{ 
			bool isSelected = ( m_Page == page ); 

			for ( int i = 0 ; !isSelected && i < subpage.Length; ++i ) 
				isSelected = ( m_Page == subpage[i] ); 

			AddButton( x, y - 1, isSelected ? 4006 : 4005, 4007, buttonID, GumpButtonType.Reply, 0 ); 
			AddHtml( x + 35, y, 200, 20, Color( text, isSelected ? Blue : White ), false, false ); 
		} 

		public void AddButtonLabeled( int x, int y, int buttonID, string text ) 
		{ 
			AddButton( x, y - 1, 4005, 4007, buttonID, GumpButtonType.Reply, 0 ); 
			AddHtml( x + 35, y, 240, 20, Color( text, White ), false, false ); 
		} 

		public int GetButtonID( int type, int index ) 
		{ 
			return 1 + (index * 30) + type; 
		} 

		public string Color( string text, int color ) 
		{ 
			return String.Format( "<BASEFONT COLOR=#{0:X6}>{1}</BASEFONT>", color, text ); 
		} 
        
		public ChooseFamiliarGump ( Mobile from, FamiliarType page) : base ( 40, 45 ) 
		{ 
			from.CloseGump( typeof( ChooseFamiliarGump ) ); 
          
			PlayerMobile player = (PlayerMobile) from;
			m_From = from; 
			m_Page = page; 
		
			Closable = true;
			Dragable = true;
			

			AddPage( 0 ); 
			AddBackground( 0, 0, 531, 360, 5054 ); 
			AddAlphaRegion( 10, 10, 511, 340 ); 

			AddImageTiled( 11, 37, 149, 19, 0x52 ); 
			AddImageTiled( 11, 37, 148, 18, 0xBBC ); 
			AddLabel( 35, 37, 0, "Choose Your Familiar" ); // Choose your class 

			AddImageTiled( 11, 11, 509, 21, 0x52 ); 
			AddImageTiled( 11, 11, 507, 19, 0xBBC ); 
			AddLabel( 165, 11, 0, "Familiar Selection Menu" ); // Class selection menu 
          
			AddImageTiled( 10, 32, 511, 5, 5058 ); 
			AddImageTiled( 10, 287, 511, 5, 5058 ); 
			AddImageTiled( 160, 37, 5, 250, 5058 ); 

			
			AddPageButton( 40, 75, GetButtonID( 0, 0 ), "Initial Page", FamiliarType.None ); //Initial Page
			AddPageButton( 40, 110, GetButtonID( 0, 1 ), "Bat", FamiliarType.Bat); 
			AddPageButton( 40, 135, GetButtonID( 0, 2 ), "Hawk", FamiliarType.Hawk); 
			AddPageButton( 40, 160, GetButtonID( 0, 3 ), "Rat", FamiliarType.Rat); 
			AddPageButton( 40, 185, GetButtonID( 0, 4 ), "Cat", FamiliarType.Cat);
			AddPageButton( 40, 210, GetButtonID( 0, 5 ), "Raven", FamiliarType.Raven); 
			AddPageButton( 40, 235, GetButtonID( 0, 6 ), "Snake", FamiliarType.Snake);
			AddPageButton( 40, 260, GetButtonID( 0, 7 ), "Toad", FamiliarType.Toad);
				

			switch ( page ) 
			{ 
				case FamiliarType.None: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("Choose your familiar, mage.  Each kind of familiar has different strengths, weaknesses, and skills that can aid you.  Once you choose, you can never choose another kind.  Be wise in your decision."), true, false ); 
					break; 
				} 

				case FamiliarType.Bat: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("<center>* Bat *</center>"), true, true ); 
					AddPageButton( 50, 317, GetButtonID( 1, 0 ), "Back To Main Menu", FamiliarType.None); // Back to Main Menu 
					AddButtonLabeled( 300, 317, GetButtonID( 1, 1 ), "Choose the Bat" ); 
					break; 
				} 

				case FamiliarType.Hawk: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("<center>* Hawk *</center>"), true, true );
					AddPageButton( 50, 317, GetButtonID( 1, 0 ), "Back To Main Menu", FamiliarType.None);
					AddButtonLabeled( 300, 317, GetButtonID( 1, 2 ), "Choose the Hawk" ); 
					break; 
				} 

				case FamiliarType.Rat: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("<center>* Rat *</center>"), true, true );
					AddPageButton( 50, 317, GetButtonID( 1, 0 ), "Back To The Main Menu", FamiliarType.None);
					AddButtonLabeled( 300, 317, GetButtonID( 1, 3 ), "Choose the Rat" ); 
					break; 
				} 

				case FamiliarType.Cat: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("<center>* Cat *</center>"), true, true );
					AddPageButton( 50, 317, GetButtonID( 1, 0 ), "Back To The Main Menu", FamiliarType.None);
					AddButtonLabeled( 300, 317, GetButtonID( 1, 4 ), "Choose the Cat" ); 
					break; 
				}
			
				case FamiliarType.Raven: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("<center>* Raven *</center>"), true, true );
					AddPageButton( 50, 317, GetButtonID( 1, 0 ), "Back To The Main Menu", FamiliarType.None);
					AddButtonLabeled( 300, 317, GetButtonID( 1, 5 ), "Choose the Raven" ); 
					break; 
				}
				
				
				case FamiliarType.Snake: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("<center>* Snake *</center>"), true, true );
					AddPageButton( 50, 317, GetButtonID( 1, 0 ), "Back To The Main Menu", FamiliarType.None);
					AddButtonLabeled( 300, 317, GetButtonID( 1, 6 ), "Choose the Snake" ); 
					break; 
				}
				
				case FamiliarType.Toad: 
				{ 
					AddHtml( 172, 40, 337, 245, String.Format("<center>* Toad *</center>"), true, true );
					AddPageButton( 50, 317, GetButtonID( 1, 0 ), "Back To The Main Menu", FamiliarType.None);
					AddButtonLabeled( 300, 317, GetButtonID( 1, 7 ), "Choose the Toad" ); 
					break; 
				}
			} 

		} 

		public override void OnResponse( NetState sender, RelayInfo info ) 
		{ 
			int val = info.ButtonID - 1; 

			if ( val < 0 ) 
				return; 

			Mobile from = m_From;
			
			PolyGlotMobile dark = from as PolyGlotMobile;

			int type = val % 30; 
			int index = val / 30; 

			switch ( type ) 
			{ 
				case 0: 
				{ 
					FamiliarType page; 

					switch ( index ) 
					{ 
						case 0: page = FamiliarType.None; break; 
						case 1: page = FamiliarType.Bat; break;
						case 2: page = FamiliarType.Hawk; break;
						case 3: page = FamiliarType.Rat; break;
						case 4: page = FamiliarType.Cat; break;
						case 5: page = FamiliarType.Raven; break; 
						case 6: page = FamiliarType.Snake; break;
						case 7: page = FamiliarType.Toad; break;
						
						default: return; 
					} 

					from.SendGump( new ChooseFamiliarGump( from, page) ); 
					break; 
				} 

				case 1: 
				{ 
					switch ( index ) 
					{ 
						case 0: 
						{ 
							from.SendGump( new ChooseFamiliarGump( from, FamiliarType.None) ); 
							break; 
						}

						case 1:
						{
							Familiar creature = new FamiliarBat(from);
							break;
						}
						
						case 2: 
						{ 
							Familiar creature = new FamiliarHawk(from);
							break; 
						} 

						case 3: 
						{ 
							Familiar creature = new FamiliarRat(from);
							break; 
						} 

						case 4: 
						{ 
							Familiar creature = new FamiliarCat(from);
							break; 
						} 

						case 5: 
						{ 
							Familiar creature = new FamiliarRaven(from);
							break; 
						}
						
						case 6:
						{
							Familiar creature = new FamiliarSnake(from);
							break;
						}
						
						case 7:
						{
							Familiar creature = new FamiliarToad(from);
							break;
						}

						default:
							break;

					}
					break;
				}

			}

		}
	}
}
