using System;
using Server;
using Server.Gumps;
using Server.Mobiles;
using Server.Spells;
using Server.Network;

namespace Server.Gumps
{
	public class EndureElementsGump : Gump
	{
		private Mobile caster, M;

		public EndureElementsGump(Mobile Caster, Mobile m)
			: base( 0, 0 )
		{
			caster = Caster;
			M = m;
			Caster.CloseGump( typeof( EndureElementsGump ) );
			this.Closable=false;
			this.Disposable=false;
			this.Dragable=false;
			this.Resizable=false;
			this.AddPage(0);
			this.AddBackground(136, 103, 386, 198, 2620);
			this.AddLabel(206, 171, 43, @"Fire");
			this.AddLabel(207, 208, 6, @"Cold");
			this.AddLabel(204, 253, 52, @"Energy");
			this.AddLabel(246, 129, 1154, @"Endure Elements");
			string name = Convert.ToString( m.Name );
			this.AddHtml( 276, 175, 148, 95, @"Choose an element which you would like " + name + " to endure.", (bool)true, (bool)false);
			this.AddButton(174, 169, 210, 211, 1, GumpButtonType.Reply, 0);
			this.AddButton(174, 211, 210, 211, 2, GumpButtonType.Reply, 0);
			this.AddButton(173, 253, 210, 211, 3, GumpButtonType.Reply, 0);
			this.AddImage(436, 140, 14146);

		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{

			switch( info.ButtonID )
			{
				case 1:
					if ( !caster.CanSee( M ) )
					{
						caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
					}
					else
					{
						TimeSpan span = TimeSpan.FromSeconds( 30 );
						PolyGlotMobile dark = M as PolyGlotMobile;
						//CustomResistanceMod mod = new CustomResistanceMod( dark, ResistType.Fire, "MagicBuff", 25, span, false);
						//dark.AddResistMod( mod );
						M.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
						M.PlaySound( 0x1EE );
					}
					break;
				case 2:
					if ( !caster.CanSee( M ) )
					{
						caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
					}
					else
					{
						TimeSpan span = TimeSpan.FromSeconds( 30 );
						PolyGlotMobile dark = M as PolyGlotMobile;
						//CustomResistanceMod mod = new CustomResistanceMod( dark, ResistType.Cold, "MagicBuff", 25, span, false);
						//dark.AddResistMod( mod );
						M.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
						M.PlaySound( 0x1EE );
					}
					break;
				case 3:
					if ( !caster.CanSee( M ) )
					{
						caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
					}
					else
					{
						TimeSpan span = TimeSpan.FromSeconds( 30 );
						PolyGlotMobile dark = M as PolyGlotMobile;
						//CustomResistanceMod mod = new CustomResistanceMod( dark, ResistType.Energy, "MagicBuff", 25, span, false);
						//dark.AddResistMod( mod );
						M.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
						M.PlaySound( 0x1EE );
					}
					break;
			}
		}

	}
}