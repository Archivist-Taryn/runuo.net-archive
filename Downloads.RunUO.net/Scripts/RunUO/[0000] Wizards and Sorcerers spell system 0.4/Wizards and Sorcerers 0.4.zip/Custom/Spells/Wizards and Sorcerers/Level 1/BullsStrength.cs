using System;
using Server.Targeting;
using Server.Network;

namespace Server.Spells.Magician
{
	public class BullsStrengthSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Bull's Strength", "Lor Vinris",
				Reagent.Bloodmoss
			);
			
		public override string Desc{ get{ return "The spell grants a bonus to strength."; } } 
		public override string ReagentsDesc{ get{ return "One Bloodmoss."; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 15.0; } }
		public override int RequiredMana{ get{ return 10; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.First; } }
        public override int SpellNumber { get { return 335; } }
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Transmutation; } }

		public BullsStrengthSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckBSequence( m ) )
			{
				SpellHelper.Turn( Caster, m );

				SpellHelper.AddStatBonus( Caster, m, StatType.Str );

				m.FixedParticles( 0x375A, 10, 15, 5017, EffectLayer.Waist );
				m.PlaySound( 0x1EE );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private BullsStrengthSpell m_Owner;

			public InternalTarget( BullsStrengthSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			} 

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
