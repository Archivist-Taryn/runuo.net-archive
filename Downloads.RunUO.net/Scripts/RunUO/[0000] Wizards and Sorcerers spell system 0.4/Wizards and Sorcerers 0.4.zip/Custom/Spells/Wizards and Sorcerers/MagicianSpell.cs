using System;
using Server;
using Server.Mobiles;
using Server.Spells;
using Server.Items;
using Server.Network;
using Server.Targeting;

namespace Server.Spells.Magician
{
	
	public enum SpellSchool
	{
		Universal, Abjuration, Conjuration, Divination, Enchantment, Evocation, Illusion, Necromancy, Transmutation
	}
	
	public abstract class MagicianSpell : Spell
	{
		public abstract double CastDelay{ get; }
		public abstract double RequiredSkill{ get; }
		public abstract int RequiredMana{ get; }
        public abstract int SpellNumber { get; }
        public abstract SpellCircle SpellLevel { get; }

        public virtual string Desc { get { return "Testing automatic spell descriptions"; } }
        public virtual string ReagentsDesc { get { return "Testing reagent amount descriptions"; } }
        public virtual SpellSchool SpellSchool { get { return SpellSchool.Universal; } }
		
		public override SkillName CastSkill{ get{ return SkillName.Magery; } }
		public override SkillName DamageSkill{ get{ return SkillName.Magery; } }
        public override TimeSpan CastDelayBase { get { return TimeSpan.FromSeconds(CastDelay); } }

        public override bool ClearHandsOnCast
        {
            get
            {
                if (this.Scroll is MagicianSpellScroll)
                    return true;
                else
                    return false;
            } 
        }

		public MagicianSpell( Mobile caster, Item scroll, SpellInfo info ) : base( caster, scroll, info )
		{
		}
		
		public override void GetCastSkills( out double min, out double max )
		{
			min = RequiredSkill;
			max = RequiredSkill + 20.0;
		}
		
		public override int GetMana()
		{
			PolyGlotMobile MageGuy = this.Caster as PolyGlotMobile;
			if ((MageGuy.Class == ClassType.Wizard)||(this.Scroll is BaseWand))
				return 0;
			else
				return RequiredMana;
		}
		
		public bool IsOppositeSchool()
		{
			if(this.SpellSchool == SpellSchool.Universal)
				return false;

            PolyGlotMobile MageGuy = this.Caster as PolyGlotMobile;
			SpellSchool[] schools = MageGuy.SpellsKnown.OppositeSchool();

            if (schools == null)
                return false;

			for(int i = 0; i < schools.Length; i++)
			{
				if (this.SpellSchool == schools[i])
					return true;
			}
			return false;
		}
		
		public override bool CheckCast()
		{
            if (!(this.Caster is PolyGlotMobile)) // Disabled npcs
                return false;

            PolyGlotMobile MageGuy = this.Caster as PolyGlotMobile;

			if(IsOppositeSchool())
			{
				this.Caster.SendMessage("You cannot cast this due to your specialist restrictions.");
				return false;
			}
			else if ( !(this.Scroll is BaseWand) && !(this.Scroll is SpellScroll) && (MageGuy.Class == ClassType.Wizard) )
			{
                
				bool crazy = MageGuy.SpellsKnown.CheckForPreparedSpell( MageGuy, this.SpellNumber );
                if (crazy)
                {
                    return true;
                }
                else
                    return false;
			}
			return true;
		}

        public override bool CheckSequence()
        {
            if (this.Caster.Deleted || !this.Caster.Alive || this.Caster.Spell != this || this.State != SpellState.Sequencing)
            {
                DoFizzle();
            }
            else if (this.Scroll != null && !(this.Scroll is Runebook) && (this.Scroll.Amount <= 0 || this.Scroll.Deleted || this.Scroll.RootParent != this.Caster || (this.Scroll is BaseWand && (((BaseWand)this.Scroll).Charges <= 0 || this.Scroll.Parent != this.Caster))))
            {
                DoFizzle();
            }
            else if ( this.Caster.Mana < GetMana() )
            {
                this.Caster.LocalOverheadMessage(MessageType.Regular, 0x22, 502625); // Insufficient mana for this spell.
            }
            else if (Core.AOS && (this.Caster.Frozen || this.Caster.Paralyzed))
            {
                this.Caster.SendLocalizedMessage(502646); // You cannot cast a spell while frozen.
                DoFizzle();
            }
            else if (this.Caster is PlayerMobile && ((PlayerMobile)this.Caster).PeacedUntil > DateTime.Now)
            {
                this.Caster.SendLocalizedMessage(1072060); // You cannot cast a spell while calmed.
                DoFizzle();
            }
            else if( !ConsumeReagents() )
            {
                this.Caster.LocalOverheadMessage(MessageType.Regular, 0x22, 502630); // More reagents are needed for this spell.
            }
            else if (CheckFizzle())
            {
                this.Caster.Mana -= GetMana();

                if ( ((PolyGlotMobile)this.Caster).Class == ClassType.Wizard && (this.Scroll == null) )
                    ((PolyGlotMobile)this.Caster).SpellsKnown.UseSpell( (PolyGlotMobile)this.Caster, this.SpellNumber);

                if (this.Scroll is SpellScroll)
                    this.Scroll.Consume();
                else if (this.Scroll is BaseWand)
                {
                    ((BaseWand)this.Scroll).ConsumeCharge(this.Caster);
                    this.Caster.RevealingAction();
                }

                if (this.Scroll is BaseWand)
                {
                    bool m = this.Scroll.Movable;

                    this.Scroll.Movable = false;

                    if (ClearHandsOnCast)
                        this.Caster.ClearHands();

                    this.Scroll.Movable = m;
                }
                else
                {
                    if (ClearHandsOnCast)
                        this.Caster.ClearHands();
                }

                return true;
            }
            else
            {
                DoFizzle();
            }

            return false;
        }

        public override bool CheckFizzle()
        {
            if (((PolyGlotMobile)this.Caster).Class == ClassType.Wizard)
                return true;

            return base.CheckFizzle();
        }

        public override bool ConsumeReagents()
        {
            if (this.Scroll != null || !this.Caster.Player)
                return true;

            if (((PolyGlotMobile)this.Caster).Class == ClassType.Wizard)
                return true;

            Container pack = this.Caster.Backpack;

            if (pack == null)
                return false;

            if (pack.ConsumeTotal(this.Info.Reagents, this.Info.Amounts) == -1)
                return true;

            return false;
        }

	}
}
