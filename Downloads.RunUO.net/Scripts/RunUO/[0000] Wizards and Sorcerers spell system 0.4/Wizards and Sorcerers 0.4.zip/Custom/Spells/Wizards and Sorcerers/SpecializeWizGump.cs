using System;
using Server;
using Server.Gumps;
using Server.Mobiles;
using Server.Network;
using System.Collections;
using Server.Spells.Magician;
using Server.Commands;

namespace Server.Gumps
{
	
	public class SpecializeWizGump : Gump
	{
		public static void Initialize()
		{
            CommandSystem.Register("specialize", AccessLevel.GameMaster, new CommandEventHandler(Specialize_OnCommand));
		}
		
		[Usage( "Specialize" )]
		[Description( "Lets a Wizard specialize in a school." )]
		private static void Specialize_OnCommand( CommandEventArgs e )
		{
			PolyGlotMobile dark = e.Mobile as PolyGlotMobile;
			
			//if ((dark.Class == ClassType.Wizard)&&(dark.Alive))
            if((dark.Alive)&&(dark.Class == ClassType.Wizard))
			{
                if (dark.SpellsKnown.Specialized == SpellSchool.Universal)
                {
                    dark.CloseGump(typeof(SpecializeWizGump));
                    dark.SendGump(new SpecializeWizGump(dark));
                }
                else
                    dark.SendMessage("You cannot specialize again!");
			}
			//else
			//	dark.SendMessage("That is not a command.");
		}
		
		
		public SpecializeWizGump(PolyGlotMobile dark)
			: base( 0, 0 )
		{
			this.Closable=false;
			this.Disposable=false;
			this.Dragable=false;
			this.Resizable=false;
			
			this.AddPage(1);
			this.AddBackground(141, 35, 304, 370, 9260);
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 21, 10441);
			this.AddImage(170, 58, 113);
			this.AddImage(384, 57, 113);
			this.AddImage(172, 96, 10464);
			this.AddImage(172, 149, 10464);
			this.AddImage(172, 202, 10464);
			this.AddImage(172, 254, 10464);
			this.AddImage(413, 19, 10441);
			this.AddImage(386, 96, 10464);
			this.AddImage(386, 149, 10464);
			this.AddImage(386, 202, 10464);
			this.AddImage(386, 254, 10464);
			this.AddImage(172, 307, 10464);
			this.AddImage(386, 306, 10464);
			this.AddLabel(216, 45, 5, @"Wizard School Specialization");
			this.AddButton(230, 80, 22151, 22150, 0, GumpButtonType.Page, 2);
			this.AddButton(230, 110, 22151, 22150, 0, GumpButtonType.Page, 3);
			this.AddButton(230, 140, 22151, 22150, 0, GumpButtonType.Page, 4);
			this.AddButton(230, 170, 22151, 22150, 0, GumpButtonType.Page, 5);
			this.AddButton(230, 200, 22151, 22150, 0, GumpButtonType.Page, 6);
			this.AddButton(230, 230, 22151, 22150, 0, GumpButtonType.Page, 7);
			this.AddButton(230, 260, 22151, 22150, 0, GumpButtonType.Page, 8);
			this.AddButton(230, 290, 22151, 22150, 0, GumpButtonType.Page, 9);
			this.AddButton(230, 320, 22151, 22150, 0, GumpButtonType.Reply, 0);
			this.AddLabel(252, 78, 6, @"Abjuration");
			this.AddLabel(252, 108, 7, @"Conjuration");
			this.AddLabel(252, 138, 9, @"Divination");
			this.AddLabel(252, 168, 11, @"Enchantment");
			this.AddLabel(252, 198, 13, @"Evocation");
			this.AddLabel(252, 228, 16, @"Illusion");
			this.AddLabel(252, 258, 19, @"Necromancy");
			this.AddLabel(252, 288, 26, @"Trasmutation");
			this.AddLabel(252, 318, 0, @"No Specialization");
			
			this.AddPage(2);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Abjuration");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Abjuration spells ward, protect, dispel, or are generally defensive for the wizard.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 1, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Abjuration?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
			
			this.AddPage(3);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Conjuration");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Conjuration spells summon entities from other planes, create new temporary objects from thin air, or create passageways to other far away places.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 2, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Conjuration?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
			
			this.AddPage(4);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Divination");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Divination spells provide information, knowledge, or awareness to the wizard.  This school personifies ultimate knowledge.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 3, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Divination?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
			
			this.AddPage(5);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Enchantment");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Enchantment spells affect the minds or behavior of others, either through subtle or overt means.  The intelligence of the wizard consumes the target.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 4, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Enchantment?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
			
			this.AddPage(6);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Evocation");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Evocation spells manipulate energy, and pure magical force.  This is the most offensive-based school of all.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 5, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Evocation?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
			
			this.AddPage(7);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Illusion");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Illusion spells affect the senses of others, by creating false sensory input in the minds of others, or by creating semi-real objects created from shadows.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 6, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Illusion?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
			
			this.AddPage(8);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Necromancy");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Necromancy spells manipulate life force, the flesh of organic beings, energies from the negative plane, and all things to do with the undead.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 7, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Necromancy?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
			
			this.AddPage(9);
			this.AddBackground(141, 35, 304, 394, 9260);
			this.AddImage(346, 46, 113);
			this.AddImage(194, 46, 113);
			this.AddLabel(255, 55, 6, @"Transmutation");
			this.AddImage(91, 19, 10440);
			this.AddImage(413, 19, 10441);
			this.AddHtml( 195, 90, 215, 100, "Transmutation spells alter or enhance the properties of objects, creatures, or physical laws of reality.  Unlike illusions, these effects are real, if only temporary.", false, false );
			this.AddButton(176, 82+(26*10), 22151, 22150, 8, GumpButtonType.Reply, 0);
			this.AddButton(176, 82+(26*11), 22151, 22150, 0, GumpButtonType.Page, 1);
			this.AddLabel(196, 81+(26*10), 0, "Choose Transmutation?");
			this.AddLabel(196, 81+(26*11), 0, "Choose a different specialization");
		}
		
			
		public override void OnResponse( NetState state, RelayInfo info )
		{
			PolyGlotMobile dark = state.Mobile as PolyGlotMobile;

			switch ( info.ButtonID )
			{
				// Level One Responses:
				case 1:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Abjuration;
						break;
					}
					
				case 2:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Conjuration;
						break;
					}
					
				case 3:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Divination;
						break;
					}
					
				case 4:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Enchantment;
						break;
					}
					
				case 5:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Evocation;
						break;
					}
					
				case 6:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Illusion;
						break;
					}
					
				case 7:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Necromancy;
						break;
					}
					
				case 8:
					{
						dark.SpellsKnown.Specialized = SpellSchool.Transmutation;
						break;
					}
                default:
                    {
                        dark.SpellsKnown.Specialized = SpellSchool.Universal;
                        break;
                    }
			}
			
		}
	}
}
