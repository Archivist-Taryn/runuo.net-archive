using System;
using Server.Targeting;
using Server.Network;

namespace Server.Spells.Magician
{
	public class DivineFavorSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Divine Favor", "Mit Sti Masse",
				Reagent.Bloodmoss,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss,
				Reagent.PigIron
			);
		
		public override string Desc{ get{ return "Grants you an increase in all stats temporarily."; } }
		public override string ReagentsDesc{ get{ return "Four Bloodmoss, one PigIron "; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fifth; } }
        public override int SpellNumber { get { return 366; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 50.0; } }
		public override int RequiredMana{ get{ return 50; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Divination; } }

		public DivineFavorSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckBSequence( m ) )
			{
				SpellHelper.Turn( Caster, m );

				SpellHelper.AddStatBonus( Caster, m, StatType.Str ); SpellHelper.DisableSkillCheck = true;
				SpellHelper.AddStatBonus( Caster, m, StatType.Dex );
				SpellHelper.AddStatBonus( Caster, m, StatType.Int ); SpellHelper.DisableSkillCheck = false;

				m.FixedParticles( 0x373A, 10, 15, 5018, EffectLayer.Waist );
				m.PlaySound( 0x1EA );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private DivineFavorSpell m_Owner;

			public InternalTarget( DivineFavorSpell owner ) : base( 12, false, TargetFlags.Beneficial )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
