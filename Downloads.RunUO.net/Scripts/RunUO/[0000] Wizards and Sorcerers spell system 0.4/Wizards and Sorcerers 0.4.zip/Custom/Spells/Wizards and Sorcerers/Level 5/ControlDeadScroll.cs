using System;
using Server;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ControlDeadScroll : MagicianSpellScroll
	{
		
		[Constructable]
		public ControlDeadScroll() : this( 1 )
		{
		}

		[Constructable]
		public ControlDeadScroll( int amount ) : base( 358, 0x1F2E, amount )
		{
			Name = "Control Dead";
		}
		
		public ControlDeadScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

	}
}

