using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Items;

namespace Server.Spells.Magician
{
	public class TongueTiedSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Tongue Tied", "Inmit Litre",
				Reagent.NoxCrystal,
				Reagent.NoxCrystal,
				Reagent.BatWing,
				Reagent.BatWing,
				Reagent.BlackPearl
			);
		public override string Desc{ get{ return "Your target forgets the right words."; } }
		public override string ReagentsDesc{ get{ return "Two NoxCrystals, Two BatWings, one BlackPearl "; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fifth; } }
        public override int SpellNumber { get { return 325; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 65.0; } }
		public override int RequiredMana{ get{ return 35; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Enchantment; } }

		public TongueTiedSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				if (m is PolyGlotMobile )
				{
					PolyGlotMobile pm = m as PolyGlotMobile;
					if( !pm.TTied )
					{
						Point3D loc = pm.Location;
						Mobile source = Caster;
						SpellHelper.Turn( source, m );
						SpellHelper.CheckReflect( (int)this.SpellLevel, ref source, ref m );
						
						Caster.SendMessage("Your target looks confused for a moment and slightly less intelligent.");
						pm.SendMessage("A magical spell has caused you the loss of the ability to speak languages.");
						
						Effects.SendLocationParticles( EffectItem.Create( new Point3D( loc.X + 1, loc.Y, loc.Z ), source.Map, EffectItem.DefaultDuration ), 0x376A, 9, 10, 9502 );
						Effects.SendLocationParticles( EffectItem.Create( new Point3D( loc.X, loc.Y - 1, loc.Z ), source.Map, EffectItem.DefaultDuration ), 0x376A, 9, 10, 9502 );
						Effects.SendLocationParticles( EffectItem.Create( new Point3D( loc.X - 1, loc.Y, loc.Z ), source.Map, EffectItem.DefaultDuration ), 0x376A, 9, 10, 9502 );
						Effects.SendLocationParticles( EffectItem.Create( new Point3D( loc.X, loc.Y + 1, loc.Z ), source.Map, EffectItem.DefaultDuration ), 0x376A, 9, 10, 9502 );
						Effects.SendLocationParticles( EffectItem.Create( new Point3D( loc.X, loc.Y,     loc.Z ), source.Map, EffectItem.DefaultDuration ), 0, 0, 0, 5014 );
						Effects.PlaySound( loc, m.Map, 0x1EF );
						new TongueTiedTimer(m, TimeSpan.FromMinutes(5));
					}
					else
					{
						Caster.SendMessage("This being's tongue has already been tied.");
					}
				}
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private TongueTiedSpell m_Owner;

			public InternalTarget( TongueTiedSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
				{
					m_Owner.Target( (Mobile)o );
				}
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
		private class TongueTiedTimer : Timer
		{
			private int m_int;
			private Mobile m_target;
			private bool elven;
			private bool drow;
			private bool orcish;
			private bool undead;
			private SpeechType clanguage;
			public TongueTiedTimer( Mobile m, TimeSpan duration ) : base( duration )
			{
				PolyGlotMobile dm = m as PolyGlotMobile;
				if(!dm.TTied)
				{
					if (m is PlayerMobile )
					{ 
						PlayerMobile pm = m as PlayerMobile;
						pm.TTied = true;
						m_target = m;
						clanguage = pm.LanguageSpeaking;
						elven = pm.KnowElven;
						drow = pm.KnowDrow;
						orcish = pm.KnowOrc;
						undead = pm.KnowUndead;
						pm.LanguageSpeaking = SpeechType.Jibberish;
					}
					else
					{
						m_int = m.Int;
						m.Int -= 40;
					}
					Start();
				}

			}
				
			protected override void OnTick()
			{
				if (m_target is PolyGlotMobile)
				{
					PolyGlotMobile dm = m_target as PolyGlotMobile;
					if(dm.TTied)
					{
						if(m_target is PlayerMobile)
						{
							PlayerMobile pm = m_target as PlayerMobile;
							pm.TTied = false;
							pm.KnowElven = elven;
							pm.KnowDrow = drow;
							pm.KnowOrc = orcish;
							pm.KnowUndead = undead;
							pm.LanguageSpeaking = clanguage;
						}
						else
						{
							m_target.Int = m_int;
						}
					}
				}
			}
		}
	}
}
