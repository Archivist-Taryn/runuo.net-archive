using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Items;

namespace Server.Spells.Magician
{
	public class ChangeStaffSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Change Staff", "Tris Mistre",
				Reagent.PigIron,
				Reagent.PigIron,
				Reagent.PigIron,
				Reagent.Bloodmoss,
				Reagent.Bloodmoss
			);
		
		public override string Desc{ get{ return "An equipped prepared staff transforms into a living being."; } }
		public override string ReagentsDesc{ get{ return "Three PigIron, Two Bloodmoss."; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Fifth; } }
        public override int SpellNumber { get { return 336; } }
		public override double CastDelay{ get{ return 2.0; } }
		public override double RequiredSkill{ get{ return 10.0; } }
		public override int RequiredMana{ get{ return 10; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Transmutation; } }

		public ChangeStaffSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}
		
		public override void OnCast()
		{
			Item weapon = Caster.FindItemOnLayer( Layer.OneHanded );

			if ( weapon == null || !weapon.Movable )
				weapon = Caster.FindItemOnLayer( Layer.TwoHanded );
			
			if (weapon is BaseTransmuteStaff)
			{
				BaseTransmuteStaff staff = weapon as BaseTransmuteStaff;
				staff.OnTransmute( Caster );
			}
			else
				Caster.SendMessage("You must be equipping a prepared staff.");
			
			
			
			FinishSequence();
		}

	}
}
