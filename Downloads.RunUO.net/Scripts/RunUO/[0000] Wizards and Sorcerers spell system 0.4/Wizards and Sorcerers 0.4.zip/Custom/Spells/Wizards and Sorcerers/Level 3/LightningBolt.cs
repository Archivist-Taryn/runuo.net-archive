using System;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;

namespace Server.Spells.Magician
{
	public class LightningBoltSpell : MagicianSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Lightning Bolt", "Shrik Simit",
				Reagent.MandrakeRoot,
				Reagent.MandrakeRoot,
				Reagent.GraveDust
			);
		public override string Desc{ get{ return "You releas a powerful stroke of electrical energy at a target."; } }
		public override string ReagentsDesc{ get{ return "Two MandrakeRoot, GraveDust"; } }
        public override SpellCircle SpellLevel { get { return SpellCircle.Third; } }
        public override int SpellNumber { get { return 302; } }
		public override double CastDelay{ get{ return 7.0; } }
		public override double RequiredSkill{ get{ return 55.0; } }
		public override int RequiredMana{ get{ return 25; } }
		
		public override SpellSchool SpellSchool{ get{ return SpellSchool.Evocation; } }

		public LightningBoltSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			Caster.Target = new InternalTarget( this );
		}

		public override bool DelayedDamage{ get{ return false; } }

		public void Target( Mobile m )
		{
			if ( !Caster.CanSee( m ) )
			{
				Caster.SendLocalizedMessage( 500237 ); // Target can not be seen.
			}
			else if ( CheckHSequence( m ) )
			{
				SpellHelper.Turn( Caster, m );

				SpellHelper.CheckReflect( (int)this.SpellLevel, Caster, ref m );

				int damage = Utility.Random( 12, 9 );

				m.BoltEffect( 0 );

				Caster.DoHarmful( m );
				//damage = AbsorbDamage(m, ResistType.Energy, damage);
				m.Damage( damage );
			}

			FinishSequence();
		}

		private class InternalTarget : Target
		{
			private LightningBoltSpell m_Owner;

			public InternalTarget( LightningBoltSpell owner ) : base( 12, false, TargetFlags.Harmful )
			{
				m_Owner = owner;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				if ( o is Mobile )
					m_Owner.Target( (Mobile)o );
			}

			protected override void OnTargetFinish( Mobile from )
			{
				m_Owner.FinishSequence();
			}
		}
	}
}
