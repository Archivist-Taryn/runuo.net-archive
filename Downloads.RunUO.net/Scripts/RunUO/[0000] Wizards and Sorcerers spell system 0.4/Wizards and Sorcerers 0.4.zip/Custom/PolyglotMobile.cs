using System;
using System.IO;
using System.Collections;
using Server;
using Server.Misc;
using Server.Items;
using Server.Custom;
using Server.Spells;
using Server.Spells.Magician;
using Server.Network;

namespace Server.Mobiles
{

    public enum SpeechType
    {
        Common, Elven, Orc, Drow, Undead, Jibberish, Druidic, Umbravox, Abyssal
    }

    public enum ClassType
    {
        None, Fighter, Cleric, Wizard, Sorcerer, Druid, Monk, Ranger, Thief, Assassin, Squire, Barbarian, Bard, Pirate, Scout, Beastmaster, Archer, Knight, Paladin, Cavalier, Rogue, DrunkenMaster
    }

    public class PolyGlotMobile : Mobile
    {

        private SpeechType LangSpeak;
        private ClassType m_Class;

        private bool m_KnowDrow;
        private bool m_KnowElven;
        private bool m_KnowOrc;
        private bool m_KnowUndead;
        private bool m_KnowDruidic;
        private bool m_KnowUmbravox;
        private bool m_KnowAbyssal;

        private SpellHolder m_SpellsKnown;
        private string m_FamiliarName;
        private Mobile m_Familiar = null;
        private bool m_TTied; // For Tongue Tied spell
        private bool m_FreeMovement; // For Web

        private bool m_Sleeping;
        private bool m_GetsTired;
        private int m_TireHard;				//Hours spent before weariness
        private int m_TireLevel;			//Minutes spent since last nap
        private TireTimer m_TireTimer;
        private SleepTimer m_SleepTimer;

        public RunebookEntry[] TeleportEntries = new RunebookEntry[5];
        public RunebookEntry[] MoonGateEntries = new RunebookEntry[2];


        #region Custom Public Properties


        #region SleepEdit

        [CommandProperty(AccessLevel.GameMaster)]
        public bool Sleeping
        {
            get { return this.m_Sleeping; }
            set
            {
                if (value && !this.m_Sleeping)
                {
                    this.Sleep();
                }
                else if (!value && this.m_Sleeping)
                {
                    this.Wake(true);
                }
                else
                    this.m_Sleeping = value;
            }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool GetsTired
        {
            get { return this.m_GetsTired; }
            set
            {
                if (value && !this.m_GetsTired)
                {
                    this.m_GetsTired = value;
                    if (!this.m_Sleeping)
                    {
                        if (this.m_TireTimer == null)
                        {
                            this.m_TireTimer = new TireTimer(this);
                            this.m_TireTimer.Start();
                        }
                        else if (!this.m_TireTimer.Running)
                        {
                            this.m_TireTimer.Start();
                        }
                    }
                }
                else if (!value && this.m_GetsTired)
                {
                    this.m_GetsTired = value;
                    if (this.m_TireTimer.Running)
                    {
                        this.m_TireTimer.Stop();
                    }
                    if (this.m_TireTimer != null)
                    {
                        this.m_TireTimer = null;
                    }
                }
                else
                    this.m_GetsTired = value;
            }
        }

        [CommandProperty(AccessLevel.Counselor)]
        public int TireLevel
        {
            get { return this.m_TireLevel; }
            set { this.m_TireLevel = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public int TireHard
        {
            get { return this.m_TireHard; }
            set { this.m_TireHard = value; }
        }

        [CommandProperty(AccessLevel.Counselor)]
        public int Tired
        {
            get
            {
                if ((this.m_TireLevel) < (this.m_TireHard * 30))
                    return 0;
                else if ((this.m_TireLevel) < (this.m_TireHard * 60))
                    return 1;
                else if ((this.m_TireLevel) < (this.m_TireHard * 120))
                    return 2;
                else
                    return 3;
            }
        }

        public void Sleep(BaseSleepItem item)
        {
            if (!this.m_Sleeping)
            {
                this.m_Sleeping = true;
                this.Squelched = true;
                this.NameMod += "[Sleeping]";
                this.Animate(21, 7, 1, true, false, 0);
                this.m_TireTimer.Stop();
                this.m_TireTimer = null;
                this.m_SleepTimer = new SleepTimer(this, item, TimeSpan.FromSeconds(Convert.ToInt32((this.TireLevel * 10) / ((int)item.RefreshRate / 4)))); //UO Minutes
                this.m_SleepTimer.Start();
                this.Paralyze(TimeSpan.FromSeconds(Convert.ToInt32((this.TireLevel * 10) / ((int)item.RefreshRate / 4)))); //UO Minutes
            }
        }

        public void Sleep(TimeSpan duration)
        {
            if (!this.m_Sleeping)
            {
                this.m_Sleeping = true;
                this.Squelched = true;
                this.NameMod += "[Sleeping]";
                this.Animate(21, 7, 1, true, false, 0);
                //~ this.Animate(int action, int frameCount, int repeatCount, bool forward, bool repeat, int delay);
                this.m_TireTimer.Stop();
                this.m_TireTimer = null;
                this.m_SleepTimer = new SleepTimer(this, duration);
                this.m_SleepTimer.Start();
                this.Paralyze(duration);
            }
        }

        public void Sleep()
        {
            this.Sleep(TimeSpan.FromSeconds(this.TireLevel * 10)); //UO Minutes
        }

        public void Wake(bool forced)
        {
            if (this.m_Sleeping)
            {
                if (!forced)
                    this.m_TireLevel = 0;

                this.m_Sleeping = false;
                this.Squelched = false;
                this.NameMod.Replace("[Sleeping]", "");
                if (this.NameMod == "")
                    this.NameMod = null;

                //~ this.Animate(int action, int frameCount, int repeatCount, bool forward, bool repeat, int delay);
                this.Animate(21, 7, 1, false, false, 0);

                if (this.m_SleepTimer != null)
                {
                    if (this.m_SleepTimer.Running)
                    {
                        this.m_SleepTimer.Stop();
                    }
                    this.m_SleepTimer = null;
                }

                if (this.Paralyzed)
                    this.Paralyzed = false;

                if (this.m_GetsTired && this.NetState != null)
                {
                    if (this.m_TireTimer == null)
                    {
                        this.m_TireTimer = new TireTimer(this);
                        this.m_TireTimer.Start();
                    }
                    else if (!this.m_TireTimer.Running)
                        this.m_TireTimer.Start();
                }
            }
        }

        //Player closes eyes when asleep
        public override bool CanSee(Mobile inSight)
        {
            //Can be edited for a "Vigilant Rest" feat
            if (this.m_Sleeping && inSight != this && inSight.AccessLevel < AccessLevel.Counselor)
                return false;

            return base.CanSee(inSight);
        }

        private class TireTimer : Timer
        {
            private PolyGlotMobile m_Owner;
            private Random test;

            public TireTimer(PolyGlotMobile from)
                : base(TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1))
            {
                m_Owner = from;
                Priority = TimerPriority.FiveSeconds;
            }

            protected override void OnTick()
            {
                if (!this.m_Owner.GetsTired || this.m_Owner.NetState == null)
                {
                    this.Stop();
                }
                else
                {
                    this.m_Owner.TireLevel++;
                    if (this.m_Owner.Tired > 0)
                    {
                        test = new Random();
                        switch (this.m_Owner.Tired)
                        {
                            case 1:
                                {
                                    this.m_Owner.Stam -= 5;
                                    if (test.Next(0, 100) < 10)
                                        this.m_Owner.LocalOverheadMessage(MessageType.Regular, m_Owner.EmoteHue, true, "You feel uncomfortably weary.");
                                    base.Interval = TimeSpan.FromMinutes(1);
                                    break;
                                }
                            case 2:
                                {
                                    this.m_Owner.Stam -= 10;
                                    if (test.Next(0, 50) < 10)
                                    {
                                        this.m_Owner.LocalOverheadMessage(MessageType.Regular, m_Owner.EmoteHue, true, "Your eyes feel heavy and your vision blurs.");
                                        this.m_Owner.Emote("Yawns");
                                    }
                                    base.Interval = TimeSpan.FromSeconds(30);
                                    break;
                                }
                            case 3:
                                {
                                    this.m_Owner.Stam -= 20;
                                    this.m_Owner.Damage(5);
                                    if (test.Next(0, 20) < 10)
                                    {
                                        this.m_Owner.Emote("Falls to the ground from exhaustion");
                                        this.m_Owner.Sleep();
                                    }
                                    else
                                        this.m_Owner.LocalOverheadMessage(MessageType.Regular, m_Owner.EmoteHue, true, "You succeed in staying awake, valiantly fighting your exhaustion.");
                                    base.Interval = TimeSpan.FromSeconds(30);
                                    break;
                                }
                            default:
                                break;
                        }
                    }
                }
            }
        }

        private class SleepTimer : Timer
        {
            private PolyGlotMobile m_Owner;

            public SleepTimer(PolyGlotMobile source, BaseSleepItem item, TimeSpan duration)
                : base(duration)
            {
                if (item.Movable)
                    m_Owner.AddToBackpack(item);
                m_Owner = source;
                Priority = TimerPriority.OneSecond;
            }

            public SleepTimer(PolyGlotMobile source, TimeSpan duration)
                : base(duration)
            {
                m_Owner = source;
                Priority = TimerPriority.OneSecond;
            }

            protected override void OnTick()
            {
                m_Owner.Wake(false);
            }
        }

        #endregion

        #region Multilinguists
        [CommandProperty(AccessLevel.GameMaster)]
        public bool KnowDrow
        {
            get { return m_KnowDrow; }
            set { m_KnowDrow = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool KnowElven
        {
            get { return m_KnowElven; }
            set { m_KnowElven = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool KnowOrc
        {
            get { return m_KnowOrc; }
            set { m_KnowOrc = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool KnowUndead
        {
            get { return m_KnowUndead; }
            set { m_KnowUndead = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool KnowDruidic
        {
            get { return m_KnowDruidic; }
            set { m_KnowDruidic = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool KnowUmbravox
        {
            get { return m_KnowUmbravox; }
            set { m_KnowUmbravox = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool KnowAbyssal
        {
            get { return m_KnowAbyssal; }
            set { m_KnowAbyssal = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public SpeechType LanguageSpeaking
        {
            get { return LangSpeak; }
            set { LangSpeak = value; }
        }
        #endregion Multilinguists

        #region MagicianSpell System
        [CommandProperty(AccessLevel.GameMaster)]
        public bool FreeMovement
        {
            get { return m_FreeMovement; }
            set { m_FreeMovement = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool TTied
        {
            get { return m_TTied; }
            set { m_TTied = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public ClassType Class
        {
            get { return this.m_Class; }
            set
            {
                this.m_Class = value;
            }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public SpellHolder SpellsKnown
        {
            get { return m_SpellsKnown; }
            set { m_SpellsKnown = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public string FamiliarName
        {
            get { return m_FamiliarName; }
            set { this.m_FamiliarName = value; }
        }

        [CommandProperty(AccessLevel.GameMaster)]
        public Mobile Familiar
        {
            get { return m_Familiar; }
            set
            {
                this.m_Familiar = value;
                Familiar fam = m_Familiar as Familiar;
                this.FamiliarType = fam.FType;
            }
        }

        private FamiliarType m_FamiliarType = FamiliarType.None;

        [CommandProperty(AccessLevel.GameMaster)]
        public FamiliarType FamiliarType
        {
            get { return m_FamiliarType; }
            set { this.m_FamiliarType = value; }
        }
        #endregion WizardSpell System

        #endregion Custom Public Properties


        public PolyGlotMobile()
        {
            LangSpeak = SpeechType.Common;
            m_KnowDrow = false;
            m_KnowElven = false;
            m_KnowOrc = false;
            m_KnowUndead = false;
            m_KnowDruidic = false;
            m_KnowUmbravox = false;
            m_KnowAbyssal = false;
            m_TTied = false;
            m_SpellsKnown = new SpellHolder();
            m_Class = ClassType.None;

            m_Sleeping = false;
            m_GetsTired = false;  // disable sleep system here
            m_TireHard = 8;
            m_TireLevel = 0;
            m_TireTimer = new TireTimer(this);
            m_TireTimer.Start();
            m_SleepTimer = null;

            for (int i = 0; i < TeleportEntries.Length; i++)
            {
                TeleportEntries[i] = new RunebookEntry(this.Location, this.Map, "null", null);
            }

            for (int i = 0; i < MoonGateEntries.Length; i++)
            {
                MoonGateEntries[i] = new RunebookEntry(this.Location, this.Map, "null", null);
            }
        }

        public PolyGlotMobile(Serial s)
            : base(s)
        {
            LangSpeak = SpeechType.Common;
            m_KnowDrow = false;
            m_KnowElven = false;
            m_KnowOrc = false;
            m_KnowUndead = false;
            m_KnowDruidic = false;
            m_KnowUmbravox = false;
            m_KnowAbyssal = false;
            m_TTied = false;
            m_SpellsKnown = new SpellHolder();
            m_Class = ClassType.None;

            m_Sleeping = false;
            m_GetsTired = false;  // disable sleep system here
            m_TireHard = 8;
            m_TireLevel = 0;
            m_TireTimer = new TireTimer(this);
            m_TireTimer.Start();
            m_SleepTimer = null;

            for (int i = 0; i < TeleportEntries.Length; i++)
            {
                TeleportEntries[i] = new RunebookEntry(this.Location, this.Map, "null", null);
            }

            for (int i = 0; i < MoonGateEntries.Length; i++)
            {
                MoonGateEntries[i] = new RunebookEntry(this.Location, this.Map, "null", null);
            }
        }


        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);
            writer.Write((int)2);//version	

            // case 2
            for (int i = 0; i < TeleportEntries.Length; i++)
            {
                TeleportEntries[i].Serialize(writer);
            }

            for (int i = 0; i < MoonGateEntries.Length; i++)
            {
                MoonGateEntries[i].Serialize(writer);
            }

            writer.Write((bool)m_FreeMovement);
            writer.Write((bool)m_GetsTired);
            writer.Write((bool)m_Sleeping);
            writer.Write((int)m_TireHard);
            writer.Write((int)m_TireLevel);
            writer.Write((int)m_Class);
            m_SpellsKnown.Serialize(writer);

            // case 1
            writer.Write((bool)m_KnowDrow);
            writer.Write((bool)m_KnowElven);
            writer.Write((bool)m_KnowOrc);
            writer.Write((bool)m_KnowUndead);
            writer.Write((bool)m_KnowDruidic);
            writer.Write((bool)m_KnowUmbravox);
            writer.Write((bool)m_KnowAbyssal);

        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);
            int version = reader.ReadInt();

            switch (version)
            {
                case 2:
                    {
                        for (int i = 0; i < TeleportEntries.Length; i++)
                        {
                            TeleportEntries[i] = new RunebookEntry(reader);
                        }

                        for (int i = 0; i < MoonGateEntries.Length; i++)
                        {
                            MoonGateEntries[i] = new RunebookEntry(reader);
                        }

                        m_FreeMovement = reader.ReadBool();
                        m_GetsTired = reader.ReadBool();
                        m_Sleeping = reader.ReadBool();

                        // Known crash here, if character was sleeping upon server restart after a save.
                        // The following if statement fixes the problem, but makes players have to start resting
                        // all over again as if they didn't rest at all before the save.
                        if (m_Sleeping)
                        {
                            m_Sleeping = false;
                            Sleep();
                        }

                        m_TireHard = reader.ReadInt();
                        m_TireLevel = reader.ReadInt();

                        m_TireTimer = new TireTimer(this);
                        if (m_GetsTired)
                        {
                            m_TireTimer.Start();
                        }

                        m_Class = (ClassType)reader.ReadInt();
                        m_SpellsKnown = new SpellHolder(reader, this);
                        goto case 1;
                    }

                case 1:
                    {
                        LangSpeak = SpeechType.Common;
                        m_KnowDrow = reader.ReadBool();
                        m_KnowElven = reader.ReadBool();
                        m_KnowOrc = reader.ReadBool();
                        m_KnowUndead = reader.ReadBool();
                        m_KnowDruidic = reader.ReadBool();
                        m_KnowUmbravox = reader.ReadBool();
                        m_KnowAbyssal = reader.ReadBool();
                        goto case 0;
                    }

                case 0:
                    break;
            }
        }
    }
}


