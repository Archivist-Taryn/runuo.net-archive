using System;
using Server;

namespace Server.Spells
{
	public class Initializer
	{
		public static void Initialize()
		{
			// First circle
			Register( 00, typeof( First.ClumsySpell ) );
			Register( 01, typeof( First.CreateFoodSpell ) );
			Register( 02, typeof( First.FeeblemindSpell ) );
			Register( 03, typeof( First.HealSpell ) );
			Register( 04, typeof( First.MagicArrowSpell ) );
			Register( 05, typeof( First.NightSightSpell ) );
			Register( 06, typeof( First.ReactiveArmorSpell ) );
			Register( 07, typeof( First.WeakenSpell ) );

			// Second circle
			Register( 08, typeof( Second.AgilitySpell ) );
			Register( 09, typeof( Second.CunningSpell ) );
			Register( 10, typeof( Second.CureSpell ) );
			Register( 11, typeof( Second.HarmSpell ) );
			Register( 12, typeof( Second.MagicTrapSpell ) );
			Register( 13, typeof( Second.RemoveTrapSpell ) );
			Register( 14, typeof( Second.ProtectionSpell ) );
			Register( 15, typeof( Second.StrengthSpell ) );

			// Third circle
			Register( 16, typeof( Third.BlessSpell ) );
			Register( 17, typeof( Third.FireballSpell ) );
			Register( 18, typeof( Third.MagicLockSpell ) );
			Register( 19, typeof( Third.PoisonSpell ) );
			Register( 20, typeof( Third.TelekinesisSpell ) );
			Register( 21, typeof( Third.TeleportSpell ) );
			Register( 22, typeof( Third.UnlockSpell ) );
			Register( 23, typeof( Third.WallOfStoneSpell ) );

			// Fourth circle
			Register( 24, typeof( Fourth.ArchCureSpell ) );
			Register( 25, typeof( Fourth.ArchProtectionSpell ) );
			Register( 26, typeof( Fourth.CurseSpell ) );
			Register( 27, typeof( Fourth.FireFieldSpell ) );
			Register( 28, typeof( Fourth.GreaterHealSpell ) );
			Register( 29, typeof( Fourth.LightningSpell ) );
			Register( 30, typeof( Fourth.ManaDrainSpell ) );
			Register( 31, typeof( Fourth.RecallSpell ) );

			// Fifth circle
			Register( 32, typeof( Fifth.BladeSpiritsSpell ) );
			Register( 33, typeof( Fifth.DispelFieldSpell ) );
			Register( 34, typeof( Fifth.IncognitoSpell ) );
			Register( 35, typeof( Fifth.MagicReflectSpell ) );
			Register( 36, typeof( Fifth.MindBlastSpell ) );
			Register( 37, typeof( Fifth.ParalyzeSpell ) );
			Register( 38, typeof( Fifth.PoisonFieldSpell ) );
			Register( 39, typeof( Fifth.SummonCreatureSpell ) );

			// Sixth circle
			Register( 40, typeof( Sixth.DispelSpell ) );
			Register( 41, typeof( Sixth.EnergyBoltSpell ) );
			Register( 42, typeof( Sixth.ExplosionSpell ) );
			Register( 43, typeof( Sixth.InvisibilitySpell ) );
			Register( 44, typeof( Sixth.MarkSpell ) );
			Register( 45, typeof( Sixth.MassCurseSpell ) );
			Register( 46, typeof( Sixth.ParalyzeFieldSpell ) );
			Register( 47, typeof( Sixth.RevealSpell ) );

			// Seventh circle
			Register( 48, typeof( Seventh.ChainLightningSpell ) );
			Register( 49, typeof( Seventh.EnergyFieldSpell ) );
			Register( 50, typeof( Seventh.FlameStrikeSpell ) );
			Register( 51, typeof( Seventh.GateTravelSpell ) );
			Register( 52, typeof( Seventh.ManaVampireSpell ) );
			Register( 53, typeof( Seventh.MassDispelSpell ) );
			Register( 54, typeof( Seventh.MeteorSwarmSpell ) );
			Register( 55, typeof( Seventh.PolymorphSpell ) );

			// Eighth circle
			Register( 56, typeof( Eighth.EarthquakeSpell ) );
			Register( 57, typeof( Eighth.EnergyVortexSpell ) );
			Register( 58, typeof( Eighth.ResurrectionSpell ) );
			Register( 59, typeof( Eighth.AirElementalSpell ) );
			Register( 60, typeof( Eighth.SummonDaemonSpell ) );
			Register( 61, typeof( Eighth.EarthElementalSpell ) );
			Register( 62, typeof( Eighth.FireElementalSpell ) );
			Register( 63, typeof( Eighth.WaterElementalSpell ) );

			if ( Core.AOS )
			{
				// Necromancy spells
				Register( 100, typeof( Necromancy.AnimateDeadSpell ) );
				Register( 101, typeof( Necromancy.BloodOathSpell ) );
				Register( 102, typeof( Necromancy.CorpseSkinSpell ) );
				Register( 103, typeof( Necromancy.CurseWeaponSpell ) );
				Register( 104, typeof( Necromancy.EvilOmenSpell ) );
				Register( 105, typeof( Necromancy.HorrificBeastSpell ) );
				Register( 106, typeof( Necromancy.LichFormSpell ) );
				Register( 107, typeof( Necromancy.MindRotSpell ) );
				Register( 108, typeof( Necromancy.PainSpikeSpell ) );
				Register( 109, typeof( Necromancy.PoisonStrikeSpell ) );
				Register( 110, typeof( Necromancy.StrangleSpell ) );
				Register( 111, typeof( Necromancy.SummonFamiliarSpell ) );
				Register( 112, typeof( Necromancy.VampiricEmbraceSpell ) );
				Register( 113, typeof( Necromancy.VengefulSpiritSpell ) );
				Register( 114, typeof( Necromancy.WitherSpell ) );
				Register( 115, typeof( Necromancy.WraithFormSpell ) );

				if( Core.SE )
					Register( 116, typeof( Necromancy.ExorcismSpell ) );

				// Paladin abilities
				Register( 200, typeof( Chivalry.CleanseByFireSpell ) );
				Register( 201, typeof( Chivalry.CloseWoundsSpell ) );
				Register( 202, typeof( Chivalry.ConsecrateWeaponSpell ) );
				Register( 203, typeof( Chivalry.DispelEvilSpell ) );
				Register( 204, typeof( Chivalry.DivineFurySpell ) );
				Register( 205, typeof( Chivalry.EnemyOfOneSpell ) );
				Register( 206, typeof( Chivalry.HolyLightSpell ) );
				Register( 207, typeof( Chivalry.NobleSacrificeSpell ) );
				Register( 208, typeof( Chivalry.RemoveCurseSpell ) );
				Register( 209, typeof( Chivalry.SacredJourneySpell ) );

                // begin edit for Magician Spells
                Register(300, typeof(Magician.MagicMissileSpell));
                Register(301, typeof(Magician.FireBlastSpell));
                Register(302, typeof(Magician.LightningBoltSpell));
                Register(303, typeof(Magician.FireWallSpell));
                Register(304, typeof(Magician.ExplosionMSpell));
                Register(305, typeof(Magician.FlameStrikeMSpell));
                Register(306, typeof(Magician.ChainLightningMSpell));
                Register(307, typeof(Magician.TremorSpell));
                Register(308, typeof(Magician.EnergyBoltMSpell));
                Register(309, typeof(Magician.CreateFoodMSpell));
                Register(310, typeof(Magician.IncognitoMSpell));
                Register(311, typeof(Magician.AnimateDeadMSpell));
                Register(312, typeof(Magician.DrainLifeMSpell));
                Register(313, typeof(Magician.GateSpell));
                Register(314, typeof(Magician.BoneWallSpell));
                Register(315, typeof(Magician.AcidSplashSpell));
                Register(316, typeof(Magician.MelfsAcidArrowSpell));
                Register(317, typeof(Magician.WebSpell));
                Register(318, typeof(Magician.CreateUndeadSpell));
                Register(319, typeof(Magician.CalmSpell));
                Register(320, typeof(Magician.LocationSpell));
                Register(321, typeof(Magician.SummonMonster1Spell));
                Register(322, typeof(Magician.SummonMonster2Spell));
                Register(323, typeof(Magician.SummonSwarm1Spell));
                Register(324, typeof(Magician.BlurSpell));
                Register(325, typeof(Magician.TongueTiedSpell));
                Register(326, typeof(Magician.FamiliarSpell));
                Register(327, typeof(Magician.InvisibilityMSpell));
                Register(328, typeof(Magician.InvisibilitySphereSpell));
                Register(329, typeof(Magician.MeteorSpell));
                Register(330, typeof(Magician.PolymorphSelfSpell));
                Register(331, typeof(Magician.OpenCloseSpell));
                Register(332, typeof(Magician.HoldPersonSpell));
                Register(333, typeof(Magician.CatsGraceSpell));
                Register(334, typeof(Magician.FoxsCunningSpell));
                Register(335, typeof(Magician.BullsStrengthSpell));
                Register(336, typeof(Magician.ChangeStaffSpell));
                Register(337, typeof(Magician.ConeOfColdSpell));
                Register(338, typeof(Magician.AnalyzeDweomerSpell));
                Register(339, typeof(Magician.ShockingGraspSpell));
                Register(340, typeof(Magician.DazeMonsterSpell));
                Register(341, typeof(Magician.ResistPoisonSpell));
                Register(342, typeof(Magician.ReadMagicSpell));
                Register(343, typeof(Magician.PolymorphOtherSpell));
                Register(344, typeof(Magician.MirrorImageSpell));
                Register(345, typeof(Magician.SleepSpell));
                Register(346, typeof(Magician.DeepSlumberSpell));
                Register(347, typeof(Magician.PalsySpell));
                Register(348, typeof(Magician.EndureElementsSpell));
                Register(349, typeof(Magician.EndureColdSpell));
                Register(350, typeof(Magician.EndureEnergySpell));
                Register(351, typeof(Magician.EndureFireSpell));
                Register(352, typeof(Magician.ResistAcidSpell));
                Register(353, typeof(Magician.EnhanceFamiliarSpell));
                Register(354, typeof(Magician.ArcaneMarkSpell));
                Register(355, typeof(Magician.FortifyFamiliarSpell));
                Register(356, typeof(Magician.ShadesSpell));
                Register(357, typeof(Magician.FireSphereSpell));
                Register(358, typeof(Magician.ControlDeadSpell));
                Register(359, typeof(Magician.LightSpell));
                Register(360, typeof(Magician.ObscuringMistSpell));
                Register(361, typeof(Magician.TeleportMSpell));
                Register(362, typeof(Magician.SimulacrumSpell));
                Register(363, typeof(Magician.DimensionDoorSpell));
                Register(364, typeof(Magician.ProvokeSpell));
                Register(365, typeof(Magician.PutridHuskSpell));
                Register(366, typeof(Magician.LevitationSpell));
                Register(366, typeof(Magician.DivineFavorSpell));

                // end edit

				if ( Core.SE )
				{
					// Samurai abilities
					Register( 400, typeof( Bushido.HonorableExecution ) );
					Register( 401, typeof( Bushido.Confidence ) );
					Register( 402, typeof( Bushido.Evasion ) );
					Register( 403, typeof( Bushido.CounterAttack ) );
					Register( 404, typeof( Bushido.LightningStrike ) );
					Register( 405, typeof( Bushido.MomentumStrike ) );

					// Ninja abilities
					Register( 500, typeof( Ninjitsu.FocusAttack ) );
					Register( 501, typeof( Ninjitsu.DeathStrike ) );
					Register( 502, typeof( Ninjitsu.AnimalForm ) );
					Register( 503, typeof( Ninjitsu.KiAttack ) );
					Register( 504, typeof( Ninjitsu.SurpriseAttack ) );
					Register( 505, typeof( Ninjitsu.Backstab ) );
					Register( 506, typeof( Ninjitsu.Shadowjump ) );
					Register( 507, typeof( Ninjitsu.MirrorImage ) );
				}

				if( Core.ML )
				{
					Register( 600, typeof( Spellweaving.ArcaneCircleSpell ) );
					Register( 601, typeof( Spellweaving.GiftOfRenewalSpell ) );
					Register( 602, typeof( Spellweaving.ImmolatingWeaponSpell ) );
					Register( 603, typeof( Spellweaving.AttuneWeaponSpell ) );
					Register( 604, typeof( Spellweaving.ThunderstormSpell ) );
					Register( 605, typeof( Spellweaving.NatureFurySpell ) );
					Register( 606, typeof( Spellweaving.SummonFeySpell ) );
					Register( 607, typeof( Spellweaving.SummonFiendSpell ) );
					Register( 608, typeof( Spellweaving.ReaperFormSpell ) );
					//Register( 609, typeof( Spellweaving.WildfireSpell ) );
					Register( 610, typeof( Spellweaving.EssenceOfWindSpell ) );
					//Register( 611, typeof( Spellweaving.DryadAllureSpell ) );
					Register( 612, typeof( Spellweaving.EtherealVoyageSpell ) );
					Register( 613, typeof( Spellweaving.WordOfDeathSpell ) );
					Register( 614, typeof( Spellweaving.GiftOfLifeSpell ) );
					//Register( 615, typeof( Spellweaving.ArcaneEmpowermentSpell ) );
				}
			}
		}

		public static void Register( int spellID, Type type )
		{
			SpellRegistry.Register( spellID, type );
		}
	}
}