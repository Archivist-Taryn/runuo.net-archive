using System;
using Server.Items;

namespace Server.Spells
{
    public class Reagent
    {
        private static Type[] m_Types = new Type[26]
			{
				typeof( BlackPearl ),//begin common regs
				typeof( Bloodmoss ),
				typeof( Garlic ),
				typeof( Ginseng ),
				typeof( MandrakeRoot ),
				typeof( Nightshade ),
				typeof( SulfurousAsh ),
				typeof( SpidersSilk ),
				typeof( BatWing ),
				typeof( GraveDust ),
				typeof( BloodSpawn ),
				typeof( NoxCrystal ),
				typeof( PigIron ),
				typeof( Bone ),
				typeof( DaemonBone ),//begin rare regs
				typeof( WyrmsHeart ),
				typeof( DaemonBlood ),
				typeof( DragonsTooth ),
				typeof( Amber ),
				typeof( Diamond ),
				typeof( Amethyst ),
				typeof( Sapphire ),
				typeof( Ruby ),
				typeof( Citrine ),
				typeof( Emerald ),
				typeof( Tourmaline ),
			};

        public Type[] Types
        {
            get { return m_Types; }
        }

        public static Type BlackPearl 				  // Begin Common Regs
        {
            get { return m_Types[0]; }
            set { m_Types[0] = value; }
        }

        public static Type Bloodmoss
        {
            get { return m_Types[1]; }
            set { m_Types[1] = value; }
        }

        public static Type Garlic
        {
            get { return m_Types[2]; }
            set { m_Types[2] = value; }
        }

        public static Type Ginseng
        {
            get { return m_Types[3]; }
            set { m_Types[3] = value; }
        }

        public static Type MandrakeRoot
        {
            get { return m_Types[4]; }
            set { m_Types[4] = value; }
        }

        public static Type Nightshade
        {
            get { return m_Types[5]; }
            set { m_Types[5] = value; }
        }

        public static Type SulfurousAsh
        {
            get { return m_Types[6]; }
            set { m_Types[6] = value; }
        }

        public static Type SpidersSilk
        {
            get { return m_Types[7]; }
            set { m_Types[7] = value; }
        }

        public static Type BatWing
        {
            get { return m_Types[8]; }
            set { m_Types[8] = value; }
        }

        public static Type GraveDust
        {
            get { return m_Types[9]; }
            set { m_Types[9] = value; }
        }

        public static Type BloodSpawn
        {
            get { return m_Types[10]; }
            set { m_Types[10] = value; }
        }

        public static Type NoxCrystal
        {
            get { return m_Types[11]; }
            set { m_Types[11] = value; }
        }

        public static Type PigIron
        {
            get { return m_Types[12]; }
            set { m_Types[12] = value; }
        }

        public static Type Bone
        {
            get { return m_Types[13]; }
            set { m_Types[13] = value; }
        }

        public static Type DeamonBone                       //Begin Rare Regs
        {
            get { return m_Types[14]; }
            set { m_Types[14] = value; }
        }

        public static Type WyrmsHeart
        {
            get { return m_Types[15]; }
            set { m_Types[15] = value; }
        }

        public static Type DaemonBlood
        {
            get { return m_Types[16]; }
            set { m_Types[16] = value; }
        }

        public static Type DragonsTooth
        {
            get { return m_Types[17]; }
            set { m_Types[17] = value; }
        }

        public static Type Amber
        {
            get { return m_Types[18]; }
            set { m_Types[18] = value; }
        }

        public static Type Diamond
        {
            get { return m_Types[19]; }
            set { m_Types[19] = value; }
        }

        public static Type Amethyst
        {
            get { return m_Types[20]; }
            set { m_Types[20] = value; }
        }

        public static Type Sapphire
        {
            get { return m_Types[21]; }
            set { m_Types[21] = value; }
        }

        public static Type Ruby
        {
            get { return m_Types[22]; }
            set { m_Types[22] = value; }
        }

        public static Type Citrine
        {
            get { return m_Types[23]; }
            set { m_Types[23] = value; }
        }

        public static Type Emerald
        {
            get { return m_Types[24]; }
            set { m_Types[24] = value; }
        }

        public static Type Tourmaline
        {
            get { return m_Types[25]; }
            set { m_Types[25] = value; }
        }
    }
}
