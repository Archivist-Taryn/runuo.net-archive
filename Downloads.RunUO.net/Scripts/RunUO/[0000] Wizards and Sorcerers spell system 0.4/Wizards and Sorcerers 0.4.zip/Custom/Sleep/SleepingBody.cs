using System;
using System.Collections;
using Server;
using Server.Engines.PartySystem;
using Server.Misc;
using Server.Guilds;
using Server.Mobiles;
using Server.Network;
using Server.ContextMenus;

namespace Server.Items
{
	public class SleepingBody : Container
	{
		private Mobile m_Owner;
		private string m_SleepingBodyName;
		private Timer m_Timer;
		private ArrayList	m_EquipItems;			// List of items equiped when the owner died. Ingame, these items display /on/ the SleepingBody, not just inside
		
		[CommandProperty( AccessLevel.GameMaster )]
		public Mobile Owner
		{
			get{ return m_Owner; }
		}
		public ArrayList EquipItems
		{
			get{ return m_EquipItems; }
		}
		
		
		[Constructable]
		public SleepingBody( Mobile owner ) : base( 0x2006 )
		{
			// To supress console warnings, stackable must be true
			Stackable = true;
			Amount = owner.Body; // protocol defines that for itemid 0x2006, amount=body
			Stackable = false;
			Movable = false;
			
			
			
			m_Owner = owner;
			Name = m_Owner.Name + " [Sleeping}";
			m_SleepingBodyName = Name;
			Hue = m_Owner.Hue;
			Direction = m_Owner.Direction;
			//	Name = "a sleeping body";
			
			m_Timer = new InternalTimer( m_Owner, this );
			
			m_Timer.Start();
			
		}
		
		
		public override void OnDoubleClick( Mobile from )
		{
			from.SendMessage("You cannot perform negative actions on this being");
		}
		
		
		
		public override void OnAfterDelete()
		{
			if ( m_Timer != null )
				m_Timer.Stop();
			
			m_Timer = null;
			if(m_Owner!=null)
			{
				m_Owner.Z=this.Z;
			}
			
			base.OnAfterDelete();
		}
		
		public SleepingBody( Serial serial ) : base( serial )
		{
	
		}
		
		public override void AddNameProperty( ObjectPropertyList list )
		{
			list.Add( m_SleepingBodyName );	
		}
		
		public override void OnSingleClick( Mobile from )
		{
			int hue = 10;
			
			if ( ItemID == 0x2006 ) // Corpse form
			{
				if ( m_SleepingBodyName != null )
					from.Send( new AsciiMessage( Serial, ItemID, MessageType.Label, hue, 3, "", m_SleepingBodyName ) );
				else
					from.Send( new MessageLocalized( Serial, ItemID, MessageType.Label, hue, 3, 1046414, "", Name ) );
			}
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			
			writer.Write( (int) 0 ); // version
			writer.Write(m_Owner);
			writer.Write(m_SleepingBodyName);
			
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			
			int version = reader.ReadInt();
			m_Owner = reader.ReadMobile();
			m_SleepingBodyName = reader.ReadString();
		}
		
		private class InternalTimer : Timer
		{
			private Mobile m_Owner;
			private Item m_Body;
			
			
			public InternalTimer( Mobile m, Item body ) : base( TimeSpan.FromSeconds(10),TimeSpan.FromSeconds(10) )
			{
				m_Owner=m;
				m_Body=body;
			}
			protected override void OnTick()
			{
				if(m_Body!=null)
					m_Body.PublicOverheadMessage(0,m_Owner.SpeechHue,false,"zZz");
				if(m_Owner!=null)
					m_Owner.PlaySound(  m_Owner.Female ? 819 : 1093);
				//seems to crash certain clients
			}
		}
	}
}
