using System;
using Server;
using Server.Mobiles;
using Server.Items;

namespace Server.Items
{
	public enum SleepRefreshRate
	{
		Worst = 1,
		Bad = 2,
		Average = 4,
		Good = 8,
		Best = 16
	}

	public abstract class BaseSleepItem : Item
	{

		protected bool inUse;
		protected Mobile lastSleeper;
		protected DateTime lastUsedOn;

		public override bool Decays { get { return false; } }

		[CommandProperty( AccessLevel.Counselor )]
		public virtual SleepRefreshRate RefreshRate { get { return SleepRefreshRate.Average; } }

		[CommandProperty( AccessLevel.Counselor )]
		public bool InUse
		{
			get { return this.inUse; }
			set { this.inUse = value; }
		}

		[CommandProperty( AccessLevel.Counselor )]
		public Mobile LastSleeper
		{
			get { return this.lastSleeper; }
		}

		[CommandProperty( AccessLevel.Counselor )]
		public DateTime LastUsedOn
		{
			get { return this.lastUsedOn; }
		}

		public BaseSleepItem() : base( 0xFFF )
		{
			inUse = false;
			lastSleeper = null;
			lastUsedOn = DateTime.Now;
		}

		public BaseSleepItem( Serial serial ) : base( serial )
		{
		}

		public override void OnDoubleClick( Mobile from )
		{
			PlayerMobile player = from as PlayerMobile;

			if ( inUse )
				from.SendMessage( "You must wait until this is available." );
			else
			{
				if ( player.Tired < 1 )
					from.SendMessage( "You are not tired enough to use this." );
				else
				{
					if ( this.IsChildOf( from.Backpack ) )
						from.SendMessage( "You cannot use this while inside your Backpack." );
					else
					{
						lastSleeper = from;
						lastUsedOn = DateTime.Now;
						inUse = true;
						player.Sleep( this );
					}
				}
			}
		}
		
		public override void Serialize (GenericWriter writer)
		{
			base.Serialize( writer );
		}
		
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize( reader );
		}
	}
}

