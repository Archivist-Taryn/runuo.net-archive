using System; 
using System.IO; 
using System.Collections; 

namespace Server.Custom 
{ 
	
	public class Translator
	{
		public static String[] EnglishElf;
		public static String[] EnglishOrc;
		public static String[] EnglishDrow;
		public static String[] Elven;
		public static String[] Orcish;
		public static String[] Drow;
		
		public static void Initialize()
		{
			bool Enabled = true;  // Disable translator here
			
			ArrayList EnglishToElven = new ArrayList();
			ArrayList EnglishToOrcish = new ArrayList();
			ArrayList EnglishToDrow = new ArrayList();
			try
			{
				using (StreamReader sr = new StreamReader("Scripts\\Custom\\EngToElven.txt"))
				{
					String line;
					while ((line = sr.ReadLine()) != null)
					{
						EnglishToElven.Add(line);
					}
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("The file could not be read:");
				Console.WriteLine(e.Message);
			}
			
			try
			{
				using (StreamReader sr = new StreamReader("Scripts\\Custom\\EngToOrcish.txt"))
				{
					String line;
					while ((line = sr.ReadLine()) != null)
					{
						EnglishToOrcish.Add(line);
					}
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("The file could not be read:");
				Console.WriteLine(e.Message);
			}
			
			try
			{
				using (StreamReader sr = new StreamReader("Scripts\\Custom\\EngToDrow.txt"))
				{
					String line;
					while ((line = sr.ReadLine()) != null)
					{
						EnglishToDrow.Add(line);
					}
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("The file could not be read:");
				Console.WriteLine(e.Message);
			}
			
			
			if((EnglishToElven.Count > 0) && (EnglishToOrcish.Count > 0) && (EnglishToDrow.Count > 0) && Enabled)
			{
				EnglishElf = new String[EnglishToElven.Count];
				Elven = new String[EnglishToElven.Count];
				
				for( int i = 0; i < EnglishToElven.Count; i++ )
				{
					String line = Convert.ToString(EnglishToElven[i]);
					String[] splitting = line.Split('=');
					EnglishElf[i] = Convert.ToString(splitting[0]);
					Elven[i] = Convert.ToString(splitting[1]);
				}
				
				EnglishOrc = new String[EnglishToOrcish.Count];
				Orcish = new String[EnglishToOrcish.Count];
				
				for( int i = 0; i < EnglishToOrcish.Count; i++ )
				{
					String line = Convert.ToString(EnglishToOrcish[i]);
					String[] splitting = line.Split('=');
					EnglishOrc[i] = Convert.ToString(splitting[0]);
					Orcish[i] = Convert.ToString(splitting[1]);
				}
				
				EnglishDrow = new String[EnglishToDrow.Count];
				Drow = new String[EnglishToDrow.Count];
				
				for( int i = 0; i < EnglishToDrow.Count; i++ )
				{
					String line = Convert.ToString(EnglishToDrow[i]);
					String[] splitting = line.Split('=');
					EnglishDrow[i] = Convert.ToString(splitting[0]);
					Drow[i] = Convert.ToString(splitting[1]);
				}
				
				
			}
			else
			{
				EnglishElf = null;
				Elven = null;
				EnglishOrc = null;
				Orcish = null;
				EnglishDrow = null;
				Drow = null;
			}
		}
		
	}
}
