using System;
using System.Text;
using Server.Gumps;
using Server.Network;
using System.Collections;
using Server.Mobiles;

namespace Server.Custom
{
	public class Translate
	{
		public static void Initialize()
		{
			// Register our speech handler
			EventSink.Speech += new SpeechEventHandler( EventSink_Speech );
		}
		
		private static void EventSink_Speech( SpeechEventArgs args )
		{
            if (!(args.Mobile is PlayerMobile))
            {
                args.Mobile.OnSpeech(args);
                return;
            }
			string mySpeech = args.Speech;
			PlayerMobile from = args.Mobile as PlayerMobile;
			args.Blocked = true;
			//	SpeechEventArgs NPCargs = new SpeechEventArgs( args.Mobile, args.Speech, args.Type, args.Hue, args.Keywords );
			int tileLength = 5;
			
			switch ( args.Type )
			{
				case MessageType.Yell:
					tileLength = 20;
					break;
				case MessageType.Regular:
					tileLength = 10;
					break;
				case MessageType.Whisper:
					tileLength = 1;
					break;
				default:
					tileLength = 10;
					break;
			}
			
			String mySpeechTranslated = null;
			if(args.Type == MessageType.Emote)
			{
				from.Emote(mySpeech);
			}
			else
			{
				ArrayList list = new ArrayList();
				foreach ( Mobile mob in from.Map.GetMobilesInRange( from.Location, tileLength ) )
				{
					list.Add(mob);
				}
				for(int j = 0; j < list.Count; j++)
				{
					Mobile m = list[j] as Mobile;
					if( m.Player )
					{
						PlayerMobile playerm = m as PlayerMobile;
						
						if (from.LanguageSpeaking == SpeechType.Common)
						{
							from.SayTo( playerm, mySpeech );
						}
						else if(((from.LanguageSpeaking == SpeechType.Drow)&&(playerm.KnowDrow)))
						{
							mySpeechTranslated = "[Drow] " + mySpeech;
							from.SayTo( playerm, mySpeechTranslated );
						}
						else if(((from.LanguageSpeaking == SpeechType.Elven)&&(playerm.KnowElven)))
						{
							mySpeechTranslated = "[Elven] " + mySpeech;
							from.SayTo( playerm, mySpeechTranslated );
						}
						else if(((from.LanguageSpeaking == SpeechType.Orc)&&(playerm.KnowOrc)))
						{
							mySpeechTranslated = "[Orc] " + mySpeech;
							from.SayTo( playerm, mySpeechTranslated );
						}
						else if(((from.LanguageSpeaking == SpeechType.Undead)&&(playerm.KnowUndead)))
						{
							mySpeechTranslated = "[Undead] " + mySpeech;
							from.SayTo( playerm, mySpeechTranslated );
						}
						else if(((from.LanguageSpeaking == SpeechType.Druidic)&&(playerm.KnowDruidic)))
						{
							mySpeechTranslated = "[Druidic] " + mySpeech;
							from.SayTo( playerm, mySpeechTranslated );
						}
						else if(((from.LanguageSpeaking == SpeechType.Umbravox)&&(playerm.KnowUmbravox)))
						{
							mySpeechTranslated = "[Umbravox] " + mySpeech;
							from.SayTo( playerm, mySpeechTranslated );
						}
						else if(((from.LanguageSpeaking == SpeechType.Abyssal)&&(playerm.KnowAbyssal)))
						{
							mySpeechTranslated = "[Abyssal] " + mySpeech;
							from.SayTo( playerm, mySpeechTranslated );
						}
						else
						{
							String[] speech = mySpeech.Split(' ');
							int stringlength = speech.Length;

                            string tempy;
                            string endchar = "";
							
							mySpeechTranslated = null;
							if (from.LanguageSpeaking == SpeechType.Drow)
							{
								
								for( int i = 0; i < stringlength; i++ )
								{
                                    // First, check for punctuation at the end of each word

                                    if (speech[i].EndsWith(".") || speech[i].EndsWith("!")
                                        || speech[i].EndsWith(",") || speech[i].EndsWith("?")
                                        || speech[i].EndsWith(";") || speech[i].EndsWith(":"))
                                    {
                                        // If punctuation is found, save it temporarily while removing it from original speech
                                        endchar = speech[i].Substring(speech[i].Length - 1, 1);
                                        speech[i] = speech[i].Substring(0, speech[i].Length - 1);
                                    }
                                                                        
                                    tempy = TranslateToDrow(speech[i]) + endchar; // add punctuation
                                    endchar = ""; // reset punctuation

                                    if (mySpeechTranslated == null)
                                        mySpeechTranslated = tempy;
                                    else if (tempy != null)
                                        mySpeechTranslated += " " + tempy;
                                    
								}
                                // Capitalize the first word of sentence
                                tempy = mySpeechTranslated.Substring(0, 1).ToUpper();
                                mySpeechTranslated = mySpeechTranslated.Substring(1, mySpeechTranslated.Length - 1);
                                mySpeechTranslated = tempy + mySpeechTranslated;
                                tempy = null; // reset temp
							}
							else if (from.LanguageSpeaking == SpeechType.Elven)
							{
							
								for( int i = 0; i < stringlength; i++ )
								{
                                    // First, check for punctuation at the end of each word

                                    if (speech[i].EndsWith(".") || speech[i].EndsWith("!")
                                        || speech[i].EndsWith(",") || speech[i].EndsWith("?")
                                        || speech[i].EndsWith(";") || speech[i].EndsWith(":"))
                                    {
                                        // If punctuation is found, save it temporarily while removing it from original speech
                                        endchar = speech[i].Substring(speech[i].Length - 1, 1);
                                        speech[i] = speech[i].Substring(0, speech[i].Length - 1);
                                    }
								
									tempy = TranslateToElven(speech[i]) + endchar;  // add punctuation
                                    endchar = ""; // reset punctuation
									
									if (mySpeechTranslated == null)
										mySpeechTranslated = tempy;
									else if (tempy != null)
										mySpeechTranslated += " " + tempy;
									
								}
                                // Capitalize the first word of sentence
                                tempy = mySpeechTranslated.Substring(0, 1).ToUpper();
                                mySpeechTranslated = mySpeechTranslated.Substring(1, mySpeechTranslated.Length - 1);
                                mySpeechTranslated = tempy + mySpeechTranslated;
                                tempy = null; // reset temp
							}
							else if (from.LanguageSpeaking == SpeechType.Orc)
							{

                                for (int i = 0; i < stringlength; i++)
                                {
                                    // First, check for punctuation at the end of each word

                                    if (speech[i].EndsWith(".") || speech[i].EndsWith("!")
                                        || speech[i].EndsWith(",") || speech[i].EndsWith("?")
                                        || speech[i].EndsWith(";") || speech[i].EndsWith(":"))
                                    {
                                        // If punctuation is found, save it temporarily while removing it from original speech
                                        endchar = speech[i].Substring(speech[i].Length - 1, 1);
                                        speech[i] = speech[i].Substring(0, speech[i].Length - 1);
                                    }

                                    tempy = TranslateToOrc(speech[i]) + endchar;  // add punctuation
                                    endchar = ""; // reset punctuation
									
									if (mySpeechTranslated == null)
										mySpeechTranslated = tempy;
									else if (tempy != null)
										mySpeechTranslated += " " + tempy;
									
								}
                                // Capitalize the first word of sentence
                                tempy = mySpeechTranslated.Substring(0, 1).ToUpper();
                                mySpeechTranslated = mySpeechTranslated.Substring(1, mySpeechTranslated.Length - 1);
                                mySpeechTranslated = tempy + mySpeechTranslated;
                                tempy = null; // reset temp
							}
							else if (from.LanguageSpeaking == SpeechType.Undead)
							{
								mySpeechTranslated = TranslateToUndead();
							}
							else if (from.LanguageSpeaking == SpeechType.Jibberish)
							{
								mySpeechTranslated = TranslateToJibberish();
							}
							else if (from.LanguageSpeaking == SpeechType.Druidic)
							{
								mySpeechTranslated = TranslateToDruidic();
							}
							else if (from.LanguageSpeaking == SpeechType.Umbravox)
							{
								mySpeechTranslated = TranslateToUmbravox();
							}
							else if (from.LanguageSpeaking == SpeechType.Abyssal)
							{
								
								for( int i = 0; i < stringlength; i++ )
								{
									tempy = TranslateToAbyssal(speech[i]);
									
									if (mySpeechTranslated == null)
										mySpeechTranslated = tempy;
									else if (tempy != null)
										mySpeechTranslated += " " + tempy;
									
								}
							}
							
							
							if (from.LanguageSpeaking == SpeechType.Umbravox)
							{
								int temphue = from.SpeechHue;
								from.SpeechHue = from.EmoteHue;
								mySpeechTranslated = "*" + mySpeechTranslated + "*";
								from.SayTo( playerm, mySpeechTranslated);
								from.SpeechHue = temphue;
							}
							else
								from.SayTo( playerm, mySpeechTranslated );
						}
					}
                    else if (m is PolyGlotMobile)
					{

						// This area is needed so that npcs will hear you.  NPCs can learn and use languages however you must change
                        // their base class from Mobile to PolyGlotMobile in order for this script to be active.

                        PolyGlotMobile npclistener = m as PolyGlotMobile;
						switch (from.LanguageSpeaking)
						{
							case SpeechType.Common:
								{
									npclistener.OnSpeech( args );
									break;
								}
								
							case SpeechType.Drow:
								{
									if (npclistener.KnowDrow)
										npclistener.OnSpeech( args );
									else
										npclistener.Emote("ignores you");
									
									break;
								}
								
							case SpeechType.Elven:
								{
									if (npclistener.KnowElven)
										npclistener.OnSpeech( args );
									else
										npclistener.Emote("ignores you");
									
									break;
								}
								
							case SpeechType.Orc:
								{
									if (npclistener.KnowOrc)
										npclistener.OnSpeech( args );
									else
										npclistener.Emote("ignores you");
									
									break;
								}
								
							case SpeechType.Druidic:
								{
									if (npclistener.KnowDruidic)
										npclistener.OnSpeech( args );
									else
										npclistener.Emote("ignores you");
									
									break;
								}
								
							case SpeechType.Umbravox:
								{
									if (npclistener.KnowUmbravox)
										npclistener.OnSpeech( args );
									else
										npclistener.Emote("ignores you");
									
									break;
								}
								
							default:
								{
									npclistener.Emote("ignores you");
									break;
								}
						}
					}
					else
						m.OnSpeech( args );
					
				}
				list.Clear();
			}
			
		}

        public static bool IsCapitalized(String speech)
        {
            return false;
        }
		
		public static String TranslateToOrc( String speech )
		{
			for(int i = 0; i < Server.Custom.Translator.Orcish.Length; i++ )
			{
                if (speech.ToLower() == Server.Custom.Translator.EnglishOrc[i])
                {
                    if ( IsCapitalized( speech ) )
                    return Server.Custom.Translator.Orcish[i];
                }
			}
			if (speech.ToLower() != speech)  // takes care of proper names that arent defined
				return speech;
			
			return null;
		}
		
		public static String TranslateToElven( String speech )
		{
			for(int i = 0; i < Server.Custom.Translator.Elven.Length; i++ )
			{
				if ( speech.ToLower() == Server.Custom.Translator.EnglishElf[i])
					return Server.Custom.Translator.Elven[i];
			}
			if (speech.ToLower() != speech)  // takes care of proper names that arent defined
				return speech;
			
			return null;
		}
		
		public static String TranslateToDrow( String speech )
		{
			for(int i = 0; i < Server.Custom.Translator.Drow.Length; i++ )
			{
				if ( speech.ToLower() == Server.Custom.Translator.EnglishDrow[i])
					return Server.Custom.Translator.Drow[i];
			}
			if (speech.ToLower() != speech)  // takes care of proper names that arent defined
				return speech;
			
			return null;
		}
		
		public static String TranslateToUndead()
		{
			int rand = Utility.Random( 0, 17 );
			String speech = null;
			
			switch(rand)
			{
				case 0:
					speech = "*moans loudly*";
					break;
				case 1:
					speech = "*groans and moans*";
					break;
				case 2:
					speech = "Raaaoooorrroaaarrrrrrrrr.";
					break;
				case 3:
					speech = "Uhhhhhhhhhhh.....";
					break;
				case 4:
					speech = "OOOOoOOoO OOooo ooOOo!";
					break;
				case 5:
					speech = "AHHHHRRRRR!";
					break;
		    	case 6:
					speech = "*Growls dreadfuly!*";
					break;
				case 7:
					speech = "Moaaaan!";
					break;
				case 8:
					speech = "Aaaaaarrrrg!";
					break;
				case 9:
					speech = "Ashhhhhhaaarrr...!";
					break;
				case 10:
					speech = "Ummmm...";
					break;	
				case 11:
					speech = "*Moans*!";
					break;	
				case 12:
					speech = "*Growls loudly*!";
					break;	
				case 13:
					speech = "*Sinister giggle*!";
					break;
				case 14:
					speech = "Gurrrahhh...!";
					break;
				case 15:
					speech = "Grrrr!";
					break;	
				case 16:
					speech = "OooooOOoo ooOoooo OOooooOOo.";
					break;		
				
			
				default:
					speech = "Ugh...";
					break;
			}
			
			return speech;
		}
		
		public static String TranslateToJibberish()
		{
			int rand = Utility.Random( 0, 15 );
			String speech = null;
			
			switch(rand)
			{
				case 0:
					speech = "jeeba";
					break;
				case 1:
					speech = "jabba";
					break;
				case 2:
					speech = "jibba";
					break;
				case 3:
					speech = "jobbo jabba";
					break;
				case 4:
					speech = "jubbaka!";
					break;	
				case 5:
					speech = "joobi...";
					break;
				case 6:
					speech = "jibbe jubby!";
					break;
				case 7:
					speech = "jebboo!";
					break;
				case 8:
					speech = "jabba jubba jeeba";
					break;
				case 9:
					speech = "jujajee";
					break;
				case 10:
					speech = "Jeebirish";
					break;
				case 11:
					speech = "Jabooki";
					break;	
				case 12:
					speech = "Jejeje!";
					break;	
				case 13:
					speech = "Jubbi!";
					break;
				case 14:
					speech = "Jaabe!";
					break;
				default:
					speech = "jeeba jabba";
					break;
			}
			
			return speech;
		}
		
		public static String TranslateToDruidic()
		{
			String speech = "";
			
			return speech;
		}
		
		public static String TranslateToUmbravox()
		{
			int rand = Utility.Random( 0, 10 );
			String speech = null;
			
			switch(rand)
			{
				case 0:
					speech = "points and raises an eyebrow";
					break;
				case 1:
					speech = "motions towards you with hands open";
					break;
				case 3:
					speech = "hand gestures";
					break;
				case 4:
					speech = "hands make a circular motion";
					break;
				case 5:
					speech = "points upward and then shows palms of hands";
					break;
				case 6:
					speech = "motions towards you with hands closed";
					break;
				case 7:
					speech = "makes a fist and then points down";
					break;
				case 8:
					speech = "makes a fist with one hand and holds it with the other hand";
					break;
				case 9:
					speech = "makes a fist and holds it to side of face";
					break;
				default:
					speech = "gestures with hands and arm movements";
					break;
			}
			
			return speech;
		}
		
		public static String TranslateToAbyssal( String speech )
		{
			if (speech.Length < 4)
				return null;
			
			int rand = Utility.Random( 0, 80 );
			
			switch(rand)
			{
				case 0:
					speech = "Cursa";
					break;
				case 1:
					speech = "Mare";
					break;
				case 2:
					speech = "Menta";
					break;
				case 3:
					speech = "Minoris";
					break;
				case 4:
					speech = "Tormentio";
					break;
				case 5:
					speech = "Carn";
					break;
				case 6:
					speech = "Demoneus";
					break;
				case 7:
					speech = "Chronos";
					break;
				case 8:
					speech = "Santuera";
					break;
				case 9:
					speech = "Divis";
					break;
				case 10:
					speech = "Nocte";
					break;
				case 11:
					speech = "Paraseus";
					break;
				case 12:
					speech = "Potens";
					break;
				case 13:
					speech = "Maledicere";
					break;
				case 14:
					speech = "Tortio";
					break;
				case 15:
					speech = "Sinestra";
					break;
				case 16:
					speech = "Projicere";
					break;
				case 17:
					speech = "Terra";
					break;
				case 18:
					speech = "Deus";
					break;
				case 19:
					speech = "Talonis";
					break;
				case 20:
					speech = "Illudere";
					break;
				case 21:
					speech = "Elleya";
					break;
				case 22:
					speech = "Jahtra";
					break;
				case 23:
					speech = "Incantare";
					break;
				case 24:
					speech = "Ferra";
					break;
				case 25:
					speech = "Lacre";
					break;
				case 26:
					speech = "Noce";
					break;
				case 27:
					speech = "Sactra";
					break;
				case 28:
					speech = "Annios";
					break;
				case 29:
					speech = "Contarius";
					break;
				case 30:
					speech = "Allysium";
					break;
				case 31:
					speech = "Anishius";
					break;
				case 32:
					speech = "Inignis";
					break;
				case 33:
					speech = "Sharen";
					break;
				case 34:
					speech = "Sacren";
					break;
				case 35:
					speech = "Inferis";
					break;
				case 36:
					speech = "Exidus";
					break;
				case 37:
					speech = "Pyrenius";
					break;
				case 38:
					speech = "Anneya";
					break;
				case 39:
					speech = "Chantra";
					break;	
				case 40:
					speech = "Sactrum";
					break;	
				case 41:
					speech = "Santuarra";
					break;	
				case 42:
					speech = "Doomio";
					break;
				case 43:
					speech = "Feris";
					break;
				case 44:
					speech = "Terris";
					break;
				case 45:
					speech = "Serre";
					break;
				case 46:
					speech = "Minos";
					break;
			   	case 47:
					speech = "Arcaniss";
					break;
				case 48:
					speech = "Bellius";
					break;
				case 49:
					speech = "Diabolio";
					break;
				case 50:
					speech = "Baroth";
					break;
				case 51:
					speech = "Infesto";
					break;
				case 52:
					speech = "Derness";
					break;
				case 53:
					speech = "Ashrra";
					break;
				case 54:
					speech = "Carre";
					break;
				case 55:
					speech = "Mir";
					break;	
				case 56:
					speech = "Abys";
					break;
				case 57:
					speech = "Inorio";
					break;	
				case 58:
					speech = "Develio";
					break;
				case 59:
					speech = "Dimianor";
					break;	
				case 60:
					speech = "Fictus";
					break;
				case 61:
					speech = "Amen";
					break;
				default:
					speech = "Ignis";
					break;
					
			}
			
			return speech;
		}
	}
}

