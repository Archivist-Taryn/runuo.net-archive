using System; 
using Server;
using Server.Mobiles;

namespace Server.Commands
{
	public class SpeechCommands
	{
		public static void Initialize()
		{
            CommandSystem.Register("speakdrow", AccessLevel.Player, new CommandEventHandler(SpeakDrow_OnCommand));
            CommandSystem.Register("speakelven", AccessLevel.Player, new CommandEventHandler(SpeakElven_OnCommand));
            CommandSystem.Register("speakorc", AccessLevel.Player, new CommandEventHandler(SpeakOrc_OnCommand));
            CommandSystem.Register("speakundead", AccessLevel.Player, new CommandEventHandler(SpeakUndead_OnCommand));
            CommandSystem.Register("speakcommon", AccessLevel.Player, new CommandEventHandler(SpeakCommon_OnCommand));
            CommandSystem.Register("speakdruidic", AccessLevel.Player, new CommandEventHandler(SpeakDruidic_OnCommand));
            CommandSystem.Register("speakumbravox", AccessLevel.Player, new CommandEventHandler(SpeakUmbravox_OnCommand));
            CommandSystem.Register("speakabyssal", AccessLevel.Player, new CommandEventHandler(SpeakAbyssal_OnCommand));
		}
		
		[Usage( "SpeakAbyssal" )]
		[Description( "Allows you to speak in an ancient Demonic tongue." )]
		private static void SpeakAbyssal_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			if (player.KnowAbyssal)
			{
				player.LanguageSpeaking = SpeechType.Abyssal;
				player.SendMessage("You can now speak in the ancient Demonic tongue.");
			}
			else
				player.SendMessage("You do not know that language!");
		}
		
		
		
		[Usage( "SpeakDruidic" )]
		[Description( "Allows you to speak in the ancient Druidic tongue." )]
		private static void SpeakDruidic_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			if (player.KnowDruidic)
			{
				player.LanguageSpeaking = SpeechType.Druidic;
				player.SendMessage("You can now speak in the ancient Druidic tongue.");
			}
			else
				player.SendMessage("You do not know that language!");
		}
		
		[Usage( "SpeakUmbravox" )]
		[Description( "Allows you to communicate using gestures and hand movements." )]
		private static void SpeakUmbravox_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			if (player.KnowUmbravox)
			{
				player.LanguageSpeaking = SpeechType.Umbravox;
				player.SendMessage("You can now communicate using gestures and hand movements.");
			}
			else
				player.SendMessage("You do not know that language!");
		}
		
		
		
		
		
		[Usage( "SpeakDrow" )]
		[Description( "Allows you to speak in the drow tongue." )]
		private static void SpeakDrow_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			if (player.KnowDrow)
			{
				player.LanguageSpeaking = SpeechType.Drow;
				player.SendMessage("You can now speak in the drow tongue.");
			}
			else
				player.SendMessage("You do not know that language!");
		}
		
		[Usage( "SpeakElven" )]
		[Description( "Allows you to speak in the elven tongue." )]
		private static void SpeakElven_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			if (player.KnowElven)
			{
				player.LanguageSpeaking = SpeechType.Elven;
				player.SendMessage("You can now speak in the elven tongue.");
			}
			else
				player.SendMessage("You do not know that language!");
		}
		
		[Usage( "SpeakOrc" )]
		[Description( "Allows you to speak in the orcish tongue." )]
		private static void SpeakOrc_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			if (player.KnowOrc)
			{
				player.LanguageSpeaking = SpeechType.Orc;
				player.SendMessage("You can now speak in the orc tongue.");
			}
			else
				player.SendMessage("You do not know that language!");
		}
		
		[Usage( "SpeakUndead" )]
		[Description( "Allows you to speak to the undead." )]
		private static void SpeakUndead_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			if (player.KnowUndead)
			{
				player.LanguageSpeaking = SpeechType.Undead;
				player.SendMessage("You can now speak to the undead.");
			}
			else
				player.SendMessage("You do not know that language!");
		}
		
		[Usage( "SpeakCommon" )]
		[Description( "Allows you to speak in the common tongue." )]
		private static void SpeakCommon_OnCommand( CommandEventArgs e )
		{
			PlayerMobile player = e.Mobile as PlayerMobile;
			
			player.LanguageSpeaking = SpeechType.Common;
			player.SendMessage("You are now speaking the Common tongue.");
		}
		
	}
}
