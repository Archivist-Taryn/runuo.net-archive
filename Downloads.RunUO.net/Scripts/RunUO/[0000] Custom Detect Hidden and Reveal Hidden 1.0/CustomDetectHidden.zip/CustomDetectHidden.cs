using System;
using Server;
using Server.Multis;
using Server.Targeting;
using Server.Items;
using Server.Regions;
using System.Collections;
using Server.Mobiles;

namespace Server.SkillHandlers
{
	public class CustomDetectHidden
	{
		
		public static void Initialize()
		{
			Server.Commands.Register( "detect", AccessLevel.Player, new CommandEventHandler( Detection ) );
			Server.Commands.Register( "reveal", AccessLevel.Player, new CommandEventHandler( Revealing ) );
		}
		
		[Usage( "Detect" )]
		[Description( "Allows you to detect hidden creatures near you. Does not require line of sight." )]
		private static void Detection(CommandEventArgs e)
		{
			int range = 22;
			Mobile src = e.Mobile;
			double srcSkill = src.Skills[SkillName.DetectHidden].Value;
			bool detectedanyone = false;
			
			if ( !src.CheckSkill( SkillName.DetectHidden, 0.0, 100.0 ) )
				range = 0;
			
			if ( range > 0 )
			{
				ArrayList inRangeArray = new ArrayList();
				
				foreach ( Mobile trg in src.GetMobilesInRange( range ) )
				{
					if( trg is PlayerMobile )
					{
						PlayerMobile test = trg as PlayerMobile;
						
						if ( trg.Hidden && src != trg )
						{
							double ss = srcSkill + Utility.Random( 21 ) - 10;
							double ts = trg.Skills[SkillName.Hiding].Value + Utility.Random( 21 ) - 10;
							if ( (src.AccessLevel >= trg.AccessLevel) && (ss >= ts) )
							{
								detectedanyone = true;
								Detecting(src, trg);
								inRangeArray.Add(trg);
							}
						}
					}
				}
				
				if(detectedanyone)
					src.SendMessage("You detect someone nearby!");
				else
					src.SendMessage("You didn't detect anyone nearby.");
				
				InternalTimer pause = new InternalTimer( src, inRangeArray );
				pause.Start();
				
			}
		}
		
		
		
		private static void Detecting(Mobile from, Mobile targ)
		{
			
			PlayerMobile pm = (PlayerMobile)targ;
			
			ArrayList list = pm.VisibilityList;
			
			list.Add( from );
			
			if ( Utility.InUpdateRange( from, targ ) )
			{
				if ( from.CanSee( targ ) )
				{
					from.Send( new Network.MobileIncoming( from, targ ) );
					//from.SendMessage("You have detected " + targ.Name);
				}
			}
		}
		
		[Usage( "Reveal" )]
		[Description( "Reveals creatures that are hidden near you. Requires line of sight." )]
		private static void Revealing(CommandEventArgs e)
		{
			PlayerMobile m_From = e.Mobile as PlayerMobile;
			
			m_From.RevealingAction();
			
			Rev(e.Mobile, e.Mobile);
		}
		
		private static void Rev( Mobile src, object targ )
		{
			bool foundAnyone = false;
			
			Point3D p;
			p = ((Mobile)targ).Location;
			
			double srcSkill = src.Skills[SkillName.DetectHidden].Value;
			int range = (int)(srcSkill / 10.0);
			
			if ( !src.CheckSkill( SkillName.DetectHidden, 0.0, 100.0 ) )
				range /= 2;
			
			BaseHouse house = BaseHouse.FindHouseAt( p, src.Map, 16 );
			
			bool inHouse = ( house != null && house.IsFriend( src ) );
			
			if ( inHouse )
				range = 22;
			
			if ( range > 0 )
			{
				foreach ( Mobile trg in src.GetMobilesInRange( range ) )
				{
					if ( trg.Hidden && src != trg )
					{
						double ss = srcSkill + Utility.Random( 21 ) - 10;
						double ts = trg.Skills[SkillName.Hiding].Value + Utility.Random( 21 ) - 10;
						
						if ( (src.AccessLevel >= trg.AccessLevel) && ( (ss >= ts) || ( inHouse && house.IsInside( trg ) )) && (src.InLOS(trg)) )
						{
							trg.RevealingAction();
							trg.SendLocalizedMessage( 500814 ); // You have been revealed!
							foundAnyone = true;
						}
					}
				}
			}
			
			if ( !foundAnyone )
			{
				src.SendLocalizedMessage( 500817 ); // You can see nothing hidden there.
			}
			else
				src.SendMessage("You find someone in the shadows!");
		}
		
		
		private class InternalTimer : Timer
		{
			private Mobile m_From;
			private ArrayList m_InRange;
			
			public InternalTimer( Mobile from, ArrayList inRange2 ) : base( TimeSpan.FromSeconds( 10.0 ) )
			{
				m_From = from;
				m_InRange = inRange2;		
			}
			
			protected override void OnTick()
			{
				foreach( Mobile target in m_InRange )
				{
					Mobile TargetMobile = target;
					PlayerMobile TargetPlayerMobile = target as PlayerMobile;
					
					TargetPlayerMobile.VisibilityList.Remove(m_From);
					
					if ( TargetMobile.Hidden && m_From != TargetPlayerMobile )
					{
						if ( !m_From.CanSee( TargetPlayerMobile ) && Utility.InUpdateRange( m_From, TargetMobile ) )
							m_From.Send( TargetPlayerMobile.RemovePacket );
					}
				}
				m_InRange.Clear();
			}
		}
		
	}
}
