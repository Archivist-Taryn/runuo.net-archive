using System;
using Ultima;

namespace Server.Bestiary
{
	public sealed class BeastInfo
	{
		private string m_name;
		private string m_bgFile;
		
		public string Name { get { return m_name; } set { m_name = value; } }
		public string Background { get { return m_bgFile; } set { m_bgFile = value; } }
		
		public BeastInfo(string name)
		{
			m_name = name;
		}
	}
}