using System;
using System.Collections;
using System.Collections.Generic;
using Server.Items;
using Server.Targeting;
using Server.Mobiles;
using System.IO;
using System.Xml;

namespace Server.Bestiary
{
	public static class Bestiary
	{
		public static Dictionary<Type, BeastInfo> TypeRegistry = new Dictionary<Type, BeastInfo> ();	
			
		public static void Generate()
		{
			Alphabetctionary<List<MobileEntry>> entries = new Alphabetctionary<List<MobileEntry>>();
			List<MobileEntry>           all                 = new List<MobileEntry>();

			// initialize alphabetctionaries' collections.
			foreach( char c in Alphabetctionary<List<MobileEntry>>.m_Alphabet )
            {
                entries[c] = new List<MobileEntry>();
            }

			foreach( Type type in TypeRegistry.Keys )
			{
                MobileEntry entry = new MobileEntry( type );

				if( !entry.GuessEmpty )
				{                    
                    entries[TypeRegistry[type].Name[0]].Add(entry);
				}
			}

            foreach (List<MobileEntry> list in entries) 
            { 
                all.AddRange(list); 
            }
			
			using( StreamWriter writer = new StreamWriter( Path.Combine( "./Bestiary/", "index.html" ) ) )
			{		
				int index = 0;

				foreach( char c in Alphabetctionary<List<MobileEntry>>.m_Alphabet )
				{
                    List<MobileEntry> hit = entries[c];

                    if (hit.Count != 0)
					{				
						writer.WriteLine( "<font size=\"4\">{0}</font> ({1} {2})", c, hit.Count, (hit.Count == 1 ? "mobile" : "mobiles") );
						writer.WriteLine( "	<div style=\"padding-left: 15px\">" );
						
						foreach( MobileEntry entry in hit )
						{
							writer.WriteLine( "		<a href=\"./content/mobile.{0}.html\">{1}</a><br />", entry.MasterType.Name, entry.Name );
							
							if ( index != 0 && all.Count != 1 )
							{
								entry.PrevLink = string.Format( "		<a href=\"mobile.{0}.html\" style=\"font-weight: bold; font-size: 11px; color: #ccc\">&lt; {1}</a>", all[ index - 1 ].MasterType.Name, all[ index - 1 ].Name );
							}
							
							if ( ( index + 1) != all.Count )
							{
								entry.NextLink = string.Format( "		<a href=\"mobile.{0}.html\" style=\"font-weight: bold; font-size: 11px; color: #ccc\">{1} &gt;</a>", all[ index + 1 ].MasterType.Name, all[ index + 1 ].Name );
							}
							
							using( StreamWriter entryWriter = new StreamWriter( Path.Combine( "./Bestiary/content/", string.Format( "mobile.{0}.html", entry.MasterType.Name ) ) ) )	
							{ 
								entryWriter.Write( entry.Html );
							}
							
							++index;
						}
						
						writer.WriteLine( "	</div>" );
						writer.WriteLine( "	<hr noshade />" );
					}
				}
			}
		
			// all mobiles, unless they're empty, have been indexed. Our job's done!
		}
		
		public static bool UseFixes = false;

		public static void ReadXMLList()
		{
			string filePath = Path.Combine( "Data/Bestiary", "data.xml" );

			if( !File.Exists( filePath ) )
				return;

			XmlDocument doc = new XmlDocument();
			doc.Load( filePath );

			XmlElement root = doc[ "mobiles" ];
			
			UseFixes = bool.Parse( Utility.GetAttribute( root, "useFixes",  "false") );

			foreach( XmlElement mobile in root.GetElementsByTagName( "mobile" ) )
			{
				string typeName = Utility.GetAttribute( mobile, "type", null );
				Type t = Type.GetType( typeName );
				
				if( t == null )
				{
					Console.WriteLine("Mobile type: {0} doesn't exist. Skipping.", typeName);
					continue;
				}
				
				string name = Utility.GetAttribute( mobile, "name", "empty" );
				string background = Utility.GetAttribute( mobile, "background", null );
				
				BeastInfo bi = new BeastInfo( name );
				
				if( background != null )
				{
					bi.Background = background;
				}
				
				TypeRegistry.Add( t, bi );
			}
		}

		public static void Initialize()
		{
			ReadXMLList();
			Generate();
		}
	}
}