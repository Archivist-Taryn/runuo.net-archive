﻿/*****************************************************************************************************************************
 * 
 * Slayer Title Core
 * Version 2.5
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 2/5/2013
 * 
* The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
  * 
 ****************************************************************************************************************************/

using System;
using System.Collections.Generic;

using Server;
using Server.Gumps;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace CustomsFramework.Systems.SlayerTitleSystem
{
    public class SlayerTitleCore : BaseCore
    {
        #region Event Handlers
        public delegate void KilledByEventHandler(BaseCreature creature, PlayerMobile player);
        public delegate void PostPrepEventHandler(BaseCore core);
        public delegate void SlayerTitleAwardedEventHandler(Mobile from, string titleSystem, string titleAwarded);

        public static event KilledByEventHandler KilledByEvent;
        public static event PostPrepEventHandler PostPrep;
        public static event SlayerTitleAwardedEventHandler SlayerTitleAwarded;
        public static event SlayerTitleAwardedEventHandler MaxSlayerTitleAchieved;

        public static void OnKilledByEvent(BaseCreature creature, PlayerMobile player)
        {
            if (KilledByEvent != null)
                KilledByEvent(creature, player);
        }
        #endregion

        private static Dictionary<String, List<Type>> m_CreatureRegistry = new Dictionary<String, List<Type>>();
        private static Dictionary<String, List<TitleEntry>> m_TitleRegistry = new Dictionary<String, List<TitleEntry>>();

        public const String SystemVersion = "2.5";

        public SlayerTitleCore() : base()
        {
            this.Enabled = true;
        }

        public SlayerTitleCore(CustomSerial serial)
            : base(serial)
        {
        }

        public override String Name
        {
            get
            {
                return "Slayer Title Core";
            }
        }

        public override String Description
        {
            get
            {
                return "Core that contains everything for the Slayer Title System.";
            }
        }

        public override String Version
        {
            get
            {
                return SystemVersion;
            }
        }

        public override AccessLevel EditLevel
        {
            get
            {
                return AccessLevel.Developer;
            }
        }

        public override Gump SettingsGump
        {
            get
            {
                return null;
            }
        }

        public static void Initialize()
        {
            SlayerTitleCore core = World.GetCore(typeof(SlayerTitleCore)) as SlayerTitleCore;

            if (core == null)
            {
                core = new SlayerTitleCore();
                core.Prep();
            }
        }

        public override void Prep() // Called after all cores are loaded
        {
            // See note regarding installing the OnKilledBy hook in BaseCreature.cs at the bottom of this script
            SlayerTitleCore.KilledByEvent += SlayerTitleCore_KilledByEvent;

            if (PostPrep != null)
                PostPrep(this);
        }

        public void RegisterTitleSystem(String titleName, List<Type> creatureTypes, List<TitleEntry> titleEntries)
        {
            if (m_CreatureRegistry.ContainsKey(titleName) || m_TitleRegistry.ContainsKey(titleName))
                return;

            m_CreatureRegistry[titleName] = creatureTypes;
            m_TitleRegistry[titleName] = titleEntries;
        }

        private void SlayerTitleCore_KilledByEvent(BaseCreature creature, PlayerMobile player)
        {
            if (!this.Enabled)
                return;

            // Manual module lookup until next commit of FortkUO
            List<BaseModule> results = World.GetModules(player);

            SlayerModule module = null;

            foreach (BaseModule mod in results)
            {
                if (mod is SlayerModule)
                {
                    module = (SlayerModule)mod;
                    break;
                }
            }

            //SlayerModule module = player.GetModule(typeof(SlayerModule)) as SlayerModule;

            if (module == null)
                module = new SlayerModule(player);

            foreach (KeyValuePair<String, List<Type>> pair in m_CreatureRegistry)
            {
                if (pair.Value.Contains(creature.GetType()))
                {
                    List<TitleEntry> entries = null;
                    m_TitleRegistry.TryGetValue(pair.Key, out entries);

                    if (entries != null)
                    {
                        module.IncrementCounter(pair.Key);

                        Int32 value = module.GetSlayerCount(pair.Key);
                        TitleEntry titleToSet = null;

                        foreach (TitleEntry entry in entries)
                            if (entry.CountNeeded == value)
                                titleToSet = entry;

                        if (titleToSet != null)
                        {
                            foreach (TitleEntry entry in entries)
                                if (player.CollectionTitles.Contains(entry.Title) && entry != titleToSet)
                                    player.CollectionTitles.Remove(entry.Title);

                            player.AddCollectionTitle(titleToSet.Title);
                            player.SendSound(0x3D);
                            player.SendMessage(0xC8, String.Format("Your have been awarded the title of '{0}' for {1} kills.", titleToSet.Title, value));

                            if (SlayerTitleAwarded != null)
                                SlayerTitleAwarded(player, pair.Key, titleToSet.Title);

                            if (IsMaxTitle(titleToSet.Title, entries) && MaxSlayerTitleAchieved != null)
                                MaxSlayerTitleAchieved(player, pair.Key, titleToSet.Title);

                        }
                    }
                }
            }
        }

        private Boolean IsMaxTitle(String title, List<TitleEntry> entries)
        {
            Int32 maxCount = 0;
            Int32 titleCount = 0;

            foreach (TitleEntry entry in entries)
            {
                if (entry.CountNeeded > maxCount)
                    maxCount = entry.CountNeeded;

                if (entry.Title == title)
                    titleCount = entry.CountNeeded;
            }

            if (titleCount == maxCount)
                return true;
            else
                return false;
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            Utilities.WriteVersion(writer, 0);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();

            switch (version)
            {
                case 0:
                    break;
            }
        }
    }
}