﻿/*****************************************************************************************************************************
 * 
 * Slayer Title Core - Examples
 * Version 2.5
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/31/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
 * 
 ****************************************************************************************************************************/

using System;
using System.Collections.Generic;

using Server;
using Server.Items;
using Server.Mobiles;

using CustomsFramework.Systems.SlayerTitleSystem;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL SLAYER TITLE GROUPS ///

namespace Dougan.SlayerTitle.Examples
{
    public class SlayerTitleExamples
    {
        public static void Configure()
        {
            SlayerTitleCore.PostPrep += SlayerTitleCore_PostPrep;
            SlayerTitleCore.MaxSlayerTitleAchieved += SlayerTitleCore_MaxSlayerTitleAchieved;
        }

        static void SlayerTitleCore_PostPrep(CustomsFramework.BaseCore core)
        {
            if (core is SlayerTitleCore)
            {
                // Sheep Slayer Titles
                ((SlayerTitleCore)core).RegisterTitleSystem("Sheep Slayer",
                    new List<Type>()
                    {
                        typeof(Sheep) 
                    },
                    new List<TitleEntry>()
                    {
                        new TitleEntry("Hunter of Mutton", 50),
                        new TitleEntry("Master of the Feast", 100),
                        new TitleEntry("Mammoth of the Wool", 250)
                    });

                // Dragon Slayer Titles
                ((SlayerTitleCore)core).RegisterTitleSystem("Dragon Slayer",
                    new List<Type>()
                    {
                        typeof(Wyvern),
                        typeof(Drake),
                        typeof(Dragon),
                        typeof(WyvernRenowned),
                        typeof(WhiteWyrm),
                        typeof(ShadowWyrm),
                        typeof(AncientWyrm),
                        typeof(StygianDragon),
                        typeof(CrimsonDragon),
                        typeof(GreaterDragon),
                        typeof(SerpentineDragon),
                        typeof(SkeletalDragon)
                    },
                    new List<TitleEntry>()
                    {
                        new TitleEntry("Apprentice Dragonslayer", 50),
                        new TitleEntry("Accomplished Dragon Hunter", 250),
                        new TitleEntry("Master of the Leather Winged", 1000),
                        new TitleEntry("Terror of the Skyborn", 5000)
                    });
            }
        }

        public static void SlayerTitleCore_MaxSlayerTitleAchieved(Mobile from, String titleSystem, String titleAwarded)
        {
            if (!from.IsPlayer())
                return;

            // Award a dragon statuette when the maximum Dragon Slayer title is achieved
            if (titleSystem == "Dragon Slayer")
            {
                MonsterStatuette statue = new MonsterStatuette(MonsterStatuetteType.Dragon);

                if (!from.PlaceInBackpack(statue))
                {
                    from.BankBox.AddItem(statue);

                    from.SendMessage("A reward statue has been placed in your bankbox.");
                }
                else
                {
                    from.SendMessage("A reward statue has been placed in your backpack.");
                }
            }
        }
    }
}
