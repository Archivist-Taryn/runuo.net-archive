using System;
using System.Collections;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Spells;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SpidersToxicBiteSpell : DarkElfSpell
	{
		private static SpellInfo m_Info = new SpellInfo(
		                                                "Spiders Toxic Bite", "spi fan bite",
		                                                //SpellCircle.Fifth,
		                                                212,
		                                                9041,
		                                                CReagent.Kindling,
		                                                CReagent.LethalVenom
		                                               );

        public override SpellCircle Circle
        {
            get { return SpellCircle.Fifth; }
        }

		public override double CastDelay{ get{ return 7.0; } }
		public override double RequiredSkill{ get{ return 95.0; } }
		public override int RequiredMana{ get{ return 85; } }

		public SpidersToxicBiteSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				if(this.Scroll!=null)
					Scroll.Consume();

				Item weap = new SpidersToxicBite( Caster );

				Caster.AddToBackpack( weap );
				Caster.SendMessage( "You summon a spider to your weapon and place it in your backpack." );

				Caster.PlaySound( 0x107 );

				Effects.SendLocationParticles( EffectItem.Create( Caster.Location, Caster.Map, EffectItem.DefaultDuration ), 0x376A, 1, 29, 1266, 2, 9962, 0 );
				Effects.SendLocationParticles( EffectItem.Create( new Point3D( Caster.X, Caster.Y, Caster.Z - 7 ), Caster.Map, EffectItem.DefaultDuration ), 0x37C4, 1, 29, 1266, 2, 9502, 0 );
			}
		}

		[FlipableAttribute( 0xDF1, 0xDF0 )]
		public class SpidersToxicBite : BaseStaff
		{
			private Mobile m_Owner;
			private DateTime m_Expire;
			private Timer m_Timer;

			public override WeaponAbility PrimaryAbility{ get{ return WeaponAbility.WhirlwindAttack; } }
      public override WeaponAbility SecondaryAbility{ get{ return WeaponAbility.ParalyzingBlow; } }

      public override int AosStrengthReq{ get{ return 35; } }
      public override int AosMinDamage{ get{ return 40; } }
      public override int AosMaxDamage{ get{ return 50; } }
      public override int AosSpeed{ get{ return 39; } }

      public override int OldStrengthReq{ get{ return 35; } }
      public override int OldMinDamage{ get{ return 8; } }
      public override int OldMaxDamage{ get{ return 33; } }
      public override int OldSpeed{ get{ return 35; } }

      public override int InitMinHits{ get{ return 40; } }
      public override int InitMaxHits{ get{ return 90; } }

			[Constructable]
			public SpidersToxicBite( Mobile owner ) : base( 0xDF1 )

			{
				WeaponAttributes.HitPoisonArea = 100;
				m_Owner = owner;
				Weight = 20.0;
				Layer = Layer.TwoHanded;
				Hue = 816;
				BlessedFor = owner;
				Name = "Spider's toxic bite";

				double time = ( owner.Skills[SkillName.Macing].Value / 25.0 ) * ToxicVenomSpell.GetScalar( owner );
				m_Expire = DateTime.Now + TimeSpan.FromMinutes( (int)time );
				m_Timer = new InternalTimer( this, m_Expire );

				m_Timer.Start();
			}

			public override void GetDamageTypes( Mobile wielder, out int phys, out int fire, out int cold, out int pois, out int nrgy )
			{
				phys = 0; fire = 0; cold = 0; pois = 100;
				nrgy = 0;
			}

			public override bool CanEquip( Mobile m )
			{
				if ( m != m_Owner )
					return false;

				return true;
			}

			public void Remove()
			{
				m_Owner.SendMessage( "Your weapon's venom slowly dissipates." );
				Delete();
			}

			public SpidersToxicBite( Serial serial ) : base( serial )
			{
			}
			public override void AddNameProperties( ObjectPropertyList list )
			{
				base.AddNameProperties( list );

				list.Add( 1049644, "Temparary Spell Enchantment" );
			}

			public override void Serialize( GenericWriter writer )
			{
				base.Serialize( writer );

				writer.Write( (int) 0 ); // version
				writer.Write( m_Owner );
				writer.Write( m_Expire );
			}

			public override void Deserialize( GenericReader reader )
			{
				base.Deserialize( reader );

				int version = reader.ReadInt();
				m_Owner = reader.ReadMobile();
				m_Expire = reader.ReadDeltaTime();

				m_Timer = new InternalTimer( this, m_Expire );
				m_Timer.Start();
			}
		}

		private class InternalTimer : Timer
		{
			private SpidersToxicBite m_staff;
			private DateTime m_Expire;

			public InternalTimer( SpidersToxicBite staff, DateTime expire ) : base( TimeSpan.Zero, TimeSpan.FromSeconds( 0.1 ) )
			{
				m_staff = staff;
				m_Expire = expire;
			}

			protected override void OnTick()
			{
				if ( DateTime.Now >= m_Expire )
				{
					m_staff.Remove();
					Stop();
				}
			}
		}
	}
}
