using System;
using Server;

namespace Server.ACC.CSS.Systems.DarkElf
{
    public class DarkElfInitializer : BaseInitializer
    {
		public static void Configure()
		{
            Register( typeof( DarkElfSpidersFangSpell ),        "Dark Elf Spiders Fang Spell",    "Summons a fang from a spider.",                "Kindling; Venom",                                            "Mana: 10; Skill: 30",  2271,  5120, School.DarkElf );
            Register( typeof( SummonedGiantSpiderSpell ),       "Summon Giant Spider Spell",      "Summons a giant spider to aid you.",           "GraveDust; Venom",                                           "Mana: 5; Skill: 10",   2271,  5120, School.DarkElf );
            Register( typeof( SummonedTerathanDroneSpell ),     "Summon Terathan Drone Spell",    "Summons a terathan drone to fight with you.",  "GraveDust; Petrafied Wood; Venom",                           "Mana: 5; Skill: 0",    2271,  5120, School.DarkElf );
            Register( typeof( SpiderBiteSpell ),                "Spider Bite Spell",              "Bites target.",                                "Nightshade; Venom",                                          "Mana: 15; Skill: 20",  2271,  5120, School.DarkElf );
            Register( typeof( SummonedFrostSpiderSpell ),       "Summon Frost Spider Spell",      "Summons a frost spider to help.",              "NoxCrystal; Venom",                                          "Mana: 15; Skill: 20",  2271,  5120, School.DarkElf );
            Register( typeof( SummonedTerathanWarriorSpell ),   "Summon Terathan Warrior Spell",  "Summons a terathan warrior to join you.",      "GraveDust; Venom; GraveDust",                                "Mana: 20; Skill: 28",  2271,  5120, School.DarkElf );
            Register( typeof( VenomSpell ),                     "Venom Spell",                    "Adds venom attack to spiders fang.",           "Nightshade; Venom; Bloodmoss",                               "Mana: 25; Skill: 25",  2271,  5120, School.DarkElf );
            Register( typeof( DarkElfSpidersSpitSpell ),        "Dark Elf Spiders Spit Spell",    "Summons a powerful bow crafted by spiders.",   "Kindling; Venom; SpidersSilk",                               "Mana: 30; Skill: 40",  2271,  5120, School.DarkElf );
            Register( typeof( DeadlyVenomSpell ),               "Deadly Venom Spell",             "Adds deadly venom to spiders spit",            "Nightshade; Venom; SpidersSilk",                             "Mana: 45; Skill: 50",  2271,  5120, School.DarkElf );
            Register( typeof( SummonedDreadSpiderSpell ),       "Summon Dread Spider Spell",      "Summons a powerful dread spider to aid you.",  "GraveDust; Petrafied Wood; Venom",                           "Mana: 25; Skill: 55",  2271,  5120, School.DarkElf );
            Register( typeof( SummonedTerathanMatriarchSpell ), "Summon Terathan Matriarch Spell","Summons a Terathan Matriarch to cast magic.",  "GraveDust; SpidersSilk; LethalVenom",                        "Mana: 30; Skill: 60",  2271,  5120, School.DarkElf );
            Register( typeof( SummonedTerathanAvengerSpell ),   "Summon Terathan Avenger Spell",  "Summons a powerful Terathan Avenger.",         "GraveDust; LethalVenom",                                     "Mana: 35; Skill: 65",  2271,  5120, School.DarkElf );
            Register( typeof( SpidersWebSpell ),                "Spiders Web Spell",              "Spins a web to trap your prey.",               "SpidersSilk; LethalVenom",                                   "Mana: 45; Skill: 70",  2271,  5120, School.DarkElf );
            Register( typeof( EvolutionDarkElfSpiderSpell ),    "Evolution Dark Elf Spider Spell","Summons a Evo spider.",                        "GraveDust; Petrafied Wood; Venom; LethalVenom; SpidersSilk", "Mana: 60; Skill: 85",  2271,  5120, School.DarkElf );
            Register( typeof( SpidersVenomusBiteSpell ),        "Spiders Venomus Bite Spell",     "Bites and infects victom with lethal venom.",  "Nightshade; LethalVenom",                                    "Mana: 85; Skill: 100", 2271,  5120, School.DarkElf );
            Register( typeof( SpidersToxicBiteSpell ),          "Spiders Toxic Bite Spell",       "Summons a powerful Staff crafted by spiders.", "Kindling; LethalVenom",                                      "Mana: 85; Skill: 95",  2271,  5120, School.DarkElf );
            Register( typeof( ToxicVenomSpell ),                "Toxic Venom Spell",              "Immbunes your Toxic Bite with venom.",         "Nightshade; Venom; LethalVenom",                             "Mana: 70; Skill: 90",  2271,  5120, School.DarkElf );      
		}
	}
}
