using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SummonedTerathanDroneScroll : CSpellScroll
	{
		[Constructable]
		public SummonedTerathanDroneScroll() : this( 1 )
		{
		}

		[Constructable]
		public SummonedTerathanDroneScroll( int amount ) : base( typeof( SummonedTerathanDroneSpell ), 0xE39, amount )
		{
			Name = "Summoned Terathan Drone Scroll";
			Hue = 816;
		}

		public SummonedTerathanDroneScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
