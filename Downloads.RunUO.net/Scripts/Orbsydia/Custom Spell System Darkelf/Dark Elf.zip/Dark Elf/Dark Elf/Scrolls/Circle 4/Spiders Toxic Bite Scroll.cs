using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SpidersToxicBiteScroll : CSpellScroll
	{
		[Constructable]
		public SpidersToxicBiteScroll() : this( 1 )
		{
		}

		[Constructable]
		public SpidersToxicBiteScroll( int amount ) : base( typeof( SpidersToxicBiteSpell ), 0xE39, amount )
		{
			Name = "Spiders Toxic Bite Scroll";
			Hue = 816;
		}

		public SpidersToxicBiteScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
