using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class DeadlyVenomScroll : CSpellScroll
	{
		[Constructable]
		public DeadlyVenomScroll() : this( 1 )
		{
		}

		[Constructable]
		public DeadlyVenomScroll( int amount ) : base( typeof( DeadlyVenomSpell ), 0xE39, amount )
		{
			Name = "Deadly Venom Scroll";
			Hue = 816;
		}

		public DeadlyVenomScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
