using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SummonedTerathanAvengerScroll : CSpellScroll
	{
		[Constructable]
		public SummonedTerathanAvengerScroll() : this( 1 )
		{
		}

		[Constructable]
		public SummonedTerathanAvengerScroll( int amount ) : base( typeof( SummonedTerathanAvengerSpell ), 0xE39, amount )
		{
			Name = "Summoned Terathan Avenger scroll";
			Hue = 816;
		}

		public SummonedTerathanAvengerScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
