using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class ToxicVenomScroll : CSpellScroll
	{
		[Constructable]
		public ToxicVenomScroll() : this( 1 )
		{
		}

		[Constructable]
		public ToxicVenomScroll( int amount ) : base( typeof( ToxicVenomSpell ), 0xE39, amount )
		{
			Name = "Toxic Venom Scroll";
			Hue = 816;
		}

		public ToxicVenomScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
