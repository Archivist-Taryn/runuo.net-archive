using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SummonedTerathanMatriarchScroll : CSpellScroll
	{
		[Constructable]
		public SummonedTerathanMatriarchScroll() : this( 1 )
		{
		}

		[Constructable]
		public SummonedTerathanMatriarchScroll( int amount ) : base( typeof( SummonedTerathanMatriarchSpell ), 0xE39, amount )
		{
			Name = "Summoned Terathan Matriarch Scroll";
			Hue = 816;
		}

		public SummonedTerathanMatriarchScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
