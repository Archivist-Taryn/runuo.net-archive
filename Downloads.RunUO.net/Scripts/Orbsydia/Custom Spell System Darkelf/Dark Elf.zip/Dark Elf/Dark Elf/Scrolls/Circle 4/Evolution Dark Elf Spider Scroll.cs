using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class EvolutionDarkElfSpiderScroll : CSpellScroll
	{
		[Constructable]
		public EvolutionDarkElfSpiderScroll() : this( 1 )
		{
		}

		[Constructable]
		public EvolutionDarkElfSpiderScroll( int amount ) : base( typeof( EvolutionDarkElfSpiderSpell ), 0xE39, amount )
		{
			Name = "Evolution Dark Elf Spider Scroll";
			Hue = 816;
		}

		public EvolutionDarkElfSpiderScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
