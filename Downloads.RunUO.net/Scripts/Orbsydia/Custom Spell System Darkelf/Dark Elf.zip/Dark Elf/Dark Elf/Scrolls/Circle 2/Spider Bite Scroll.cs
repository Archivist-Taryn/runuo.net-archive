using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SpiderBiteScroll : CSpellScroll
	{
		[Constructable]
		public SpiderBiteScroll() : this( 1 )
		{
		}

		[Constructable]
		public SpiderBiteScroll( int amount ) : base( typeof( SpiderBiteSpell ), 0xE39, amount )
		{
			Name = "Spider Bite scroll";
			Hue = 816;
		}

		public SpiderBiteScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
