using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SummonedGiantSpiderScroll : CSpellScroll
	{
		[Constructable]
		public SummonedGiantSpiderScroll() : this( 1 )
		{
		}

		[Constructable]
		public SummonedGiantSpiderScroll( int amount ) : base( typeof( SummonedGiantSpiderSpell ), 0xE39, amount )
		{
			Name = "Summoned Giant Spider Scroll";
			Hue = 816;
		}

		public SummonedGiantSpiderScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
