using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class SpidersVenomusBiteScroll : CSpellScroll
	{
		[Constructable]
		public SpidersVenomusBiteScroll() : this( 1 )
		{
		}

		[Constructable]
		public SpidersVenomusBiteScroll( int amount ) : base( typeof( SpidersVenomusBiteSpell ), 0xE39, amount )
		{
			Name = "Spiders Venomus Bite Scroll";
			Hue = 816;
		}

		public SpidersVenomusBiteScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
