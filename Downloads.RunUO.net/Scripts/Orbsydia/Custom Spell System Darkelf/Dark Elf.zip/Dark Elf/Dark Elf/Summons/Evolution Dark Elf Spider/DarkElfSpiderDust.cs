using System; 
using Server.Items; 

namespace Server.Items 
{ 
   	public class DarkElfSpiderDust: Item 
   	{ 
		[Constructable]
		public DarkElfSpiderDust() : this( 1 )
		{
		}

		[Constructable]
		public DarkElfSpiderDust( int amount ) : base( 0x26B8 )
		{
			Stackable = true;
			Weight = 0.5;
			Amount = amount;
			Name = "venom";
			Hue = 613;
		}

            	public DarkElfSpiderDust( Serial serial ) : base ( serial ) 
            	{             
           	} 

           	public override void Serialize( GenericWriter writer ) 
           	{ 
              		base.Serialize( writer ); 
              		writer.Write( (int) 0 ); 
           	} 
            
           	public override void Deserialize( GenericReader reader ) 
           	{ 
              		base.Deserialize( reader ); 
              		int version = reader.ReadInt(); 
           	} 
        } 
} 