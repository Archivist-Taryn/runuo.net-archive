using System;
using System.Collections; 
using Server.Mobiles;
using Server.Items;
using Server.Network; 
using Server.Targeting;
using Server.Gumps;

namespace Server.ACC.CSS.Systems.DarkElf
{
	[CorpseName( "a spider's corpse" )]
	public class EvolutionDarkElfSpider : BaseCreature
	{
		
		public int m_Stage;
		public int m_KPDarkElfSpider;

		public bool m_S1;
		public bool m_S2;
		public bool m_S3;
		public bool m_S4;
		public bool m_S5;

		public bool S1
		{
			get{ return m_S1; }
			set{ m_S1 = value; }
		}
		public bool S2
		{
			get{ return m_S2; }
			set{ m_S2 = value; }
		}
		public bool S3
		{
			get{ return m_S3; }
			set{ m_S3 = value; }
		}
		public bool S4
		{
			get{ return m_S4; }
			set{ m_S4 = value; }
		}
		public bool S5
		{
			get{ return m_S5; }
			set{ m_S5 = value; }
		}		

		[CommandProperty( AccessLevel.GameMaster )]
		public int KPDarkElfSpider
		{
			get{ return m_KPDarkElfSpider; }
			set{ m_KPDarkElfSpider = value; }
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public int Stage
		{
			get{ return m_Stage; }
			set{ m_Stage = value; }
		}

		[Constructable]
		public EvolutionDarkElfSpider() : this( "Summoned" )
		{
		}

		[Constructable]
		public EvolutionDarkElfSpider( string name ) : base( AIType.AI_Mage, FightMode.Closest, 10, 1, 0.2, 0.4 )
		{
			Name = "Spider";
			Body = 28;
			BaseSoundID = 0x388;
			Stage = 1;

			S1 = true;
			S2 = true;
			S3 = true;
			S4 = true;
			S5 = true;

			SetStr( 20, 40 );
			SetDex( 10, 20 );
			SetInt( 10, 20 );

			SetHits( 30, 40 );

			SetDamage( 1, 5 );

			SetDamageType( ResistanceType.Physical, 100 );

			SetResistance( ResistanceType.Physical, 15 );

			SetSkill( SkillName.Anatomy, 30.3, 75.0 );
			SetSkill( SkillName.Poisoning, 60.1, 80.0 );
			SetSkill( SkillName.MagicResist, 45.1, 60.0 );
			SetSkill( SkillName.Tactics, 65.1, 80.0 );
			SetSkill( SkillName.Wrestling, 70.1, 85.0 );

			Fame = 30000;
			Karma = 3000;

			VirtualArmor = 30;

			ControlSlots = 3;

			PackItem( new DarkElfSpiderDust( 1 ) );
			

		}

		public EvolutionDarkElfSpider(Serial serial) : base(serial)
		{
		}
		
		public override void Damage( int amount, Mobile defender )
		
		{

			int KPDarkElfSpidergainmin, KPDarkElfSpidergainmax;

			if ( this.Stage == 1 )
			{
				if ( defender is BaseCreature )
				{
					BaseCreature bc = (BaseCreature)defender;

					if ( bc.Controlled != true )
					{
						KPDarkElfSpidergainmin = 5 + ( bc.HitsMax ) / 10;
						KPDarkElfSpidergainmax = 5 + ( bc.HitsMax ) / 5;

						this.KPDarkElfSpider += Utility.RandomList( KPDarkElfSpidergainmin, KPDarkElfSpidergainmax );
					}
				}

				if ( this.KPDarkElfSpider >= 300 )
				{
					if ( this.S1 == true )
					{
						this.S1 = false;
						int va;

						va = ( this.VirtualArmor + 10 );

						this.Warmode = false;
						this.Say( "*"+ this.Name +" is now a wolf spider*");
						this.Title = "wolf spider";
						this.BodyValue = 736;
						this.BaseSoundID = 0x388;
						this.VirtualArmor = va;
						this.Stage = 2;

						this.SetDamageType( ResistanceType.Physical, 0 );
						this.SetDamageType( ResistanceType.Fire, 0 );
						this.SetDamageType( ResistanceType.Cold, 0 );
						this.SetDamageType( ResistanceType.Poison, 100 );
						this.SetDamageType( ResistanceType.Energy, 0 );

						this.SetResistance( ResistanceType.Physical, 25 );
						this.SetResistance( ResistanceType.Fire, 25 );
						this.SetResistance( ResistanceType.Cold, 25 );
						this.SetResistance( ResistanceType.Poison, 100 );
						this.SetResistance( ResistanceType.Energy, 25 );
						
						this.SetSkill( SkillName.Anatomy, 50.3, 75.0 );
            this.SetSkill( SkillName.Poisoning, 80.1, 100.0 );
            this.SetSkill( SkillName.MagicResist, 45.1, 60.0 );
            this.SetSkill( SkillName.Tactics, 75.1, 80.0 );
            this.SetSkill( SkillName.Wrestling, 80.1, 85.0 );

						this.SetStr( 100, 120 );
            this.SetDex( 150, 200 );
            this.SetInt( 40, 60 );

            this.SetHits( 120, 150 );

            this.SetDamage( 5, 8 );
					}
				}
			}

			else if ( this.Stage == 2 )
			{
				if ( defender is BaseCreature )
				{
					BaseCreature bc = (BaseCreature)defender;

					if ( bc.Controlled != true )
					{
						KPDarkElfSpidergainmin = 5 + ( bc.HitsMax ) / 30;
						KPDarkElfSpidergainmax = 5 + ( bc.HitsMax ) / 20;

						this.KPDarkElfSpider += Utility.RandomList( KPDarkElfSpidergainmin, KPDarkElfSpidergainmax );
					}
				}

				if ( this.KPDarkElfSpider >= 500 )
				{
					if ( this.S2 == true )
					{
						this.S2 = false;
						int va;

						va = ( this.VirtualArmor + 10 );

						this.Warmode = false;
						this.Say( "*"+ this.Name +" is now a  dread spider*");
						this.Title = "dread spider";
						this.BodyValue = 11;
						this.BaseSoundID = 1170;
						this.VirtualArmor = va;
						this.Stage = 3;

						this.SetDamageType( ResistanceType.Physical, 0 );
						this.SetDamageType( ResistanceType.Fire, 0 );
						this.SetDamageType( ResistanceType.Cold, 0 );
						this.SetDamageType( ResistanceType.Poison, 100 );
						this.SetDamageType( ResistanceType.Energy, 0 );

						this.SetResistance( ResistanceType.Physical, 50 );
						this.SetResistance( ResistanceType.Fire, 25 );//Capped
						this.SetResistance( ResistanceType.Cold, 30 );//Capped
						this.SetResistance( ResistanceType.Poison, 100 );
						this.SetResistance( ResistanceType.Energy, 35 );//Capped
						
						this.SetSkill( SkillName.Anatomy, 65.3, 75.0 );
            this.SetSkill( SkillName.Poisoning, 100.1, 110.0 );
            this.SetSkill( SkillName.MagicResist, 60.1, 75.0 );
            this.SetSkill( SkillName.Tactics, 80.1, 95.0 );
            this.SetSkill( SkillName.Wrestling, 90.1, 100.0 );

						this.SetStr( 200, 250 );
            this.SetDex( 300, 350 );
            this.SetInt( 90, 120 );

            this.SetHits( 300, 500 );

            this.SetDamage( 10, 12 );
					}
				}
			}

			else if ( this.Stage == 3 )
			{
				if ( defender is BaseCreature )
				{
					BaseCreature bc = (BaseCreature)defender;

					if ( bc.Controlled != true )
					{
						KPDarkElfSpidergainmin = 5 + ( bc.HitsMax ) / 100;
						KPDarkElfSpidergainmax = 5 + ( bc.HitsMax ) / 80;

						this.KPDarkElfSpider += Utility.RandomList( KPDarkElfSpidergainmin, KPDarkElfSpidergainmax );
					}
				}

				if ( this.KPDarkElfSpider >= 1000 )
				{
					if ( this.S3 == true )
					{
						this.S3 = false;
						int va;

						va = ( this.VirtualArmor + 10 );

						this.Warmode = false;
						this.Say( "*"+ this.Name +" is now a sentinel spider*");
						this.Title = "sentinel spider";
						this.BodyValue = 0x9D;
						this.BaseSoundID = 0x388;
						this.VirtualArmor = va;
						this.Stage = 4;

						this.SetDamageType( ResistanceType.Physical, 0 );
						this.SetDamageType( ResistanceType.Fire, 0 );
						this.SetDamageType( ResistanceType.Cold, 0 );
						this.SetDamageType( ResistanceType.Poison, 100 );
						this.SetDamageType( ResistanceType.Energy, 0 );

						this.SetResistance( ResistanceType.Physical, 65 );//capped
						this.SetResistance( ResistanceType.Fire, 25 );//Capped
						this.SetResistance( ResistanceType.Cold, 30 );//Capped
						this.SetResistance( ResistanceType.Poison, 100 );//Capped
						this.SetResistance( ResistanceType.Energy, 35 );//Capped
						
						this.SetSkill( SkillName.Anatomy, 80.3, 95.0 );
            this.SetSkill( SkillName.Poisoning, 110.1, 115.0 );
            this.SetSkill( SkillName.MagicResist, 80.1, 85.0 );
            this.SetSkill( SkillName.Tactics, 95.1, 100.0 );//Capped
            this.SetSkill( SkillName.Wrestling, 100.1, 105.0 );//Capped

						this.SetStr( 250, 300 );//Capped
            this.SetDex( 400, 450 );
            this.SetInt( 150, 220 );//Capped

            this.SetHits( 800, 1200 );

            this.SetDamage( 12, 15 );
					}
				}
			}

			else if ( this.Stage == 4 )
			{
				if ( defender is BaseCreature )
				{
					BaseCreature bc = (BaseCreature)defender;

					if ( bc.Controlled != true )
					{
						KPDarkElfSpidergainmin = 5 + ( bc.HitsMax ) / 540;
						KPDarkElfSpidergainmax = 5 + ( bc.HitsMax ) / 480;

						this.KPDarkElfSpider += Utility.RandomList( KPDarkElfSpidergainmin, KPDarkElfSpidergainmax );
					}
				}

				if ( this.KPDarkElfSpider >= 5000 )
				{
					if ( this.S4 == true )
					{
						this.S4 = false;
						int va;

						va = ( this.VirtualArmor + 50 );

						this.Warmode = false;
						this.Say( "*"+ this.Name +" is now a giant black widow*");
						this.Title = "giant black widow";
						this.BodyValue = 0x9D;
						this.BaseSoundID = 0x388;
						this.VirtualArmor = va;
						this.Stage = 5;

						this.SetDamageType( ResistanceType.Physical, 0 );
						this.SetDamageType( ResistanceType.Fire, 0 );
						this.SetDamageType( ResistanceType.Cold, 0 );
						this.SetDamageType( ResistanceType.Poison, 100 );
						this.SetDamageType( ResistanceType.Energy, 0 );

						this.SetResistance( ResistanceType.Physical, 65 );//capped
						this.SetResistance( ResistanceType.Fire, 25 );//Capped
						this.SetResistance( ResistanceType.Cold, 30 );//Capped
						this.SetResistance( ResistanceType.Poison, 100 );//Capped
						this.SetResistance( ResistanceType.Energy, 35 );//Capped
						
						this.SetSkill( SkillName.Anatomy, 95.3, 100.0 );
            this.SetSkill( SkillName.Poisoning, 115.1, 125.0 );
            this.SetSkill( SkillName.MagicResist, 90.1, 100.0 );
            this.SetSkill( SkillName.Tactics, 95.1, 100.0 );//Capped
            this.SetSkill( SkillName.Wrestling, 100.1, 105.0 );//Capped


						this.SetStr( 250, 300 );//Capped
            this.SetDex( 500, 550 );//Capped
            this.SetInt( 150, 220 );//Capped

            this.SetHits( 1500, 2000 );

            this.SetDamage( 25, 35 );
					

					}
				}
			}
			base.Damage( amount, defender );
		}

		public override bool OnDragDrop( Mobile from, Item dropped )
   		{
   			PlayerMobile player = from as PlayerMobile;
   
   			if ( player != null )
   			{
   				if ( dropped is DarkElfSpiderDust )
   				{
 		 		DarkElfSpiderDust dust = ( DarkElfSpiderDust )dropped;
   
 					int amount = ( dust.Amount * 1000 );
   
 					this.PlaySound( 665 );
 					this.KPDarkElfSpider += amount;
 					dust.Delete();
 		 		this.Say( "*"+ this.Name +" drinks the venom*" );
   
 					return false;
   				}
   				else
   				{
   				}
   			}
   			return base.OnDragDrop( from, dropped );
   		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);

			writer.Write((int) 1);			
			writer.Write( m_S1 );
                        writer.Write( m_S2 ); 
                        writer.Write( m_S3 ); 
                        writer.Write( m_S4 ); 
                        writer.Write( m_S5 );  
			writer.Write( (int) m_KPDarkElfSpider );
			writer.Write( (int) m_Stage );
		}

		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);

			int version = reader.ReadInt();

			switch ( version )
			{
				case 1:
				{
                        		m_S1 = reader.ReadBool(); 
                        		m_S2 = reader.ReadBool(); 
                        		m_S3 = reader.ReadBool(); 
                        		m_S4 = reader.ReadBool(); 
                        		m_S5 = reader.ReadBool(); 
					m_KPDarkElfSpider = reader.ReadInt();
					m_Stage = reader.ReadInt();

					break;
				}
			}
		}
	}
}