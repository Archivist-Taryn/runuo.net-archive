using System;
using Server;
using Server.Items;

namespace Server.ACC.CSS.Systems.DarkElf
{
	public class DarkElfBag : ScrollBag
	{
		[Constructable]
		public DarkElfBag()
		{
			Hue = 0x48C;
			PlaceItemIn( 30, 35, new DarkElfSpidersFangScroll() );
			PlaceItemIn( 50, 35, new SummonedGiantSpiderScroll() );
			PlaceItemIn( 70, 35, new SummonedTerathanDroneScroll() );
			PlaceItemIn( 90, 35, new DeadlyVenomScroll() );
			PlaceItemIn( 90, 35, new SpiderBiteScroll() );
			PlaceItemIn( 30, 55, new SummonedTerathanAvengerScroll() );
			PlaceItemIn( 50, 55, new SummonedTerathanMatriarchScroll() );
			PlaceItemIn( 70, 55, new SummonedTerathanWarriorScroll() );
			PlaceItemIn( 30, 35, new DarkElfSpidersSpitScroll() );
			PlaceItemIn( 50, 35, new SpidersWebScroll() );
			PlaceItemIn( 70, 35, new SummonedDreadSpiderScroll() );
			PlaceItemIn( 90, 35, new SummonedFrostSpiderScroll() );
			PlaceItemIn( 30, 55, new VenomScroll() );
			PlaceItemIn( 50, 55, new EvolutionDarkElfSpiderScroll() );
			PlaceItemIn( 70, 55, new SpidersToxicBiteScroll() );
			PlaceItemIn( 30, 35, new ToxicVenomScroll() );
			PlaceItemIn( 30, 35, new SpidersVenomusBiteScroll() );
		}

		public DarkElfBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}