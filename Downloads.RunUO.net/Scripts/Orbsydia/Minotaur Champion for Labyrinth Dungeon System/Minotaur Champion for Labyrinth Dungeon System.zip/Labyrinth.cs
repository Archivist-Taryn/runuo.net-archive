using System; 
using Server.Mobiles; 
using Server.Gumps;
using System.Collections;
using System.Collections.Generic;
using Server;
using Server.Misc;
using Server.Items;
using Server.Targeting;
using Server.Network;
using Server.Commands;

namespace Server.Items 
{ 
    public class Labyrinth
    {
	private static int m_Kills;
	private static bool m_DoCounting;
	private const int m_KillsToAppear = 200;
        private const int ThirdSpawn = 120;
        private const int SecondSpawn = 60;
        private const int FirstSpawn = 20;
 
 	public static DateTime m_DelayOne;
	public static DateTime m_DelayTwo;
	public static DateTime m_DelayTree;  

	public static bool DoCounting
	{
	      get {return m_DoCounting;}
	      set {m_DoCounting = value;}
	}

	public static int Kills
	{
	      get{return m_Kills;}
	      set
	      {
		   if(m_DoCounting)
		   {
			if( value >= m_KillsToAppear )  // >= 180
			{
				SpawnChampion();	                                				
			}
               		else if( value >= ThirdSpawn )  // >= 120
			{
                                SpawnMinotaurC();
	        	}
                        else if( value >= SecondSpawn )  // >= 60
                     	{
                                SpawnMinotaurS();  
			}
                	else if( value > FirstSpawn )  // > 20
			{
                                SpawnMinotaur();

                                 Reset();  
			}     

                        
                        if( value >= m_KillsToAppear ) 
			{
                              Map map = Map.Malas; 
 
                              ArrayList list = new ArrayList();
                              Point3D loc1 = new Point3D(388,1920,0); 

	                      foreach (Mobile mob in map.GetMobilesInRange( loc1, 50 ))
                              {               
                                 if (mob.Player)
                                       list.Add(mob);
                              }

                              foreach (Mobile mob in list)
                              {                
                                   mob.SendLocalizedMessage(1073369);  // A minotaur captain bellows, "Meraktus has arrived!"                                 
                              }
      	        	}                       
                	else if( value == ThirdSpawn )
			{
                              Map map = Map.Malas; 
 
                              ArrayList list = new ArrayList();
                              Point3D loc1 = new Point3D(388,1920,0); 

	                      foreach (Mobile mob in map.GetMobilesInRange( loc1, 50 ))
                              {               
                                 if (mob.Player)
                                       list.Add(mob);
                              }

                              foreach (Mobile mob in list)
                              {            
                                   mob.SendLocalizedMessage(1073368);  // A minotaur captain barks an order to his fellow scouts, "Aid the others! Kill the invaders!"     
		              }
			}
                	else if( value == SecondSpawn )
			{
                              Map map = Map.Malas; 

                              ArrayList list = new ArrayList();
                              Point3D loc1 = new Point3D(388,1920,0); 

	                      foreach (Mobile mob in map.GetMobilesInRange( loc1, 50 ))
                              {               
                                 if (mob.Player)
                                       list.Add(mob);
                              }

                              foreach (Mobile mob in list)
                              {   			
                                   mob.SendLocalizedMessage(1073367);  // A minotaur scout barks an order to his fellow minotaurs, "Invaders are among us! Crush them!"
		              }
			}     
                        else if( value == FirstSpawn )
			{
                              Map map = Map.Malas; 

                              ArrayList list = new ArrayList();
                              Point3D loc1 = new Point3D(388,1920,0); 

	                      foreach (Mobile mob in map.GetMobilesInRange( loc1, 50 ))
                              {               
                                 if (mob.Player)
                                       list.Add(mob);
                              }

                              foreach (Mobile mob in list)
                              {   			
                                   mob.SendLocalizedMessage(1073370);  // A minotaur bellows, "I see invaders! Must warn the others!"
		              }
			}                                                       
	           }
 
                   m_Kills = value;  
	      }
	}

	public static void SpawnChampion()
	{
               	Meraktus m = new Meraktus();
		m_DoCounting = false;
                m_Kills = 0;
		m.MoveToWorld(new Point3D(383,1932,10),Map.Malas);
	}

        public static void SpawnMinotaur()
        {
           if ( DateTime.Now > m_DelayOne )
           {                 
                Map map = Map.Malas;

                int Spawn = 15;
                                
                for (int i = 0; i < Spawn; ++i)
                {  
                    Minotaur mino = new Minotaur();

                    int X = 388;
                    int Y = 1920; 
                                
                    Point3D loc = new Point3D(388,1920,0);  
                    bool validLocation = false;

                    for (int j = 0; !validLocation && j < 9; ++j)
                    {
                        int x = X + (Utility.Random( 50 ) - Utility.Random( 50 ));
                        int y = Y + (Utility.Random( 40 ) - Utility.Random( 40 ));

                        if (validLocation = map.CanFit(x, y, 0, 16, false, false))
                            loc = new Point3D(x, y, 0);
                        else if (validLocation = map.CanFit(x, y, 0, 16, false, false))
                            loc = new Point3D(x, y, 0);
                    }
                                
                    mino.MoveToWorld( loc, Map.Malas );
                }

                m_DelayOne = DateTime.Now + TimeSpan.FromSeconds(Utility.RandomMinMax(15, 30));  
            }  
        }       

        public static void SpawnMinotaurS()
        {
           if ( DateTime.Now > m_DelayTwo )
           { 
                Map map = Map.Malas;
  
                int Spawn2 = 15;
                
                for (int i = 0; i < Spawn2; ++i)
                {
                    MinotaurScout mino2 = new MinotaurScout();
                    
                    int X = 388;
                    int Y = 1920; 

                    Point3D loc = new Point3D(388,1920,0);
                    bool validLocation = false;

                    for (int j = 0; !validLocation && j < 9; ++j)
                    {
                        int x = X + (Utility.Random( 50 ) - Utility.Random( 50 ));
                        int y = Y + (Utility.Random( 40 ) - Utility.Random( 40 ));
                        
                        if (validLocation = map.CanFit(x, y, 0, 16, false, false))
                            loc = new Point3D(x, y, 0);
                        else if (validLocation = map.CanFit(x, y, 0, 16, false, false))
                            loc = new Point3D(x, y, 0);
                    }
                                
                    mino2.MoveToWorld( loc, Map.Malas );                    
                }

                m_DelayTwo = DateTime.Now + TimeSpan.FromSeconds(Utility.RandomMinMax(30, 60));                      
            }  
        } 
 
        public static void SpawnMinotaurC()
        {            
           if ( DateTime.Now > m_DelayTree )
           { 
                Map map = Map.Malas;

                int Spawn3 = 15;

                for (int i = 0; i < Spawn3; ++i)
                {
                    MinotaurCaptain mino3 = new MinotaurCaptain();

                    int X = 388;
                    int Y = 1920; 

                    Point3D loc = new Point3D(388,1920,0);  
                    bool validLocation = false;

                    for (int j = 0; !validLocation && j < 9; ++j)
                    {
                        int x = X + (Utility.Random( 50 ) - Utility.Random( 50 ));
                        int y = Y + (Utility.Random( 40 ) - Utility.Random( 40 ));

                        if (validLocation = map.CanFit(x, y, 0, 16, false, false))
                            loc = new Point3D(x, y, 0);
                        else if (validLocation = map.CanFit(x, y, 0, 16, false, false))
                            loc = new Point3D(x, y, 0);
                    }
                                
                    mino3.MoveToWorld( loc, Map.Malas );
                }

                m_DelayTree = DateTime.Now + TimeSpan.FromSeconds(Utility.RandomMinMax(60, 120));    
            }  
        }  
      
        public static void Reset()
	{
	    Timer.DelayCall(TimeSpan.FromMinutes(10.0), delegate()
            {
                 Map map = Map.Malas; 
 
                 ArrayList list = new ArrayList();
                 ArrayList list2 = new ArrayList();
                 Point3D loc1 = new Point3D(388,1920,0); 

	         foreach (Mobile mob in map.GetMobilesInRange( loc1, 50 ))
                 {               
                      if ( mob.Player && mob.AccessLevel == AccessLevel.Player )
                          list.Add(mob);
                 }

                 if (list.Count == 0)
                 {            
                      foreach ( Mobile minos in map.GetMobilesInRange( loc1, 50 ))
		      {				
			if ( minos is Minotaur || minos is MinotaurScout || minos is MinotaurCaptain )
			   list2.Add( minos );				
		      }

		      foreach ( Mobile minos in list2 )
		      {
			   minos.Delete();                    
		      }   

                      Initialize();
		 }    
                 else  
                 {
                     Timer.DelayCall(TimeSpan.FromMinutes(5.0), delegate()
                     {
                           Reset();  
                     });  
                 }                                                              
            });      
	}

	public static void Initialize()
	{
	    m_Kills = 0;
	    m_DoCounting = true;             
	}
    }
}