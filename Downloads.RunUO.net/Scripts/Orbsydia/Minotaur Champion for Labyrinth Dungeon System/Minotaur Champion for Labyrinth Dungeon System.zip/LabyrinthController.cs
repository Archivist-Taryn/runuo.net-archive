using System;
using Server;
using Server.Guilds;
using Server.Mobiles; 
using Server.Gumps;
using System.Collections;
using System.Collections.Generic;
using Server.Misc;
using Server.Items;
using Server.Targeting;
using Server.Network;
using Server.Commands;

namespace Server.Items
{
	public class LabyrinthController : Item
	{ 
                [CommandProperty(AccessLevel.GameMaster)]
                public int Kill
	        {
	            get{return Labyrinth.Kills;}
	            set{Labyrinth.Kills = value;}
	        }

		[Constructable]
		public LabyrinthController() : base( 0x1BC3 )
		{
                    Name = "Labyrinth Controller";

                    Visible = false;
                    Movable = false;
                    Hue = 1161;

		}
                
                public override void AddNameProperties( ObjectPropertyList list )
 		{
 			base.AddNameProperties( list );
                    
                       list.Add( 1060659, "Labyrinth Kills\t {0}", Kill );
                }
 
                public override void OnDoubleClick(Mobile from)
                {
                    if( from.AccessLevel > AccessLevel.Player )
                    {
                        Labyrinth.Initialize();  
                    } 
                    else
                    {
                        return;  
                    }
                } 

		public LabyrinthController( Serial serial ) : base(serial)
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
			
			writer.Write( (int) Kill );            
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
			
			switch ( version )
			{
				case 0:
				{
					Kill = (int)reader.ReadInt();
                                        
					break;
				}
			}
		}
		
	}
}