﻿using System;
using System.Collections;
using Server;
using Server.Mobiles;
using Server.Network;
using Server.Commands;
using Server.Multis;

namespace Server.Misc
{
    public class AlignmentSystem
    {
        #region Setup
        //Setup

        private static bool m_Alignment = true;    // If false, alignment system deactivated.
        private static bool m_Good = true;  // If false, good alignment deactivated.
        private static bool m_Evil = true; //  If false, evil alignment deactivated.
        private static bool m_Neutral = true; // If false, neutral alignment deactivated.
        private static bool m_ShowTitles = false; // Shows Alignment Title
        private static bool m_Enemies = false; // Are Good and Evil at war?

        //Good
        private static bool m_LawfulGood = true;  // Lawful good active?
        private static bool m_NeutralGood = true; // Neutral Good Active?
        private static bool m_ChaoticGood = true; // Chaotic Good Active?

        //Neutral
        private static bool m_LawfulNeutral = true; // Lawful Neutral Active?
        private static bool m_TrueNeutral = true;  // True Neutral Active?
        private static bool m_ChaoticNeutral = true;  // Chaotic Neutral Active?

        //Evil
        private static bool m_LawfulEvil = true; // Lawful Evil Active?
        private static bool m_NeutralEvil = true; // Neutral Evil Active?
        private static bool m_ChaoticEvil = true; // Chaotic Evil Active?

        //Setup End
        #endregion

        public static bool Alignment { get { return m_Alignment; } }
        public static bool Good { get { return m_Good; } }
        public static bool Neutral { get { return m_Neutral; } }
        public static bool Evil { get { return m_Evil; } }
        public static bool ShowTitles { get { return m_ShowTitles; } }
        public static bool Enemies { get { return m_Enemies; } }
        public static bool LawfulGood { get { return m_LawfulGood; } }
        public static bool NeutralGood { get { return m_NeutralGood; } }
        public static bool ChaoticGood { get { return m_ChaoticGood; } }
        public static bool LawfulNeutral { get { return m_LawfulNeutral; } }
        public static bool TrueNeutral { get { return m_TrueNeutral; } }
        public static bool ChaoticNeutral { get { return m_ChaoticNeutral; } }
        public static bool LawfulEvil { get { return m_LawfulEvil; } }
        public static bool NeutralEvil { get { return m_NeutralEvil; } }
        public static bool ChaoticEvil { get { return m_ChaoticEvil; } }

    }
}