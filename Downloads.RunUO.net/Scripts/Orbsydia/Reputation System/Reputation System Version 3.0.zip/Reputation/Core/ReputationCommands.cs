/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Commands;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationCommands
    {
        public static void Initialize()
        {
            CommandSystem.Register("repspawn", AccessLevel.Administrator, new CommandEventHandler(RepSpawn_OnCommand));
        }

        [Description("Activate all defined reputation spawns.")]
        [Usage("[RepSpawn <Abbreviation>")]
        private static void RepSpawn_OnCommand(CommandEventArgs e)
        {
            ReputationSystem.ActivateSpawners(e);
        }
    }
}
