﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationTitleScroll : Item
    {
        private String m_Title;
        private Mobile m_Owner;

        [CommandProperty(AccessLevel.GameMaster)]
        public String Title { get { return m_Title; } }

        [CommandProperty(AccessLevel.GameMaster)]
        public Mobile Owner { get { return m_Owner; } set { m_Owner = value; } }

        [Constructable]
        public ReputationTitleScroll(String title) : base(0x2258)
        {
            LootType = LootType.Cursed;
            Name = "Scroll Bestowing the Title of";
            m_Title = title;
        }

        public ReputationTitleScroll(Serial serial) : base(serial)
        {
        }

        public override void AddNameProperty(ObjectPropertyList list)
        {
            list.Add(Name);
            list.Add(1049644, m_Title);

            if (m_Owner != null)
                list.Add(1072304, m_Owner.Name);
        }

        public bool CanPlayerUseScroll(PlayerMobile player)
        {
            if (player.CollectionTitles.Contains(m_Title))
                return false;

            return true;
        }

        public override void OnDoubleClick(Mobile from)
        {
            if (!(from is PlayerMobile))
                return;

            if (m_Owner != null && from != m_Owner)
            {
                from.SendLocalizedMessage(500364);
                return;
            }

            if (((PlayerMobile)from).CollectionTitles.Contains(m_Title))
            {
                from.SendLocalizedMessage(1073626);
                return;
            }

            ((PlayerMobile)from).AddCollectionTitle(m_Title);
            from.SendSound(0x3D);
            from.SendLocalizedMessage(1073625, m_Title);
            Delete();
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0); // version

            writer.Write((String)m_Title);
            writer.Write((Mobile)m_Owner);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();

            m_Title = reader.ReadString();
            m_Owner = reader.ReadMobile();
        }
    }
}