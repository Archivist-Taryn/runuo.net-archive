﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationLogbook : Item
    {
        [Constructable]
        public ReputationLogbook() : base(0xFF0)
        {
            Name = "Reputation Logbook";
            LootType = Server.LootType.Blessed;
            Hue = 0x489;
            Weight = 0;
        }

        public ReputationLogbook(Serial serial) : base(serial)
        {
        }

        public override Boolean DisplayWeight { get { return false; } }

        public override void OnDoubleClick(Mobile from)
        {
            if (from is PlayerMobile)
                from.SendGump(new ReputationLogbookGump((PlayerMobile)from));
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();

            switch (version)
            {
                case 0:
                    break;
            }
        }
    }
}
