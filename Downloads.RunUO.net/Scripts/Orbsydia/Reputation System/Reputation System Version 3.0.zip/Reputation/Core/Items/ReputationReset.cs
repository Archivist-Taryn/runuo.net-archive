﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationReset : Item
    {
        private BaseReputationGroup m_ReputationGroup;
        public BaseReputationGroup ReputationGroup { get { return m_ReputationGroup; } set { m_ReputationGroup = value; } }

        private Int32 m_ReputationValue;

        [CommandProperty(AccessLevel.GameMaster)]
        public Int32 ReputationValue { get { return m_ReputationValue; } set { m_ReputationValue = value; } }

        [Constructable]
        public ReputationReset() : base(0x1852)
        {
            Name = "Reputation Reset Scales";
            LootType = Server.LootType.Blessed;
            Hue = 0x489;
            Weight = 0;
        }

        public ReputationReset(Serial serial) : base(serial)
        {
        }

        public override Boolean DisplayWeight { get { return false; } }

        public override void OnDoubleClick(Mobile from)
        {
            if (from.AccessLevel >= AccessLevel.Administrator && m_ReputationGroup == null)
            {
                from.Target = new InternalTarget(this);
                return;
            }

            if (m_ReputationGroup == null || !(from is PlayerMobile))
                return;

            ReputationEntry entry = ReputationSystem.FindEntry((PlayerMobile)from, m_ReputationGroup.GroupName, m_ReputationGroup.StartingReputation);

            entry.ResetReputation((PlayerMobile)from, m_ReputationValue);
            Delete();
        }

        private class InternalTarget : Target
        {
            private readonly ReputationReset m_Reset;

            public InternalTarget(ReputationReset reset) : base(20, false, TargetFlags.None)
            {
                this.m_Reset = reset;
            }

            protected override void OnTarget(Mobile from, object targeted)
            {
                if (this.m_Reset.Deleted)
                    return;

                if (targeted is BaseReputationVendor)
                    m_Reset.ReputationGroup = ((BaseReputationVendor)targeted).ReputationGroup;
                else if (targeted is BaseReputationQuestGiver)
                    m_Reset.ReputationGroup = ((BaseReputationQuestGiver)targeted).ReputationGroup;
            }
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();

            Delete();
        }
    }
}
