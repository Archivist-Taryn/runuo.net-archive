﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationEntry
    {
        private String m_GroupName;
        private Int32 m_ReputationPoints;

        public String GroupName { get { return m_GroupName; } }
        public Int32 ReputationPoints { get { return m_ReputationPoints; } }

        public ReputationLevel Reputation { get { return ReputationSystem.DetermineCurrentLevel(m_ReputationPoints); } }

        public ReputationEntry(String groupName) : this(groupName, 0)
        {
        }

        public ReputationEntry(String groupName, Int32 points)
        {
            m_GroupName = groupName;
            m_ReputationPoints = points;
        }

        public void AwardReputation(PlayerMobile player, ReputationLevel maxLevel, Int32 amount)
        {
            if (amount == 0)
                return;

            ReputationLevel originalReputation = Reputation;

            m_ReputationPoints += amount;

            if (m_ReputationPoints < ReputationSystem.Hated)
            {
                amount += (m_ReputationPoints - ReputationSystem.Hated);
                m_ReputationPoints = ReputationSystem.Hated;
            }
            else if (m_ReputationPoints > ReputationSystem.PointsNeededForLevel(maxLevel))
            {
                amount -= (m_ReputationPoints - ReputationSystem.PointsNeededForLevel(maxLevel));
                m_ReputationPoints = ReputationSystem.PointsNeededForLevel(maxLevel);
            }
            else if (m_ReputationPoints > ReputationSystem.Member)
            {
                amount -= (m_ReputationPoints - ReputationSystem.Member);
                m_ReputationPoints = ReputationSystem.Member;
            }

            if (amount == 0)
                return;

            if (amount > 0)
                player.SendMessage(0x3E, "Your reputation with {0} has increased by {1} points.", m_GroupName, amount);
            else
                player.SendMessage(0x26, "Your reputation with {0} has decreased by {1} points.", m_GroupName, Math.Abs(amount));

            if (Reputation > originalReputation)
                ReachedNewLevel(player, amount > 0);
        }

        public void ResetReputation(PlayerMobile player, Int32 amount)
        {
            ReputationLevel originalReputation = Reputation;

            Int32 change = amount - m_ReputationPoints;
            m_ReputationPoints = amount;

            if (change == 0)
                return;

            if (change > 0)
                player.SendMessage(0x3E, "Your reputation with {0} has increased by {1} points.", m_GroupName, change);
            else
                player.SendMessage(0x26, "Your reputation with {0} has decreased by {1} points.", m_GroupName, Math.Abs(change));

            if (Reputation > originalReputation)
                ReachedNewLevel(player, change > 0);
        }

        private void ReachedNewLevel(PlayerMobile player, Boolean increase)
        {
            player.SendMessage(0xC8, "Your reputation with {0} has {1}creased to {2}.", 
                m_GroupName, increase ? "in" : "de", Reputation.ToString());
        }
    }
}
