﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using Server;
using Server.Commands;
using Server.Mobiles;
using Server.Engines.XmlSpawner2;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationSystem
    {
        public const Int32 Hated = -21000;
        public const Int32 Disliked = -9000;
        public const Int32 Wary = -3000;
        public const Int32 Neutral = 0;
        public const Int32 Friendly = 3000;
        public const Int32 WellKnown = 9000;
        public const Int32 Trusted = 21000;
        public const Int32 Member = 45000;

        private const Int32 HatedHue = 0xED;
        private const Int32 DislikedHue = 0x2C;
        private const Int32 WaryHue = 0x38;
        private const Int32 NeutralHue = 0x38A;
        private const Int32 FriendlyHue = 0x3C;
        private const Int32 WellKnownHue = 0x56;
        private const Int32 TrustedHue = 0x15;
        private const Int32 MemberHue = 0x64;

        private static Hashtable m_ReputationRegistry = new Hashtable();
        private static Dictionary<Type, Dictionary<BaseReputationGroup, KillGainHelper>> m_GainsByKill = new Dictionary<Type, Dictionary<BaseReputationGroup, KillGainHelper>>();

        #region Event Handlers
        public delegate void KilledByEventHandler(BaseCreature creature, PlayerMobile player);
        public static event KilledByEventHandler KilledByEvent;

        public static void OnKilledByEvent(BaseCreature creature, PlayerMobile player)
        {
            if (KilledByEvent != null)
                KilledByEvent(creature, player);
        }
        #endregion

        #region KillGainHelper
        private class KillGainHelper
        {
            private ReputationLevel m_MaxLevel;
            public ReputationLevel MaxLevel { get { return m_MaxLevel; } }

            private Int32 m_GainAmount;
            public Int32 GainAmount { get { return m_GainAmount; } }

            public KillGainHelper(ReputationLevel maxLevel, Int32 gainAmount)
            {
                m_MaxLevel = maxLevel;
                m_GainAmount = gainAmount;
            }
        }
        #endregion

        public static void Initialize()
        {
            EventSink.Login += new LoginEventHandler(EventSink_Login);

            // See note regarding installing the OnKilledBy hook in BaseCereature.cs at the bottom of this script
            ReputationSystem.KilledByEvent += ReputationSystem_KilledByEvent;
        }

        private static void EventSink_Login(LoginEventArgs e)
        {
            if (e.Mobile is PlayerMobile)
            {
                ReputationAttachment attachment = FindAttachment(e.Mobile);
            }
        }

        private static void ReputationSystem_KilledByEvent(BaseCreature creature, PlayerMobile player)
        {
            Dictionary<BaseReputationGroup, KillGainHelper> groups = null;
            m_GainsByKill.TryGetValue(creature.GetType(), out groups);

            if (groups == null)
                return;

            foreach (KeyValuePair<BaseReputationGroup, KillGainHelper> pair in groups)
            {
                ReputationEntry entry = FindEntry(player, pair.Key.GroupName, pair.Key.StartingReputation);

                if (entry != null)
                    entry.AwardReputation(player, pair.Value.MaxLevel, pair.Value.GainAmount);
            }
        }

        public static void AwardReputation(PlayerMobile player, BaseReputationGroup group, ReputationLevel maxLevel, Int32 amount)
        {
            ReputationEntry entry = FindEntry(player, group.GroupName, group.StartingReputation);

            if (entry != null)
                entry.AwardReputation(player, maxLevel, amount);
        }

        public static void RegisterReputationGroup(BaseReputationGroup group)
        {
            m_ReputationRegistry[group.GroupName] = group;
        }

        public static void RegisterReputationKillGain(Type slainType, BaseReputationGroup reputationGroup, ReputationLevel maxLevel, Int32 gainAmount)
        {
            Dictionary<BaseReputationGroup, KillGainHelper> groups = null;
            m_GainsByKill.TryGetValue(slainType, out groups);

            if (groups == null)
                m_GainsByKill[slainType] = groups = new Dictionary<BaseReputationGroup, KillGainHelper>();

            groups[reputationGroup] = new KillGainHelper(maxLevel, gainAmount);
        }

        public static ReputationLevel GetCurrentReputation(Mobile from, BaseReputationGroup reputationGroup)
        {
            if (!(from is PlayerMobile))
                return ReputationLevel.Neutral;

            ReputationAttachment attachment = FindAttachment(from);
            ReputationEntry entry = FindEntry((PlayerMobile)from, reputationGroup.GroupName, reputationGroup.StartingReputation);

            if (entry != null)
                return entry.Reputation;
            else
                return ReputationLevel.Neutral;
        }

        public static BaseReputationGroup LocateReputationGroup(string groupName)
        {
            if (m_ReputationRegistry.ContainsKey(groupName))
                return (BaseReputationGroup)m_ReputationRegistry[groupName];

            return null;
        }

        public static void ActivateSpawners(CommandEventArgs e)
        {
            foreach (BaseReputationGroup group in m_ReputationRegistry.Values)
                if (e.Arguments.Length == 0 || e.Arguments[0] == "" || e.Arguments[0] == group.Abbreviation)
                    group.ActivateSpawnRequest(e);
        }

        public static ReputationAttachment FindAttachment(Mobile m)
        {
            ReputationAttachment attachment = (ReputationAttachment)XmlAttach.FindAttachment(m, typeof(ReputationAttachment));

            if (attachment == null)
            {
                attachment = new ReputationAttachment();
                XmlAttach.AttachTo(m, attachment);
            }

            return attachment;
        }

        public static ReputationEntry FindEntry(PlayerMobile player, String groupName, ReputationLevel defaultReputation)
        {
            ReputationAttachment attachment = FindAttachment(player);

            if (attachment != null)
            {
                ReputationEntry entry = attachment.FindReputationEntryName(groupName);

                if (entry == null)
                {
                    entry = new ReputationEntry(groupName, ReputationSystem.PointsNeededForLevel(defaultReputation));
                    attachment.ReputationEntries.Add(entry);
                    attachment.ReputationEntries.Sort(ComapreByName);
                }

                return entry;
            }

            return null;
        }

        public static Int32 ComapreByName(ReputationEntry entry1, ReputationEntry entry2)
        {
            if (entry1.GroupName == null)
            {
                if (entry2.GroupName == null)
                    return 0;
                else
                    return -1;
            }
            else
            {
                if (entry2.GroupName == null)
                    return 1;
                else
                    return entry1.GroupName.CompareTo(entry2.GroupName);
            }
        }

        public static Int32 PointsNeededForLevel(ReputationLevel reputationLevel)
        {
            Int32[] PointsValues = new Int32[8] { Hated, Disliked, Wary, Neutral, Friendly, WellKnown, Trusted, Member };

            return PointsValues[(Int32)reputationLevel];
        }

        public static Int32 GetReputationHue(ReputationLevel reputationLevel)
        {
            Int32[] Hues = new Int32[8] { HatedHue, DislikedHue, WaryHue, NeutralHue, FriendlyHue, WellKnownHue, TrustedHue, MemberHue };

            return Hues[(Int32)reputationLevel];
        }

        public static ReputationLevel DetermineCurrentLevel(Int32 points)
        {
            if (points <= Hated)
                return ReputationLevel.Hated;
            else if (points <= Disliked)
                return ReputationLevel.Disliked;
            else if (points <= Wary)
                return ReputationLevel.Wary;
            else if (points < Friendly)
                return ReputationLevel.Neutral;
            else if (points < WellKnown)
                return ReputationLevel.Friendly;
            else if (points < Trusted)
                return ReputationLevel.WellKnown;
            else if (points < Member)
                return ReputationLevel.Trusted;
            else
                return ReputationLevel.Member;
        }

        public static Int32 NeededForNextHigherLevel(Int32 currentPoints)
        {
            Int32 needed = 0;

            switch (DetermineCurrentLevel(currentPoints))
            {
                case ReputationLevel.Hated:
                    needed = Math.Abs(Math.Abs(Hated) - Math.Abs(currentPoints)) + 1;
                    break;
                case ReputationLevel.Disliked:
                    needed = Math.Abs(Math.Abs(Disliked) - Math.Abs(currentPoints)) + 1;
                    break;
                case ReputationLevel.Wary:
                    needed = Math.Abs(Math.Abs(Wary) - Math.Abs(currentPoints)) + 1;
                    break;
                case ReputationLevel.Neutral:
                    needed = Friendly - currentPoints;
                    break;
                case ReputationLevel.Friendly:
                    needed = WellKnown - currentPoints;
                    break;
                case ReputationLevel.WellKnown:
                    needed = Trusted - currentPoints;
                    break;
                case ReputationLevel.Trusted:
                    needed = Member - currentPoints;
                    break;
            }

            return needed;
        }
    }
}


        /*****************************************************************************************************************************
         * 
         * In order to hook into the reputation when a creature is killed, you will need to make a small change
         * to the BaseCreature.cs script.  Open the script and find the OnKilledBy routine as shown below.
         *  
                    public virtual void OnKilledBy( Mobile mob )
                    {
                        if (this.m_Paragon && XmlParagon.CheckArtifactChance(mob, this))
                            XmlParagon.GiveArtifactTo(mob, this);
                        .
                        .
                        .
                    }

         * Now we need to add two lines to hook into the reputation system as shown below

                    public virtual void OnKilledBy( Mobile mob )
                    {
                        if (this.m_Paragon && XmlParagon.CheckArtifactChance(mob, this))
                            XmlParagon.GiveArtifactTo(mob, this);

            			if (mob is PlayerMobile)
            				Custom.ReputationSystem.ReputationSystem.OnKilledByEvent(this, ((PlayerMobile)mob));
                        .
                        .
                        .
                    }
     
         * Once this changed has been made, save the script and moster kills can now be captured by the
         * reputation system.
         * 
         * ***************************************************************************************************************************/