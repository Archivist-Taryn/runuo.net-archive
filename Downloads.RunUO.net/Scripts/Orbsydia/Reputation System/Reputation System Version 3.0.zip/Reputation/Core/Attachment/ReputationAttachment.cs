﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using System.Collections.Generic;
using Server;
using Server.Engines.XmlSpawner2;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationAttachment : XmlAttachment
    {
        private List<ReputationEntry> m_ReputationEntries = new List<ReputationEntry>();
        public List<ReputationEntry> ReputationEntries { get { return m_ReputationEntries; } set { m_ReputationEntries = value; } }

        // a serial constructor is REQUIRED
        public ReputationAttachment(ASerial serial) : base(serial)
        {
        }

        [Attachable]
        public ReputationAttachment()
        {
        }

        public ReputationEntry FindReputationEntryName(String groupName)
        {
            return m_ReputationEntries.Find(delegate(ReputationEntry entry) { return entry.GroupName == groupName; });
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0);

            writer.Write((Int32)m_ReputationEntries.Count);

            foreach (ReputationEntry entry in m_ReputationEntries)
            {
                writer.Write((String)entry.GroupName);
                writer.Write((Int32)entry.ReputationPoints);
            }
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();

            Int32 entryCount = reader.ReadInt();

            for (Int32 i = 0; i < entryCount; i++)
                m_ReputationEntries.Add(new ReputationEntry(reader.ReadString(), reader.ReadInt()));
        }
    }
}
