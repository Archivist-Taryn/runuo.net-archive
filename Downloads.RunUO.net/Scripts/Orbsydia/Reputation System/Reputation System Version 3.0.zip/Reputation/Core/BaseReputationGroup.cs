﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

using System;
using Server;
using Server.Commands;
using Server.Mobiles;

namespace Custom.ReputationSystem
{
    public abstract class BaseReputationGroup
    {
        public abstract String GroupName { get; }
        public abstract ReputationLevel StartingReputation { get; }
        public abstract String Abbreviation { get; }

        public virtual void ActivateSpawnRequest(CommandEventArgs e)
        {
        }

        public BaseReputationGroup()
        {
        }

        protected void ActivateSpawn(Mobile from, String xmlFilename)
        {
            CommandSystem.Handle(from, String.Format("{0}XmlLoad {1}", Server.Commands.CommandSystem.Prefix, xmlFilename));
        }
    }
}
