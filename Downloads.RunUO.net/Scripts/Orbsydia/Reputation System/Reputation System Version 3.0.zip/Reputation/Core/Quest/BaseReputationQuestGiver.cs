﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using System.Collections.Generic;
using Server;
using Server.ContextMenus;
using Server.Engines.Quests;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public abstract class BaseReputationQuestGiver : MondainQuester
    {
        public override Boolean DisallowAllMoves { get { return true; } }
        public override Boolean ClickTitle { get { return false; } }
        public override Boolean CanTeach { get { return false; } }
        public override Int32 AutoTalkRange { get { return -1; } }
        public override Int32 AutoSpeakRange { get { return -1; } }

        public abstract BaseReputationGroup ReputationGroup { get; }
        public abstract String ReputationGroupTitle { get; }
        public virtual ReputationLevel MinimumReputation { get { return ReputationLevel.Neutral; } }

        public BaseReputationQuestGiver()
            : base()
        {
        }

        public BaseReputationQuestGiver(Serial serial)
            : base(serial)
        {
        }

        public override void AddCustomContextEntries(Mobile from, List<Server.ContextMenus.ContextMenuEntry> list)
        {
            base.AddCustomContextEntries(from, list);

            list.Add(new TalkEntry(from, this));
        }

        #region TalkEntry
        private class TalkEntry : ContextMenuEntry
        {
            Mobile m_Player;
            BaseReputationQuestGiver m_QuestGiver;

            public TalkEntry(Mobile player, BaseReputationQuestGiver questGiver) : base(3006146, 10)
            {
                m_QuestGiver = questGiver;
                m_Player = player;
            }

            public override Boolean NonLocalUse { get { return true; } }

            public override void OnClick()
            {
                if (m_Player is PlayerMobile)
                    m_QuestGiver.OnTalk((PlayerMobile)m_Player);
            }
        }
        #endregion

        public override void AddNameProperties(ObjectPropertyList list)
        {
            base.AddNameProperties(list);

            if (ReputationGroupTitle != null && ReputationGroupTitle != "")
                list.Add(ReputationGroupTitle);
        }

        public override void InitBody()
        {
            InitStats(100, 100, 25);

            Hue = Utility.RandomSkinHue();
            SpeechHue = 0x3B2;
            NameHue = 0x159;

            if (this.Female = Utility.RandomBool())
            {
                this.Body = 0x191;
                this.Name = NameList.RandomName("female");
            }
            else
            {
                this.Body = 0x190;
                this.Name = NameList.RandomName("male");
            }

            Int32 hairHue = GetHairHue();

            Utility.AssignRandomHair(this, hairHue);
            Utility.AssignRandomFacialHair(this, hairHue);
        }

        protected void EquipItem(Item item, Int32 hue)
        {
            item.Hue = hue;
            EquipItem(item);
        }

        public bool CanInteractWith(Mobile from)
        {
            if (!from.InRange(this.Location, 10) || from.Deleted || !from.Alive || !this.CanSee(from))
                return false;

            return true;
        }

        public bool ValidReputation(Mobile from)
        {
            if (ReputationSystem.GetCurrentReputation(from, ReputationGroup) < MinimumReputation)
                return false;

            return true;
        }

        public override void OnTalk(PlayerMobile player)
        {
            if (!CanInteractWith(player))
                return;

            if (QuestHelper.DeliveryArrived(player, this))
                return;

            if (QuestHelper.InProgress(player, this))
                return;

            if (QuestHelper.QuestLimitReached(player))
                return;

            // check if this quester can offer any quest chain (already started)
            foreach (KeyValuePair<QuestChain, BaseChain> pair in player.Chains)
            {
                BaseChain chain = pair.Value;

                if (chain != null && chain.Quester != null && chain.Quester == GetType())
                {
                    BaseQuest q = QuestHelper.RandomQuest(player, new Type[] { chain.CurrentQuest }, this);

                    if (q != null)
                    {
                        player.CloseGump(typeof(MondainQuestGump));
                        player.SendGump(new MondainQuestGump(q));
                        return;
                    }
                }
            }

            if (!ValidReputation(player))
            {
                SayTo(player, "I have nothing to say to you right now.");
                return;
            }

            BaseQuest quest = QuestHelper.RandomQuest(player, Quests, this);

            if (quest is ReputationQuest)
                ((ReputationQuest)quest).InitializeQuest(player, this);

            if (quest != null)
            {
                player.CloseGump(typeof(MondainQuestGump));
                player.SendGump(new MondainQuestGump(quest));
            }
        }

        public override bool CanPaperdollBeOpenedBy(Mobile from)
        {
            return false;
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.WriteEncodedInt((Int32)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadEncodedInt();
        }
    }
}