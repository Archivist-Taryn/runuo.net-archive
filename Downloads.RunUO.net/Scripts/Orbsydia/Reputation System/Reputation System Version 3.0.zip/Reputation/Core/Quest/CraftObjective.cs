﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Engines.Quests;
using Server.Items;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class CraftObjective : ObtainObjective
    {
        private Boolean m_ReqExceptional;
        public Boolean ReqExceptional { get { return m_ReqExceptional; } set { m_ReqExceptional = value; } }

        public CraftObjective(Type obtain, String name, Int32 amount, Boolean requireExceptional) : this(obtain, name, amount, requireExceptional, 0, 0)
        {
        }

        public CraftObjective(Type obtain, String name, Int32 amount, Boolean requireExceptional, Int32 image) : this(obtain, name, amount, requireExceptional, image, 0)
        {
        }

        public CraftObjective(Type obtain, String name, Int32 amount, Boolean requireExceptional, Int32 image, Int32 seconds) : base(obtain, name, amount, image, seconds)
        {
            m_ReqExceptional = requireExceptional;
        }

        public override Boolean IsObjective(Item item)
        {
            if (Obtain == null)
                return false;

            if (!Obtain.IsAssignableFrom(item.GetType()))
                return false;

            if (item is BaseWeapon && ((BaseWeapon)item).PlayerConstructed)
            {
                if (m_ReqExceptional && ((BaseWeapon)item).Quality != WeaponQuality.Exceptional)
                    return false;
                else
                    return true;
            }
            else if (item is BaseArmor && ((BaseArmor)item).PlayerConstructed)
            {
                if (m_ReqExceptional && ((BaseArmor)item).Quality != ArmorQuality.Exceptional)
                    return false;
                else
                    return true;
            }

            return false;
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.WriteEncodedInt((Int32)0); // version

            writer.Write((Boolean)m_ReqExceptional);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadEncodedInt();

            m_ReqExceptional = reader.ReadBool();
        }
    }
}
