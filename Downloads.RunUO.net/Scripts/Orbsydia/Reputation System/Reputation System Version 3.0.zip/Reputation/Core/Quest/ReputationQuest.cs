﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Engines.Quests;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public abstract class ReputationQuest : BaseQuest
    {
        public abstract BaseReputationGroup ReputationGroup { get; }

        private String m_QuestName;
        public String QuestName { get { return m_QuestName; } set { m_QuestName = value; } }

        private String m_CustomDescription;
        public String CustomDescription { get { return m_CustomDescription; } set { m_CustomDescription = value; } }

        private String m_CustomRefuse;
        public String CustomRefuse { get { return m_CustomRefuse; } set { m_CustomRefuse = value; } }

        private String m_CustomUncomplete;
        public String CustomUncomplete { get { return m_CustomUncomplete; } set { m_CustomUncomplete = value; } }

        private String m_CustomComplete;
        public String CustomComplete { get { return m_CustomComplete; } set { m_CustomComplete = value; } }

        private String m_GoalName;
        public String GoalName { get { return m_GoalName; } set { m_GoalName = value; } }

        private Type m_GoalType;
        public Type GoalType { get { return m_GoalType; } set { m_GoalType = value; } }

        private Int32 m_GoalAmount;
        public Int32 GoalAmount { get { return m_GoalAmount; } set { m_GoalAmount = value; } }

        private Int32 m_ReputationRewarded;
        public Int32 ReputationRewarded { get { return m_ReputationRewarded; } set { m_ReputationRewarded = value; } }

        private Boolean m_RequireExceptional = false;
        public Boolean RequireExceptional { get { return m_RequireExceptional; } set { m_RequireExceptional = value; } }

        public override object Title { get { return m_QuestName; } }
        public override object Description { get { return m_CustomDescription; } }
        public override object Refuse { get { return m_CustomRefuse; } }
        public override object Uncomplete { get { return m_CustomUncomplete; } }
        public override object Complete { get { return m_CustomComplete; } }
        public virtual ReputationLevel MaxReputationLevel { get { return ReputationLevel.Member; } }

        public abstract void InitializeQuest(PlayerMobile player, BaseReputationQuestGiver questGiver);

        public override void GiveRewards()
        {
            base.GiveRewards();

            ReputationSystem.AwardReputation(Owner, ReputationGroup, MaxReputationLevel, m_ReputationRewarded);
        }

        public ReputationQuest()
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0); // version

            writer.Write((String)m_QuestName);
            writer.Write((String)m_CustomDescription);
            writer.Write((String)m_CustomRefuse);
            writer.Write((String)m_CustomUncomplete);
            writer.Write((String)m_CustomComplete);
            writer.Write((String)m_GoalName);
            writer.Write((String)m_GoalType.FullName);
            writer.Write((Int32)m_GoalAmount);
            writer.Write((Int32)m_ReputationRewarded);
            writer.Write((Boolean)m_RequireExceptional);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();

            m_QuestName = reader.ReadString();
            m_CustomDescription = reader.ReadString();
            m_CustomRefuse = reader.ReadString();
            m_CustomUncomplete = reader.ReadString();
            m_CustomComplete = reader.ReadString();
            m_GoalName = reader.ReadString();

            String type = reader.ReadString();

            if (type != null)
                m_GoalType = ScriptCompiler.FindTypeByFullName(type);

            m_GoalAmount = reader.ReadInt();
            m_ReputationRewarded = reader.ReadInt();
            m_RequireExceptional = reader.ReadBool();
        }
    }
}
