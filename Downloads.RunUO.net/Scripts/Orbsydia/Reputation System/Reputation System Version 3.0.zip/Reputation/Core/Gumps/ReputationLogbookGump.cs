﻿/*****************************************************************************************************************************
 * 
 * Reputation System
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server.Gumps;
using Server.Mobiles;
using Server.Engines.XmlSpawner2;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Custom.ReputationSystem
{
    public class ReputationLogbookGump : Gump
    {
        private PlayerMobile player;

        private Int32 width = 400;
        private Int32 height = 450;

        public ReputationLogbookGump(PlayerMobile p) : base(20, 20)
        {
            player = p;

            ReputationAttachment attachment = (ReputationAttachment)XmlAttach.FindAttachment(player, typeof(ReputationAttachment));

            if (attachment != null)
            {
                Int32 pageNumber = 1;

                StartNewPage(pageNumber);

                Int32 y = 60;

                for (Int32 i = 0; i < attachment.ReputationEntries.Count; i++)
                {
                    ReputationEntry entry = attachment.ReputationEntries[i];

                    Int32 nextY = y + 25 + (entry.Reputation < ReputationLevel.Member ? 15 : 0);

                    if (nextY > 395 && i < attachment.ReputationEntries.Count - 1)
                    {
                        if (pageNumber > 1)
                            AddButton(30, 395, 4014, 4015, 0, GumpButtonType.Page, pageNumber - 1);

                        AddButton(340, 395, 4005, 4006, 0, GumpButtonType.Page, pageNumber + 1);

                        pageNumber += 1;

                        StartNewPage(pageNumber);

                        Int32 yDiff = nextY - y;

                        y = 60;
                        nextY = y + yDiff;
                    }

                    AddLabelCropped(30, y, 260, 16, 0x481, entry.GroupName);
                    AddLabelCropped(300, (entry.Reputation < ReputationLevel.Member ? y + 8 : y), 80, 16, ReputationSystem.GetReputationHue(entry.Reputation), entry.Reputation.ToString());

                    if (entry.Reputation < ReputationLevel.Member)
                    {
                        AddLabel(30, y + 15, 0x270, "Progress:");

                        Int32 difference = ReputationSystem.NeededForNextHigherLevel(entry.ReputationPoints);

                        AddLabel(100, y + 15, 0x270, String.Format("{0} Needed For Next Level", difference));
                    }

                    if (i < attachment.ReputationEntries.Count - 1 && WillFit(nextY, attachment.ReputationEntries[i + 1]))
                        AddImageTiled(25, nextY - 3, 350, 2, 10001);

                    y = nextY;
                }

                if (pageNumber > 1)
                    AddButton(30, 395, 4014, 4015, 0, GumpButtonType.Page, pageNumber - 1);
            }
        }

        private bool WillFit(Int32 startY, ReputationEntry entry)
        {
            Int32 nextY = startY + 25 + (entry.Reputation < ReputationLevel.Member ? 15 : 0);

            if (nextY > 395)
                return false;
            else
                return true;
        }

        private void StartNewPage(Int32 pageNumber)
        {
            AddPage(pageNumber);

            AddBackground(0, 0, width, height, 9390);

            //AddTextEntry(-10, -10, 1, 1, 17, 0, "");    // First TextEntry adds an underscore.  Fix this by displaying an empty string offscreen
            AddLabel(139, 35, 0xBC, "Reputation Status");
        }
    }
}