﻿/*****************************************************************************************************************************
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Items;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION GROUPS ///

namespace Custom.ReputationSystem
{
    public class MBA_Foreman : BaseReputationQuestGiver
    {
        // This must contain an instance of your reputation group
        public override BaseReputationGroup ReputationGroup { get { return new MinocBlacksmithAssociation(); } }

        // This must contain the quest giver's group title.  Leave blank or null for no title.
        public override String ReputationGroupTitle { get { return "Foreman of the Minoc Blacksmithing Association"; } }

        // Add your quest types here.  Be sure they are of type ReputationQuest to award reputation
        public override Type[] Quests
        {
            get { return new Type[] { typeof(MBA_HuntQuest), }; }
        }

        // Dress your quest giver however you like, or leave this routine out to accept default attire
        public override void InitOutfit()
        {
            Int32 armorHue;
            Int32 cloakShoeHue;

            switch (Utility.Random(9))
            {
                default:
                case 0: armorHue = OreInfo.Iron.Hue; break;
                case 1: armorHue = OreInfo.DullCopper.Hue; break;
                case 2: armorHue = OreInfo.Copper.Hue; break;
                case 3: armorHue = OreInfo.Bronze.Hue; break;
                case 4: armorHue = OreInfo.ShadowIron.Hue; break;
                case 5: armorHue = OreInfo.Gold.Hue; break;
                case 6: armorHue = OreInfo.Agapite.Hue; break;
                case 7: armorHue = OreInfo.Verite.Hue; break;
                case 8: armorHue = OreInfo.Valorite.Hue; break;
            }

            switch (Utility.Random(9))
            {
                default:
                case 0: cloakShoeHue = OreInfo.Iron.Hue; break;
                case 1: cloakShoeHue = OreInfo.DullCopper.Hue; break;
                case 2: cloakShoeHue = OreInfo.Copper.Hue; break;
                case 3: cloakShoeHue = OreInfo.Bronze.Hue; break;
                case 4: cloakShoeHue = OreInfo.ShadowIron.Hue; break;
                case 5: cloakShoeHue = OreInfo.Gold.Hue; break;
                case 6: cloakShoeHue = OreInfo.Agapite.Hue; break;
                case 7: cloakShoeHue = OreInfo.Verite.Hue; break;
                case 8: cloakShoeHue = OreInfo.Valorite.Hue; break;
            }

            if (Female)
                EquipItem(new FemalePlateChest(), armorHue);
            else
                EquipItem(new PlateChest(), armorHue);

            EquipItem(new PlateLegs(), armorHue);
            EquipItem(new PlateArms(), armorHue);
            EquipItem(new PlateGloves(), armorHue);

            EquipItem(new Cloak(), cloakShoeHue);
        }

        [Constructable]
        public MBA_Foreman()
        {
            //InitOutfit();   // Be sure to manually run this or the mobile will be naked
            Direction = Server.Direction.South;

            Title = "the Foreman";
        }

        public MBA_Foreman(Serial serial) : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.WriteEncodedInt((Int32)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadEncodedInt();
        }
    }
}