﻿/*****************************************************************************************************************************
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Mobiles;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION GROUPS ///

namespace Custom.ReputationSystem
{
    [CorpseName("a lesser elemental corpse")]
    public class LesserElemental : BaseCreature
    {
        [Constructable]
        public LesserElemental() : base(AIType.AI_Melee, FightMode.Closest, 10, 1, 0.2, 0.4)
        {
            this.Name = "Lesser Elemental";
            this.NameHue = 0x18;
            this.Body = 14;
            this.BaseSoundID = 268;
            this.Hue = 0xD2;

            this.SetStr(60, 75);
            this.SetDex(36, 45);
            this.SetInt(31, 52);

            this.SetHits(76, 93);
            this.SetMana(0);

            this.SetDamage(2, 3);

            this.SetDamageType(ResistanceType.Physical, 100);

            this.SetResistance(ResistanceType.Physical, 30, 35);
            this.SetResistance(ResistanceType.Fire, 10, 20);
            this.SetResistance(ResistanceType.Cold, 10, 20);
            this.SetResistance(ResistanceType.Poison, 15, 25);
            this.SetResistance(ResistanceType.Energy, 15, 25);

            this.SetSkill(SkillName.MagicResist, 20.1, 45.0);
            this.SetSkill(SkillName.Tactics, 30.1, 50.0);
            this.SetSkill(SkillName.Wrestling, 30.1, 50.0);

            this.Fame = 500;
            this.Karma = -500;

            this.VirtualArmor = 34;
            this.ControlSlots = 2;
        }

        public LesserElemental(Serial serial) : base(serial)
        {
        }

        public override Boolean CanFlee { get { return false; } }
        public override Boolean BleedImmune { get { return true; } }

        public override Boolean IsEnemy(Mobile m)
        {
            return false;
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);
            writer.Write((Int32)0);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);
            Int32 version = reader.ReadInt();
        }
    }
}