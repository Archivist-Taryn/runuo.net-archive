﻿/*****************************************************************************************************************************
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Engines.Quests;
using Server.Items;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION GROUPS ///

namespace Custom.ReputationSystem
{
    public class LargeBlacksmithRewardBag : Bag
    {
        public LargeBlacksmithRewardBag() : base()
        {
            Hue = BaseReward.RewardBagHue();

            DropItem(new Gold(Utility.RandomMinMax(500, 1000)));

            Item rewardItem = SmallBlacksmithRewardBag.GetItemReward();

            if (rewardItem != null)
                DropItem(rewardItem);

            rewardItem = SmallBlacksmithRewardBag.GetItemReward();

            if (rewardItem != null)
                DropItem(rewardItem);

            if (Utility.RandomDouble() < 0.15)
                DropItem(BaseReward.SmithRecipe());
        }

        public LargeBlacksmithRewardBag(Serial serial) : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();
        }
    }
}
