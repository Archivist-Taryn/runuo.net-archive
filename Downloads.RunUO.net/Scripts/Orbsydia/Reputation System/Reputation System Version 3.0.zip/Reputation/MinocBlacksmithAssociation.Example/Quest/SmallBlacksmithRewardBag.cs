﻿/*****************************************************************************************************************************
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Engines.Quests;
using Server.Items;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION GROUPS ///

namespace Custom.ReputationSystem
{
    public class SmallBlacksmithRewardBag : Bag
    {
        public SmallBlacksmithRewardBag() : base()
        {
            Hue = BaseReward.RewardBagHue();

            DropItem(new Gold(Utility.RandomMinMax(250, 500)));

            Item rewardItem = GetItemReward();

            if (rewardItem != null)
                DropItem(rewardItem);

            if (Utility.RandomDouble() < 0.1)
                DropItem(BaseReward.SmithRecipe());
        }

        // This is simply a static routine used to generate a random item reward.
        public static Item GetItemReward()
        {
            Double rnd = Utility.RandomDouble();

            if (rnd <= 0.02)
                return new PowderOfTemperament();       // 2% Chance
            else if (rnd <= 0.05)
                return new RingmailGlovesOfMining(5);   // 3% Chance
            else if (rnd <= 0.1)
                return new StuddedGlovesOfMining(3);    // 5% Chance
            else if (rnd <= 0.17)
                return new LeatherGlovesOfMining(1);    // 7% Chance
            else if (rnd <= 0.32)
                return new GargoylesPickaxe();          // 15% Chance
            else if (rnd <= 0.66)
                return new SturdyPickaxe();             // 34% Chance
            else
                return new SturdyShovel();              // 34% Chance
        }

        public SmallBlacksmithRewardBag(Serial serial) : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            Int32 version = reader.ReadInt();
        }
    }
}
