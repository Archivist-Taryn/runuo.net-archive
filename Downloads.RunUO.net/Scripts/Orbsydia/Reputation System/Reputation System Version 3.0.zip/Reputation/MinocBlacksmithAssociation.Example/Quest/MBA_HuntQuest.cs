﻿/*****************************************************************************************************************************
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server;
using Server.Engines.Quests;
using Server.Mobiles;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION GROUPS ///

namespace Custom.ReputationSystem
{
    public class MBA_HuntQuest : ReputationQuest
    {
        // This must contain an instance of your reputation group
        public override BaseReputationGroup ReputationGroup { get { return new MinocBlacksmithAssociation(); } }

        /*
         * This routine is used to determine if reputation can be awarded for this quest.
         * 
         * This routine, in combination with the creature killing hook found the reputation group definition, can be used to
         * create complex conditions on how players can earn reputation.
         * 
         * Consider the following example:
         *      The creature killing hook allows player to gain reputation up to Well Known by killing lizardmen.
         *      
         *      At the same time, the player can complete quests that allows him/her to gain reputation up to Trusted.
         *      
         *      In order to attain Member reputation, a second section of the creature killing hook allows the players
         *      to gain reputation up to Member by killing Dragons.
         */

        public MBA_HuntQuest() : base()
        {
        }

        public override void InitializeQuest(PlayerMobile from, BaseReputationQuestGiver questGiver)
        {
            // Use this variable to specify the name of your kill quest
            QuestName = "Favor to Miners";

            // Specify the number of creatures the player needs to kill to complete the quest
            Int32 rnd = Utility.Random(3);
            GoalAmount = 10 + (rnd * 10);

            // Use this variable to specify the text of the quest offer
            CustomDescription = String.Format("Hail {0}!<BR><BR>You look like an able bodied adventurer.  Perhaps you can assist me.<BR><BR>" +
                "The blacksmiths of Minoc get most of their iron from deep within these mines, but the mine has recently " +
                "become overrun with lesser elementals.<BR><BR>The Minoc Blacksmithing Association would like to enlist you, {0}, to " +
                "exterminate {1} of these foul creatures.", from.Name, GoalAmount);

            // Use this variable to specify the text that is displayed when talking to the quest giver during the quest
            CustomUncomplete = "You still have more lesser elementals to slay.  Please come back when you are finished.";

            // Use this variable to specify the text that is displayed when the player completes the quest
            CustomComplete = "You have done it!  We will send messengers to our miners at once to inform them.";

            // Use this variable to specify the text that is displayed if the quest is refused
            CustomRefuse = String.Format("Very well. Perhaps you will have time to assist us another time.", questGiver.Name);

            GoalName = "Lesser Elemental";           // Specify the name of the target creature
            GoalType = typeof(LesserElemental);      // Specify the Type of the target creature
            ReputationRewarded = 250;               // Specify the number of repuation points the player will receive upon completion

            AddObjective(new SlayObjective(GoalType, GoalName, GoalAmount));

            if (GoalAmount > 20)
                AddReward(new BaseReward(typeof(LargeBlacksmithRewardBag), "Large Blacksmith Reward Bag"));
            else
                AddReward(new BaseReward(typeof(SmallBlacksmithRewardBag), "Small Blacksmith Reward Bag"));
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((Int32)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            // Add null objectives to allow for proper deserialization
            AddObjective(new SlayObjective(null, null, -1));

            base.Deserialize(reader);

            Int32 version = reader.ReadInt();

            // Initialize quest parameters after deserialization completes
            SlayObjective o = (SlayObjective)Objectives[0];
            o.Creature = GoalType;
            o.Name = GoalName;
            o.MaxProgress = GoalAmount;

            // Reinitialize quest rewards
            if (GoalAmount > 20)
                AddReward(new BaseReward(typeof(LargeBlacksmithRewardBag), "Large Blacksmith Reward Bag"));
            else
                AddReward(new BaseReward(typeof(SmallBlacksmithRewardBag), "Small Blacksmith Reward Bag"));
        }
    }
}