﻿/*****************************************************************************************************************************
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Version 3.0
 * Designed for ForkUO 0.2
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 1/30/2013
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 ****************************************************************************************************************************/

using System;
using Server.Commands;
using Server.Mobiles;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION GROUPS ///

namespace Custom.ReputationSystem
{
    public class MinocBlacksmithAssociation : BaseReputationGroup
    {
        // This must contain the name of the reputation group
        public override string GroupName { get { return "Minoc Blacksmithing Association"; } }

        // This must contain the starting reputation level for this group
        public override ReputationLevel StartingReputation { get { return ReputationLevel.Neutral; } }

        // This must contain the abbreviation of the reputation group
        public override String Abbreviation { get { return "MBA"; } }

        // The Initialize routine must be present only if you want to catch KilledByEvents
        public static void Initialize()
        {
            // Register the reputation group with the system
            ReputationSystem.RegisterReputationGroup(new MinocBlacksmithAssociation());

            // First create an instance of your reputation group (since this routine is static)
            MinocBlacksmithAssociation repGroup = new MinocBlacksmithAssociation();

            // Register the creatures that will award repution when slain
            ReputationSystem.RegisterReputationKillGain(typeof(LesserElemental), repGroup, ReputationLevel.Friendly, 5);
            ReputationSystem.RegisterReputationKillGain(typeof(EarthElemental), repGroup, ReputationLevel.WellKnown, 20);
            ReputationSystem.RegisterReputationKillGain(typeof(DullCopperElemental), repGroup, ReputationLevel.WellKnown, 30);
            ReputationSystem.RegisterReputationKillGain(typeof(ShadowIronElemental), repGroup, ReputationLevel.Trusted, 40);
            ReputationSystem.RegisterReputationKillGain(typeof(CopperElemental), repGroup, ReputationLevel.Trusted, 50);
            ReputationSystem.RegisterReputationKillGain(typeof(BronzeElemental), repGroup, ReputationLevel.Trusted, 60);
            ReputationSystem.RegisterReputationKillGain(typeof(GoldenElemental), repGroup, ReputationLevel.Trusted, 70);
            ReputationSystem.RegisterReputationKillGain(typeof(AgapiteElemental), repGroup, ReputationLevel.Member, 80);
            ReputationSystem.RegisterReputationKillGain(typeof(VeriteElemental), repGroup, ReputationLevel.Member, 90);
            ReputationSystem.RegisterReputationKillGain(typeof(ValoriteElemental), repGroup, ReputationLevel.Member, 100);
        }

        // This routine is used to place spawners for your reputation vendors, quest givers, custom monsters, items or anything else you need to spawn for your system.
        // This routine only needs to exist to initiate your spawns when the [RepSpawn command is issued.
        public override void ActivateSpawnRequest(CommandEventArgs e)
        {
            ActivateSpawn(e.Mobile, "Spawns/Reputation/mba.xml");

            CommandSystem.Handle(e.Mobile, String.Format("{0}XmlSpawnerRespawnAll MBA_Hunt", Server.Commands.CommandSystem.Prefix));
        }
    }
}