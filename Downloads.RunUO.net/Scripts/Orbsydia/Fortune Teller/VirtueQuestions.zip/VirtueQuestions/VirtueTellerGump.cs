//------------\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\Created by Abracadabra//////////////////////////////////////////////////////-------------
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Edited by Abracadabra with many modifications.//////////////////////////////////////////////////////
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Please report any bugs to http://craftuo.com/index.php?forums/support.17/  Thank you.////////////////////////////////////

using System; 
using Server; 
using Server.Gumps; 
using Server.Network;
using Server.Items;
using Server.Mobiles;
using Server.Misc;

namespace Server.Gumps
{ 
   public class VirtueTellerGump : Gump 
   { 
      public VirtueTellerGump( Mobile owner ) : base( 50,50 ) 
      {

		        Closable=false;
			Dragable=true;
			owner.Frozen=true;
//----------------------------------------------------------------------------------------------------

				AddPage( 0 );
			AddImageTiled(  54, 33, 369, 400, 2624 );
			AddAlphaRegion( 54, 33, 369, 400 );

			AddImageTiled( 416, 39, 44, 389, 203 );
//--------------------------------------Window size bar--------------------------------------------
			
			AddImage( 97, 49, 9005 );
			AddImageTiled( 58, 39, 29, 390, 10460 );
			AddImageTiled( 412, 37, 31, 389, 10460 );
			AddLabel( 140, 60, 0x34, "The Test of Virtue" );
			
//			AddImage( 100, 160, 61002 );
			AddImage( 100, 160, 65000 );

			AddHtml( 207, 140, 200, 200, "<BODY>" +
//----------------------/----------------------------------------------/
//"<BASEFONT COLOR=WHITE>\"Welcome to this place, traveler.\" The gypsy's voice echoes throughout the chamber. Your heart races with the thought of attempting this yet again. \"It is time to read the path of you future She says. Step Forward.\"" +
//"<BASEFONT COLOR=WHITE> As you draw near, she prepares several reagents for use in what appears to be some form of spell. \"Sit... and we shall begin.\" You rest your weary bones in the chair directly across from her, and gesture for her to continue." +
//"<BASEFONT COLOR=WHITE> \"Let me tell you, should you not like the outcome of your fortune, you can reroll or abort and continue as you are. Be forwarned, should you accept my fortune you will be a more powerful Avatar.\"" +

"<BASEFONT COLOR=WHITE>\"Welcome, O Seeker. We have been waiting such a long time.\" The gypsy's voice seems to come from a great distance away. \"It is time to read the path of your future,\" she says. \"Let us begin the casting.\"" +
"<BASEFONT COLOR=WHITE> As you draw near the incense thickens, and you get fleeting images of distant worlds scattered like pearls across the void before the vision passes. \"Sit... and we shall begin.\" She lays out eight cards on the table, each one bearing a different symbol." +
"<BASEFONT COLOR=WHITE> \"Before we begin, you should remember that all roads are open to you. If you wish me to cast the cards again, simply ask.\"" +

						     "</BODY>", false, true);

			AddImage( 430, 9, 10441);
			AddImageTiled( 40, 38, 17, 391, 9263 );
			AddImage( 6, 25, 10421 );
			AddImage( 34, 12, 10420 );
			AddImageTiled( 94, 25, 342, 15, 10304 );
			AddImageTiled( 40, 427, 415, 16, 10304 );
			AddImage( -10, 314, 10402 );
			AddImage( 56, 150, 10411 );
			AddImage( 155, 120, 2103 );
			AddImage( 136, 84, 96 );


			AddButton( 95, 340, 0x2A4E, 0x2A4E, 1, GumpButtonType.Reply, 0 );
			AddHtml( 135, 340, 280, 200, "<BODY>" +
//----------------------/----------------------------------------------/
"<BASEFONT COLOR=WHITE>Begin Fortune telling." +
						     "</BODY>", false, false);

			AddButton( 95, 380, 0x2A62, 0x2A62, 0, GumpButtonType.Reply, 0 );
			AddHtml( 135, 380, 280, 200, "<BODY>" +
//----------------------/----------------------------------------------/
"<BASEFONT COLOR=WHITE>Decline Fortune telling." +
						     "</BODY>", false, false);
		}

//--------------------------------------------------------------------------------------------------------------

      public override void OnResponse( NetState state, RelayInfo info ) //Function for GumpButtonType.Reply Buttons 
      { 
          Mobile from = state.Mobile;
	  state.Mobile.Frozen=false;
         
	 switch ( info.ButtonID )
 
         { 
            case 0: 
            { 
               break;
            } 

	    case 1: 
            { 
// comment this out if you don't it. This lets people retake the test for different stats
// if that's what they want, and not keep gaining more and more. Heh. =)

		from.RawStr = 10;
		from.RawDex = 10;
		from.RawInt = 10;

// lock meditation and focus. We're going to be increasing dex and int, let's not spam
// the hell out of the player. Skill is unlocked at the end.

Skill med = from.Skills[SkillName.Meditation];
med.SetLockNoRelay( SkillLock.Locked ); med.Update();

Skill foc = from.Skills[SkillName.Focus];
foc.SetLockNoRelay( SkillLock.Locked ); foc.Update();


int QoneA;
int QoneB;
int QtwoA;
int QtwoB;
int QthreeA;
int QthreeB;
int QfourA;
int QfourB;


QoneA = Utility.RandomMinMax( 1, 8 );


QoneB = Utility.RandomMinMax( 1, 8 );

while ( QoneB == QoneA )
{
	QoneB = Utility.RandomMinMax( 1, 8 );
}

QtwoA = Utility.RandomMinMax( 1, 8 );

while ( QtwoA == QoneA || QtwoA == QoneB )
{
	QtwoA = Utility.RandomMinMax( 1, 8 );
}

QtwoB = Utility.RandomMinMax( 1, 8 );

while ( QtwoB == QoneA || QtwoB == QoneB || QtwoB == QtwoA )
{
	QtwoB = Utility.RandomMinMax( 1, 8 );
}

QthreeA = Utility.RandomMinMax( 1, 8 );

while ( QthreeA == QoneA || QthreeA == QoneB || QthreeA == QtwoA || QthreeA == QtwoB )
{
	QthreeA = Utility.RandomMinMax( 1, 8 );
}

QthreeB = Utility.RandomMinMax( 1, 8 );

while ( QthreeB == QoneA || QthreeB == QoneB || QthreeB == QtwoA || QthreeB == QtwoB || QthreeB == QthreeA )
{
	QthreeB = Utility.RandomMinMax( 1, 8 );
}

QfourA = Utility.RandomMinMax( 1, 8 );

while ( QfourA == QoneA || QfourA == QoneB || QfourA == QtwoA || QfourA == QtwoB || QfourA == QthreeA || QfourA == QthreeB )
{
	QfourA = Utility.RandomMinMax( 1, 8 );
}

QfourB = Utility.RandomMinMax( 1, 8 );

while ( QfourB == QoneA || QfourB == QoneB || QfourB == QtwoA || QfourB == QtwoB || QfourB == QthreeA || QfourB == QthreeB || QfourB == QfourA )
{
	QfourB = Utility.RandomMinMax( 1, 8 );
}


// sort results, questions absolutely must have the lower value come first


if ( QoneA > QoneB )
{
	int tmp = QoneB;
	QoneB = QoneA;
	QoneA = tmp;
}

if ( QtwoA > QtwoB )
{
	int tmp = QtwoB;
	QtwoB = QtwoA;
	QtwoA = tmp;
}

if ( QthreeA > QthreeB )
{
	int tmp = QthreeB;
	QthreeB = QthreeA;
	QthreeA = tmp;
}

if ( QfourA > QfourB )
{
	int tmp = QfourB;
	QfourB = QfourA;
	QfourA = tmp;
}


//                                                                                                                  current question, answer values
	       from.SendGump( new VirtueQuestionGump( from, QoneA, QoneB, QtwoA, QtwoB, QthreeA, QthreeB, QfourA, QfourB, 1, 0, 0, 0, 0, 0, 0, 0 ) );
	       break;
            } 

         }
     }
   }
}