//------------\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\Created by Abracadabra//////////////////////////////////////////////////////-------------
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Edited by Abracadabra with many modifications.//////////////////////////////////////////////////////
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Please report any bugs to http://craftuo.com/index.php?forums/support.17/  Thank you.////////////////////////////////

using System;
using Server.Items;
using Server.ContextMenus;
using Server.Gumps;
using Server.Network;

namespace Server.Items
{
	// I think that's all of them...
	[FlipableAttribute( 4773, 4774, 4775, 4776, 4777, 4778, 4779, 4780 )]
	public class VirtueTarot : Item
	{
                
		[Constructable]
		public VirtueTarot() : base ( 4775 )
		{
			Name = "virtue cards";
			Movable = false;
		}

		public VirtueTarot( Serial serial ) : base( serial )
		{
		}

		public override void OnDoubleClick( Mobile from )
		{  
			from.SendGump( new VirtueTellerGump( from ) ); 
	        } 

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	} 
}