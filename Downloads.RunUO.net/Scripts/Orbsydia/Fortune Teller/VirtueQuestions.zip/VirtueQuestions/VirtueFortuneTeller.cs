//------------\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\Created by Abracadabra//////////////////////////////////////////////////////-------------
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Edited by Abracadabra with many modifications.//////////////////////////////////////////////////////
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Please report any bugs to http://craftuo.com/index.php?forums/support.17/  Thank you.////////////////////////////////

using System;
using Server.Items;
using Server.ContextMenus;
using Server.Gumps;
using Server.Network;

namespace Server.Mobiles
{
	[CorpseName( "VirtueFortuneTeller corpse" )]
	public class VirtueFortuneTeller : Mobile
	{
		[Constructable]
		public VirtueFortuneTeller()
		{
                        Title = "the fortune teller";
			Blessed = true;

			InitBody();
			InitOutfit();
		}

		public void InitBody()
		{
			Hue = Utility.RandomSkinHue();

			this.Body = 0x191;
			this.Name = NameList.RandomName( "female" );
			this.CantWalk = true;
		}
		
		public virtual void InitOutfit()
		{
			AddItem( new GnarledStaff() );

			Item item = new FancyDress( Utility.RandomNeutralHue() );
			item.Layer = Layer.InnerTorso;
			AddItem( item );
			AddItem( new Boots( Utility.RandomNeutralHue() ) );

			Item hair = new LongHair( 1153 );
			hair.Hue = Utility.RandomNondyedHue();
			hair.Layer = Layer.Hair;
			hair.Movable = false;
			AddItem( hair );
		}

		public VirtueFortuneTeller( Serial serial ) : base( serial )
		{
		}

		public override void OnDoubleClick( Mobile from )
		{  
			from.SendGump( new VirtueTellerGump( from ) ); 
	        } 

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	} 
}