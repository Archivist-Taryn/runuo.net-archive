//------------\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\Created by Abracadabra//////////////////////////////////////////////////////-------------
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Edited by Abracadabra with many modifications.//////////////////////////////////////////////////////
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ Please report any bugs to http://craftuo.com/index.php?forums/support.17/  Thank you.////////////////////////////////

// This one gump handles all the questions, calling itself
// each time with the updated variables. The code is fairly 'sloppy', as in I'm sure there
// were better ways to do many of the things in here. I'm still more than a bit clumsy with my
// C# code, due to lack of skill and lack of knowledge.
//
// 
// uncomment the following line to enable the custom graphics.
 #define CUSTOM_GRAPHICS


using System; 
using Server; 
using Server.Gumps; 
using Server.Network;
using Server.Items;
using Server.Mobiles;
using Server.Misc;

namespace Server.Gumps
{ 
	public class VirtueQuestionGump : Gump
	{
		private int m_QoneA;
		private int m_QoneB;
		private int m_QtwoA;
		private int m_QtwoB;
		private int m_QthreeA;
		private int m_QthreeB;
		private int m_QfourA;
		private int m_QfourB;

		private int m_Currentquestion;

		private int m_Aone;
		private int m_Atwo;
		private int m_Athree;
		private int m_Afour;
		private int m_Afive;
		private int m_Asix;
		private int m_Aseven;

		private Mobile m_From;
	
		public VirtueQuestionGump( Mobile from, int QoneA, int QoneB, int QtwoA, int QtwoB, int QthreeA, int QthreeB, int QfourA, int QfourB, int currentquestion, int Aone, int Atwo, int Athree, int Afour, int Afive, int Asix, int Aseven ) : base( 50,50 )
		{

			m_From = from;


			m_QoneA = QoneA;
			m_QoneB = QoneB;
			m_QtwoA = QtwoA;
			m_QtwoB = QtwoB;
			m_QthreeA = QthreeA;
			m_QthreeB = QthreeB;
			m_QfourA = QfourA;
			m_QfourB = QfourB;

			m_Currentquestion = currentquestion;

			m_Aone = Aone;
			m_Atwo = Atwo;
			m_Athree = Athree;
			m_Afour = Afour;
			m_Afive = Afive;
			m_Asix = Asix;
			m_Aseven = Aseven;


			Closable=false;
			Dragable=true;
			from.Frozen=true;

			int first;   // first virtue to compare
			int second;  // second virtue to compare


			switch ( m_Currentquestion )
			{
				case 1:
				first = m_QoneA;
				second = m_QoneB;
				break;

				case 2:
				first = m_QtwoA;
				second = m_QtwoB;
				break;

				case 3:
				first = m_QthreeA;
				second = m_QthreeB;
				break;

				case 4:
				first = m_QfourA;
				second = m_QfourB;
				break;

				case 5:
				first = m_Aone;
				second = m_Atwo;
				break;

				case 6:
				first = m_Athree;
				second = m_Afour;
				break;

				case 7:
				first = m_Afive;
				second = m_Asix;
				break;

				default:
				m_From.SendMessage( "Error, invalid question number! Unrecoverable!" );
				return;
				break;
			}



			// this check should never happen
			if ( first > second )
			{
				int tmp = first;
				first = second;
				second = tmp;
				m_From.SendMessage( "Error! Virtues in wrong order! This should never happen!");
				return;
			}

			// likewise.
			if ( first == second )
			{
				m_From.SendMessage( "Error! Virtues identical! This should never happen!");
				return;
			}


			//----------------------------------------------------------------------------------------------------
			
			AddPage( 0 );
			AddImageTiled(  54, 33, 369, 400, 2624 );
			AddAlphaRegion( 54, 33, 369, 400 );
			
			AddImageTiled( 416, 39, 44, 389, 203 );
			//--------------------------------------Window size bar--------------------------------------------
			
			AddImage( 97, 49, 9005 );
			AddImageTiled( 58, 39, 29, 390, 10460 );
			AddImageTiled( 412, 37, 31, 389, 10460 );
			AddLabel( 140, 60, 0x34, "Question: " + m_Currentquestion );
			
			
			AddHtml( 107, 137, 300, 230, "<BODY>" +
			        //----------------------/----------------------------------------------/
			        "<BASEFONT COLOR=WHITE>" + GetQuestion( first, second, 1 ) +
			        "</BODY>", false, false);
			
			AddImage( 430, 9, 10441);
			AddImageTiled( 40, 38, 17, 391, 9263 );
			AddImage( 6, 25, 10421 );
			AddImage( 34, 12, 10420 );
			AddImageTiled( 94, 25, 342, 15, 10304 );
			AddImageTiled( 40, 427, 415, 16, 10304 );
			AddImage( -10, 314, 10402 );
			AddImage( 56, 150, 10411 );
			AddImage( 155, 120, 2103 );
			AddImage( 136, 84, 96 );
			

#if CUSTOM_GRAPHICS			
			AddImage( 145, 207, GetCustomVirtueGraphic( first ) );	//Change Card number here, this is for use WITH the verdata.mul
#else			
			AddImage( 150, 220, GetVirtueGraphic( first ) );			//---these 2 lines are for use WITHOUT the verdata.mul
			AddLabel( 150, 280, 0x34, GetVirtueName( first ) );
#endif			


#if CUSTOM_GRAPHICS			
			AddImage( 275, 207, GetCustomVirtueGraphic( second ) );	//Change Card number here, this is for use WITH the verdata.mul
#else			
			AddImage( 270, 220, GetVirtueGraphic( second ) );
			AddLabel( 280, 280, 0x34, GetVirtueName( second ) );		//---these 2 lines are for use WITHOUT the verdata.mul
#endif			

			AddButton( 95, 340, 0x2A4E, 0x2A4E, 0, GumpButtonType.Reply, 0 );
			AddHtml( 135, 340, 280, 200, "<BODY>" +
			        //----------------------/----------------------------------------------/
			        "<BASEFONT COLOR=WHITE>" + GetQuestion( first, second, 2 ) +  // line 2
			        "</BODY>", false, false);
			
			AddButton( 95, 380, 0x2A3A, 0x2A3A, 1, GumpButtonType.Reply, 0 );
			AddHtml( 135, 380, 280, 200, "<BODY>" +
			        //----------------------/----------------------------------------------/
			        "<BASEFONT COLOR=WHITE>" + GetQuestion( first, second, 3 ) +  // line 3
			        "</BODY>", false, false);
			
		}
		
		//--------------------------------------------------------------------------------------------------------------
		
		public override void OnResponse( NetState state, RelayInfo info ) //Function for GumpButtonType.Reply Buttons
		{
			Mobile from = state.Mobile;
			state.Mobile.Frozen=false;


			switch ( m_Currentquestion )
			{
				case 1:
				if ( info.ButtonID == 0 )
				{
					m_Aone = m_QoneA;
				}
				else
				{
					m_Aone = m_QoneB;
				}
				DoStatGain( from, m_Aone );
				break;


				case 2:
				if ( info.ButtonID == 0 )
				{
					m_Atwo = m_QtwoA;
				}
				else
				{
					m_Atwo = m_QtwoB;
				}
				DoStatGain( from, m_Atwo );
				break;


				case 3:
				if ( info.ButtonID == 0 )
				{
					m_Athree = m_QthreeA;
				}
				else
				{
					m_Athree = m_QthreeB;
				}
				DoStatGain( from, m_Athree );
				break;


				case 4:
				if ( info.ButtonID == 0 )
				{
					m_Afour = m_QfourA;
				}
				else
				{
					m_Afour = m_QfourB;
				}
				DoStatGain( from, m_Afour );



				// fix order, since it no longer matters
				// and Q5&6 needs Aone thru Afour in low->high order

				if ( m_Aone > m_Atwo )
				{
					int tmp = m_Atwo;
					m_Atwo = m_Aone;
					m_Aone = tmp;
				}

				if ( m_Athree > m_Afour )
				{
					int tmp = m_Afour;
					m_Afour = m_Athree;
					m_Athree = tmp;
				}

				// damn this kind of fudging shit is clumsy...


				break;


				case 5:
				if ( info.ButtonID == 0 )
				{
					m_Afive = m_Aone;
				}
				else
				{
					m_Afive = m_Atwo;
				}
				DoStatGain( from, m_Afive );
				break;

				case 6:
				if ( info.ButtonID == 0 )
				{
					m_Asix = m_Athree;
				}
				else
				{
					m_Asix = m_Afour;
				}
				DoStatGain( from, m_Asix );

				// fix order, since it no longer matters
				// and Q7 needs Afive&Asix in low->high order
				if ( m_Afive > m_Asix )
				{
					int tmp = m_Asix;
					m_Asix = m_Afive;
					m_Afive = tmp;
				}
				break;

				case 7:
				if ( info.ButtonID == 0 )
				{
					m_Aseven = m_Afive;
				}
				else
				{
					m_Aseven = m_Asix;
				}
				DoStatGain( from, m_Aseven );
				break;



			}

			if ( m_Currentquestion < 7 )
			{
// do next question

				m_Currentquestion++;
				from.SendGump( new VirtueQuestionGump( from, m_QoneA, m_QoneB, m_QtwoA, m_QtwoB, m_QthreeA, m_QthreeB, m_QfourA, m_QfourB, m_Currentquestion, m_Aone, m_Atwo, m_Athree, m_Afour, m_Afive, m_Asix, m_Aseven ) );
			}
			else
			{
// finish up.



// max out health, stamina, and mana

from.Hits = from.HitsMax;
from.Stam = from.StamMax;
from.Mana = from.ManaMax;


// unlock meditation and focus

Skill med = from.Skills[SkillName.Meditation];
med.SetLockNoRelay( SkillLock.Up ); med.Update();

Skill foc = from.Skills[SkillName.Focus];
foc.SetLockNoRelay( SkillLock.Up ); foc.Update();


				switch ( m_Aseven )  // give 'final' virtue gump.
				{

					case 1:  // honesty
				//	from.SendGump( new MageGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Mage" );
					break;

					case 2: // compassion
				//	from.SendGump( new BardGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Bard" );
					break;

					case 3: // valor
				//	from.SendGump( new FighterGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Fighter" );
					break;

					case 4: // justice
				//	from.SendGump( new DruidGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Druid" );
					break;

					case 5: // sacrifice
				//	from.SendGump( new TinkerGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Tinker" );
					break;

					case 6: // honor
				//	from.SendGump( new PaladinGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Paladin" );
					break;

					case 7: // spirituality
				//	from.SendGump( new RangerGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Ranger" );
					break;

					case 8: // humility
				//	from.SendGump( new ShepherdGateGump( from ) );
					from.SendMessage( "Your recommended profession is: Shepherd" );
					break;

					default:
					from.SendMessage( "Profession selection received an invalid virtue id: {0}", m_Aseven );
					break;
				}
			}
		}




		public void DoStatGain( Mobile from, int virtue )
		{
// uncomment the below line to easily disable stat gain in these scripts.
// return;

// 1 = honesty, 2 = compassion, 3 = valor, 4 = justice, 5 = sacrifice, 6 = honor, 7 = spirituality, 8 = humility

			switch( virtue )
			{
				case 1: // honesty(blue) = truth = int
				from.RawInt = from.RawInt + 6;
				break;

				case 2: // compassion(yellow) = love = dex
				from.RawDex = from.RawDex + 6;
				break;

				case 3: // valor(red) = courage = str
				from.RawStr = from.RawStr + 6;
				break;

				case 4: // justice(green) = truth + love = int + dex
				from.RawInt = from.RawInt + 3;
				from.RawDex = from.RawDex + 3;
				break;

				case 5: // sacrifice(orange) = love + courage = str + dex
				from.RawStr = from.RawStr + 3;
				from.RawDex = from.RawDex + 3;
				break;

				case 6: // honor(purple) = courage + truth = int + str
				from.RawStr = from.RawStr + 3;
				from.RawInt = from.RawInt + 3;
				break;

				case 7: // spirituality(white) = love + courage + truth = str + int + dex
				from.RawStr = from.RawStr + 2;
				from.RawInt = from.RawInt + 2;
				from.RawDex = from.RawDex + 2;
				break;

				case 8: // humility(black) = !love + !courage + !truth = str + int + dex (I'm not punishing people for being humble. =P =)
				from.RawStr = from.RawStr + 2;
				from.RawInt = from.RawInt + 2;
				from.RawDex = from.RawDex + 2;
				break;

				default:
				from.SendMessage( "ERROR: DoStatGain received an invalid virtue number: {0}", virtue );
				break;
			}

		}

		public string GetVirtueName( int virtue )
		{
			switch ( virtue )
			{
				case 1:
				return "Honesty";

				case 2:
				return "Compassion";

				case 3:
				return "Valor";

				case 4:
				return "Justice";

				case 5:
				return "Sacrifice";

				case 6:
				return "Honor";

				case 7:
				return "Spirituality";

				case 8:
				return "Humility";

				default:
				return "Invalid virtue!";
			}
		}

		public int GetVirtueGraphic( int virtue )
		{

/*
   I have no idea how these numbers work, just that they do.
   They don't corrospond to anything in InsideUO, they're a
   few digits off from the actual virtue images.. but they work. =P
*/

			switch ( virtue )
			{
				case 1:  // honesty
				return 106;

				case 2: // compassion
				return 105;

				case 3: // valor
				return 112;

				case 4: // justice
				return 109;

				case 5: // sacrifice
				return 110;

				case 6: // honor
				return 107;

				case 7: // spirituality
				return 111;

				case 8: // humility
				return 108;

				default:
				return 003; // should be an X...
			}
		}


		public int GetCustomVirtueGraphic( int virtue )
		{
/*
	To use the custom graphics you must have the graphic patch applied to every client
	who will connect. I don't know of any way to autodetect if they are installed
	unless you add a gump before the main gump that asks the player if they see the
	graphic or not, and even then it would mean another variable passed to this
	instead of the #define...
*/

			switch ( virtue )
			{
				case 1:  // honesty
				return 65004;

				case 2: // compassion
				return 65005;

				case 3: // valor
				return 65008;

				case 4: // justice
				return 65006;

				case 5: // sacrifice
				return 65007;

				case 6: // honor
				return 65003;

				case 7: // spirituality
				return 65001;

				case 8: // humility
				return 65002;

				default:
				return 003; // should be an X...
			}
		}


		public string GetQuestion( int virtueone, int virtuetwo, int line)
		{
			string[,,]questiontext = new string[9,9,4]; // I hope this works... defined with 1 extra due to 0 being 'null' and invalid.

			questiontext[1,2,1] = "Entrusted to deliver an uncounted purse of gold, thou dost meet a poor beggar. Dost thou";
			questiontext[1,2,2] = "deliver the gold knowing the Trust in thee was well-placed; or";
			questiontext[1,2,3] = "show Compassion, giving the Beggar a coin, knowing it won't be missed?";

			questiontext[1,3,1] = "Thou has been prohibited by thy absent Lord from joining thy friends in a close pitched battle. Dost thou";
			questiontext[1,3,2] = "refrain, so thou may Honestly claim obedience; or";
			questiontext[1,3,3] = "show Valor, and aid thy comrades, knowing thou may deny it later?";

			questiontext[1,4,1] = "A merchant owes thy friend money, now long past due. Thou dost see the same merchant drop a purse of gold. Dost thou";
			questiontext[1,4,2] = "Honestly return the purse intact; or";
			questiontext[1,4,3] = "Justly give thy friend a portion of the gold first?";

			questiontext[1,5,1] = "Thee and thy friend are valiant but penniless warriors. Thou both go out to slay a mighty dragon. Thy friend thinks he slew it, thee did. When asked, dost thou";
			questiontext[1,5,2] = "Truthfully claim the gold; or";
			questiontext[1,5,3] = "Allow thy friend the large reward?";

			questiontext[1,6,1] = "Thou art sworn to protect thy Lord at any cost, yet thou knowest he hath committed a crime. Authorities ask thee of the affair, dost thou";
			questiontext[1,6,2] = "break thine oath by Honestly speaking; or";
			questiontext[1,6,3] = "uphold Honor by silently keeping thine oath?";

			questiontext[1,7,1] = "Thy friend seeks admittance to thy Spiritual order. Thou art asked to vouch for his purity of Spirit, of which thou art unsure. Dost thou";
			questiontext[1,7,2] = "Honestly express thy doubt; or";
			questiontext[1,7,3] = "Vouch for him, hoping for his Spiritual improvement?";

			questiontext[1,8,1] = "Thy Lord mistakenly believes he slew a dragon. Thou hast proof that thy lance felled the beast.  When asked, dost thou";
			questiontext[1,8,2] = "Honestly claim the kill and the prize; or";
			questiontext[1,8,3] = "Humbly permit thy Lord his belief?";

			questiontext[2,3,1] = "Thou dost manage to disarm thy mortal enemy in a duel. He is at thy mercy. Dost thou";
			questiontext[2,3,2] = "show Compassion by permitting him to yield; or";
			questiontext[2,3,3] = "slay him as expected of a Valiant duelist?";

			questiontext[2,4,1] = "After 20 years thou hast found the slayer of thy best friends. The villain proves to be a man who provides the sole support for a young girl. Dost thou";
			questiontext[2,4,2] = "spare him in Compassion for the girl; or";
			questiontext[2,4,3] = "slay him in the name of Justice?";

			questiontext[2,5,1] = "Thee and thy friends have been routed and ordered to retreat. In defiance of thy orders, dost thou";
			questiontext[2,5,2] = "stop in Compassion to aid a wounded companion; or";
			questiontext[2,5,3] = "Sacrifice thyself to slow the pursuing enemy, so others can escape?";

			questiontext[2,6,1] = "Thou art sworn to uphold a Lord who participates in the forbidden torture of prisoners. Each night their cries of pain reach thee. Dost thou";
			questiontext[2,6,2] = "Show Compassion by reporting the deeds; or";
			questiontext[2,6,3] = "Honor thy oath and ignore the deeds?";

			questiontext[2,7,1] = "Thou hast been taught to preserve all life as sacred. A man lies fatally stung by a venomous serpent. He pleads for a merciful death. Dost thou";
			questiontext[2,7,2] = "show Compassion and end his pain; or";
			questiontext[2,7,3] = "heed thy Spiritual beliefs and refuse?";

			questiontext[2,8,1] = "As one of the King's Guard, thy Captain has asked that one amongst you visit a hospital to cheer the children with tales of thy valiant deeds. Dost thou";
			questiontext[2,8,2] = "Show thy Compassion and play the braggart; or";
			questiontext[2,8,3] = "Humbly let another go?";

			questiontext[3,4,1] = "Thou hast been sent to secure a needed treaty with a distant Lord. Thy host is agreeable to the proposal but insults thy country at dinner. Dost thou";
			questiontext[3,4,2] = "Valiantly bear the slurs; or";
			questiontext[3,4,3] = "Justly rise and demand an apology?";

			questiontext[3,5,1] = "A mighty knight accosts thee and demands thy food. Dost thou";
			questiontext[3,5,2] = "Valiantly refuse and engage the knight; or";
			questiontext[3,5,3] = "Sacrifice thy food unto the hungry knight?";

			questiontext[3,6,1] = "During battle thou art ordered to guard thy commander's empty tent. The battle goes poorly and thou dost yearn to aid thy fellows. Dost thou";
			questiontext[3,6,2] = "Valiantly enter the battle to aid thy companions; or";
			questiontext[3,6,3] = "Honor thy post as guard?";

			questiontext[3,7,1] = "A local bully pushes for a fight. Dost thou";
			questiontext[3,7,2] = "Valiantly trounce the rogue; or";
			questiontext[3,7,3] = "Decline, knowing in thy Spirit that no lasting good will come of it?";

			questiontext[3,8,1] = "Although a teacher of music, thou art a skillful wrestler. Thou hast been asked to fight in a local championship. Dost thou";
			questiontext[3,8,2] = "accept the invitation and Valiantly fight to win; or";
			questiontext[3,8,3] = "Humbly decline knowing thou art sure to win?";

			questiontext[4,5,1] = "During a pitched battle, thou dost see a fellow desert his post, endangering many. As he flees, he is set upon by several enemies. Dost thou";
			questiontext[4,5,2] = "Justly let him fight alone; or";
			questiontext[4,5,3] = "Risk Sacrificing thine own life to aid him?";

			questiontext[4,6,1] = "Thou hast sworn to do thy Lord's bidding in all. He covets a piece of land and orders the owner removed. Dost thou";
			questiontext[4,6,2] = "serve Justice, refusing to act, thus being disgraced; or";
			questiontext[4,6,3] = "Honor thine oath and unfairly evict the landowner?";

			questiontext[4,7,1] = "Thou dost believe that virtue resides in all people. Thou dost see a rogue steal from thy Lord. Dost thou";
			questiontext[4,7,2] = "call him to Justice; or";
			questiontext[4,7,3] = "personally try to sway him back to the Spiritual path of good?";

			questiontext[4,8,1] = "Unwitnessed, thou hast slain a great dragon in self defense. A poor warrior claims the offered reward. Dost thou";
			questiontext[4,8,2] = "Justly step forward to claim the  reward; or";
			questiontext[4,8,3] = "Humbly go about life, secure in thy self-esteem?";

			questiontext[5,6,1] = "Thou art a bounty hunter sworn to return an alleged murderer. After his capture, thou believest him to be innocent.  Dost thou";
			questiontext[5,6,2] = "Sacrifice thy sizeable bounty for thy belief; or";
			questiontext[5,6,3] = "Honor thy oath to return him as thou hast promised?";

			questiontext[5,7,1] = "Thou hast spent thy life in charitable and righteous work. Thine uncle the innkeeper lies ill and asks you to take over his tavern. Dost thou";
			questiontext[5,7,2] = "Sacrifice thy life of purity to aid thy kin; or";
			questiontext[5,7,3] = "decline & follow thy Spirit's call?";

			questiontext[5,8,1] = "Thou art an elderly, wealthy eccentric. Thy end is near. Dost thou";
			questiontext[5,8,2] = "donate all thy wealth to feed hundreds of starving children, and receive public adulation;"; // "or" was removed, overflowed into the next line. This is the only question that needed to be trimmed.
			questiontext[5,8,3] = "Humbly live out thy life, willing thy fortune to thy heirs?";

			questiontext[6,7,1] = "In thy youth thou pledged to marry thy sweetheart. Now thou art on a sacred quest in distant lands. Thy sweetheart  asks thee to keep thy vow. Dost thou";
			questiontext[6,7,2] = "Honor thy pledge to wed; or";
			questiontext[6,7,3] = "follow thy Spiritual crusade?";

			questiontext[6,8,1] = "Thou art at a crossroads in thy life. Dost thou";
			questiontext[6,8,2] = "Choose the Honorable life of a Paladin, striving for Truth and Courage; or";
			questiontext[6,8,3] = "Choose the Humble life of a Shepherd, and a world of simplicity and peace?";

			questiontext[7,8,1] = "Thy parents wish thee to become an apprentice. Two positions are available. Dost thou";
			questiontext[7,8,2] = "Become an acolyte in the Spiritual order; or";
			questiontext[7,8,3] = "Become an assistant to a humble village cobbler?";


			return questiontext[virtueone,virtuetwo,line];
		}



	}
}
